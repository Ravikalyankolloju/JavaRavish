<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Inheritance in Java</title>
<meta name="description" content="Inheritance can be defined as the process where one class acquires the properties (methods and fields) of another.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Inheritance in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/inheritance-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Inheritance can be defined as the process where one class acquires the properties (methods and fields) of another.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Inheritance in Java">
<meta name="twitter:description" content="Inheritance can be defined as the process where one class acquires the properties (methods and fields) of another.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/inheritance-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>

<style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="inheritance-in-java.php">
<span itemprop="name">What is Inheritance?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Inheritance in Java</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Inheritance in Java.</h1>
<div class="card-body">
<div>
<p>Inheritance is a process of writing a new class by using existing class functionality. ‘The process by which one class acquires the properties(instance variables) and functionalities of another class is called inheritance’. This happens when one class adopts the non-private properties and methods of one class. These classes will then be referred to as superclass and subclass.</p>
<div class="tab" role="tabpanel">
<hr>
<div>
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#SingleInheritance" role="tab" data-toggle="tab">Single Inheritance</a></li>
<li role="presentation"><a href="#MultilevelInheritance" role="tab" data-toggle="tab">Multi-level Inheritance</a></li>
<li role="presentation"><a href="#HierarchicalInheritance" role="tab" data-toggle="tab">Hierarchical Inheritance</a></li>
<li role="presentation"><a href="#MultipleInheritance" role="tab" data-toggle="tab">Multiple Inheritance</a></li>
<li role="presentation"><a href="#HybridInheritance" role="tab" data-toggle="tab">Hybrid Inheritance</a></li>
</ul>
</div><hr>
<ul>
<li>The existing class is called super class or base class or parent class.</li>
<li>New class is called sub class or derived class or child class.</li>
<li>Use of inheritance is code re-usability.</li>
<li>Most importantly, we use inheritance if we want to increase features of class.</li>
</ul>
<p>For ex.: Let's say that a student has attributes like age, location, and this class has existed for a long time. After some time, we need to add more attribute like pan card to student.</p>
<p>What options do we have?<br>
Option 1 : We can modify class student<br>
Option 2 : We need to extend student class and add an attribute in that new subclass</p>
<ul>
<li><p>The first option is a violation of principles of java: 'Java classes are not open for modifications', so we should not modify an existing one. This will increase unit testing which will have to be done again for the existing class.</p></li>
<li><p>The second option is, without disturbing existing class, we add variable in another class by making subclass. So, the unit testing needs to be done for the child and not parent.</p></li>
</ul>
<hr>

<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance;
/*
* @author Kiran
*/
public class A {
    int age;
    int loc;
 }</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance;
/*
* @author Kiran
*/
public class B extends A { 
    int pancard;
}
</code></pre>
</div>
<hr>
<p>
<h4 class="breadcrumb"><b>Note:</b></h4>
<ul><li>Super class members inherits to subclass provided they are eligible by access specifiers and if they are not already present in subclass.</li></ul>
<hr>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance;
/*
* @author Kiran
*/
public class C { 
   private int a = 20;
   public int b = 30; 
   public int c = 40;
}
</code></pre>
<br>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance;
/*
* @author Kiran
*/
public class D extends C { 
     public int c = 10;
}
</code></pre>
<br>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance;
/*	
* @author Kiran
*/
public class CDTest {
  public static void main(String[] args){
    D d=new D();
      //System.out.println(d.a);
     //Error:as it not accessible;it is private,'a'is not coming to D
     // b is of C class 
    System.out.println(d.b);
     // c is of D class and the answer will be 10, not 40
    System.out.println(d.c);
  }
}
</code></pre>
</div>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     30 
     10 
    </code></pre>
<hr>
<p class="card-text"><h4 class="breadcrumb"><b>Here are some rules we need to remember:</b></h4>
<ul>
<li>We cannot assign super class to subclass.</li>
<li>We cannot extend final class.</li>
<li>We cannot extend class which has only private constructor, but if we have private constructor as well as public constructor then we can extend super to sub class. And in that case only public constructor will work.</li>
<li>Java doesn't support multiple inheritance in case of classes, but it supports it in case of interfaces.</li>
<li>Class cannot extend itself.</li>
</ul>
If we assign subclass reference to super class reference, it is called ‘dynamic dispatch’.<br><br>
Consider the scenarios given below:
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance.scenarios;
/**
* @author Java By Kiran
*/
public class A { 
  int a = 10;
  int b = 20; 
  void m1() {
    System.out.println("I am in A-m1”);
  }
  void m2() {
    System.out.println("I am in A-m2”);
  }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance.scenarios;
/**
* @author Java By Kiran
*/
public class B extends A{ 
  int b = 30;
  int c = 40; 
 void m2() {
    System.out.println("I am in B-m2");
 }
 void m3() {
    System.out.println("I am in B-m3");
 }
}
</code></pre>
</div><hr>
<h4><b class="breadcrumb">Only change this given class for all scenarios given below:</b></h4>
<pre><b><i>// Scenario 1</i></b></pre>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Inheritance.scenarios;
/**
* @author Java By Kiran
*/
public class Scenarios {
  public static void main(String[] args){
  // Scenario 1
     A a =new A();	// Super class object a is eligible to   
                        //call only A
     System.out.println(a.a); 
     System.out.println(a.b);
     //System.out.println(a.c);//Error; c does not exist in A
     a.m1();
     a.m2();
     //a.m3(); //Error m3 does not exist in class A
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     10
     20
     I am in A-m1 
     I am in A-m2
    </code></pre>
</div><br>
<pre><b><i>// Scenario 2</i></b></pre>
<p>Now change the main method with different scenarios:</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>B b = new B(); System.out.println(b.a); // a of A
System.out.println(b.b); // b of B 
System.out.println(b.c); // c of B 
b.m1();// m1 of A 
b.m2();// m2 of B 
b.m3(); // m3 of B
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     10
     30
     40	
     I am in A-m1 
     I am in B-m2 
     I am in B-m3
    </code></pre>
</div>
<p>This example assigns sub class to super class. <br>
This is allowed in java. i.e. <code>A a = new B()</code> in Scenario 3
</p><br>
<pre><b><i>// Scenario 3</i></b></pre>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
<code>1) A a =new B();
2) System.out.println(a.a);// a of A
3) System.out.println(a.b);// b of A
4) //System.out.println(a.c); //Error c of A does not exist in A 
5) a.m1();// m1 of A
6) a.m2();// m2 of B
7) //a.m3(); //Error m3 of A does not exist in A
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     10
     20
     I am in A-m1
     I am in B-m2
    </code></pre>
</div>
<p><b>Remember these Rules:</b> In this case a is eligible to call
<ul>
<li><p>At compile time, everything of A class will be called other than that everything shows error at compile time. This means that in this case line no.(4) and line no.(7) will have problems.</p></li>
<li><p>At run time, all variables and methods of class A will get called, but all those methods which are overridden by class B will get executed. Or exactly similar methods of A into B will be called (Observe Output).</p></li>
</ul>
<br>
<pre><b><i>// Scenario 4</i></b></pre>
<div>
<p><b>Try changing main method like below:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code11" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code11" class="breadcrumb pretagcodebox">
<code>A a=new A(); 
B b=new B(); 
a=b;  //This is equivalent to A a=new B(); refer 3rd Scenario
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code12" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code12" class="breadcrumb pretagcodebox">
<code>1) System.out.println(a.a); // a of A
2) System.out.println(a.b); // b of A
3) // System.out.println(a.c); //Error c of A not exist 
4) a.m1(); // m1 of A
5) a.m2(); // m2 of B
6) // a.m3(); // Error m3 of A does not exist
</code></pre>
</div>
<br>
<pre><b><i>// Scenario 5</i></b></pre>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code13" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code13" class="breadcrumb pretagcodebox">
<code>B b=new A();	// syntax error
//Try calling everything by using b
</code></pre>
</div>
<br>
<pre><b><i>// Scenario 6</i></b></pre>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code14" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code14" class="breadcrumb pretagcodebox">
<code>A a=new B(); 
B b=new B();
b=(B)a; // looks like super class assigned to subclass but  
        //it translates internally to 
B b=new B(); //It’s equivalent to 2nd scenario
</code></pre>
</div>
<hr>
<p>
<b>Following are the various types of inheritances:</b>
<ul><li>Simple/Single Inheritance</li>
<li>Multi-level Inheritance</li>
<li>Hierarchical Inheritance</li>
<li>Multiple Inheritance</li>
<li>Hybrid Inheritance</li>
</ul>
<hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="SingleInheritance">
<h2 class="breadcrumb"><a name="SingleInheritance">Simple/Single Inheritance:</a></h2>
<ul>
<li>In this, there will be only one super class and one sub class</li>
<li>Every class has a super class as Object, and the package for Object class is java.lang.Object.</li>
</ul>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/singleinheritance.webp" alt="single inheritance in java" title="Single Inheritance"></div>
<br>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code15" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code15" class="breadcrumb pretagcodebox">
<code>public class A {
   public void methodA(){
        System.out.println("Base class method");
    }
}
public class B extends A {
    public void methodB() {
        System.out.println("Child class method");
    }
public static void main(String args[]){
    B obj = new B();
    obj.methodA();  //calling super class method
    obj.methodB();  //calling local method of B
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
    Base class method
    Child class method

    </code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="MultilevelInheritance">
<h2 class="breadcrumb">Multi-level Inheritance:</h2>
<ul>
<li>When a class extends a class, which in turn extends another class, is called multi-level inheritance</li>
</ul>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/multilevelinheritance.webp" alt="multilevel inheritance in java" title="Multi-level Inheritance"></div>
<br>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code16" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code16" class="breadcrumb pretagcodebox">
<code>public class X {
    public void methodX() {
      System.out.println("Class X method");
    }
}
public class Y extends X {
     public void methodY() {
        System.out.println("Class Y method");
     }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code17" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code17" class="breadcrumb pretagcodebox">
<code>public class Z extends Y {
     public void methodZ() {
        System.out.println("Class Z method");
     } 
public static void main(String args[]) {
    Z obj = new Z();
    obj.methodX(); //calling X grand parent class method
    obj.methodY(); //calling Y parent class method
    obj.methodZ(); //calling Z class local method
  }  	
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
    Class X method
    Class Y method
    Class Z method

    </code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="MultipleInheritance">
<h2 class="breadcrumb">Multiple Inheritance:</h2>
<ul>
<li>One class has many super classes</li>
<li>This is not allowed in java</li>
<li>One needs to understand why this is not allowed, as you may be asked this question in an interview.</li>
</ul>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/multipleinheritance.webp" alt="multiple inheritance in java" title="Multiple Inheritance"></div>
<br>
<ul>
<li><p>Note 1 : Multiple Inheritances are very rarely used in software projects. Using multiple inheritances often leads to problems in the hierarchy. This results in unwanted complexity when further extending the class</p></li>
<li><p>Note 2 : Most of the new object oriented languages like Small Talk, Java, and C# do not support multiple inheritances. Multiple Inheritances is supported in C++</p></li>
<li><p>From the diagram above, if class A has m1 and class B also has m1 and they will have different implementations</p></li>
<li><p>As per inheritance concepts both methods should inherited to class C</p></li>
<li><p>If somebody creates object of class C, which m1 will get called? This is ambiguity of methods and therefore not allowed in java</p></li>
<li><p>Class C extends A, B like this syntax is not allowed in java</p></li>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="HierarchicalInheritance">
<h2 class="breadcrumb">Hierarchical Inheritance:</h2>
<p>In such kind of inheritance one class is inherited by many sub classes. In the example below, class B, C and D inherits the same class.
Class A is parent class (or base class) of B, C and D (or derived classes).
</p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/hierarchicalinheritance.webp" alt="hierarchical inheritance in java" title="Hierarchical Inheritance"></div>
<br>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code18" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code18" class="breadcrumb pretagcodebox">
<code>public class A {
  public void methodA(){
     System.out.println("method of Class A");
  }
}
public class B extends A {
  public void methodB() {
    System.out.println("method of Class B");
  }
 }
public class C extends A {
    public void methodC() {
        System.out.println("method of Class C");
    }
 }
public class D extends A {
    public void methodD() {
         System.out.println("method of Class D");
    }
 }

public class MyClass {
    public void methodB() {
        System.out.println("method of Class B");
}
     public static void main(String args[]) {
        B obj1 = new B(); 
        C obj2 = new C(); 
        D obj3 = new D(); 
        obj1.methodA(); 
        obj2.methodA(); 
        obj3.methodA();
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     method of Class A 
     method of Class A 
     method of Class A
  </code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="HybridInheritance">
<h2 class="breadcrumb">Hybrid Inheritance:</h2>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/hybridinheritance.webp" alt="hybrid inheritance in java" title="Hybrid Inheritance"></div>
<br>
<ul>
<li>Not allowed in Java</li>
<li>In simple terms, you can say that Hybrid inheritance is a combination of Single and Multiple inheritances. A typical flow diagram would look like above. A hybrid inheritance can not be achieved in the java in a same way as multiple inheritances can be!! Using interface it is allowed. Yes you heard it right. By using interfaces you can have multiple as well as hybrid inheritance in Java</li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code19" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code19" class="breadcrumb pretagcodebox">
<code>class A extends A{
}
/*This is not ok because it is like cyclic inheritance,
A inherits itself.*/
class A {

}
class B {

}
class C extends A,B {

}

/* Not ok, because multiple inheritance is not allowed. 
Here C has two parent classes. */
</code></pre>
</div>
</div>
</div>
<hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#SingleInheritance" role="tab" data-toggle="tab">Single Inheritance</a></li>
<li role="presentation"><a href="#MultilevelInheritance" role="tab" data-toggle="tab">Multi-level Inheritance</a></li>
<li role="presentation"><a href="#HierarchicalInheritance" role="tab" data-toggle="tab">Hierarchical Inheritance</a></li>
<li role="presentation"><a href="#MultipleInheritance" role="tab" data-toggle="tab">Multiple Inheritance</a></li>
<li role="presentation"><a href="#HybridInheritance" role="tab" data-toggle="tab">Hybrid Inheritance</a></li>
</ul>
</div>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="constructor-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="super-and-this-keyword-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>



</div>

</div>

<script type="application/ld+json">
{ "@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Inheritance - Java",
 "alternativeHeadline": "What is inheritance in java?",
 "image": "https://www.jbktutorials.com/images/java/singleinheritance.webp",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java inheritance", 
 "keywords": "java inheritance, inheritance, inheritance in java, single inheritance, multi level inheritance, hierarchical inheritance, multiple inheritance, hierarchical inheritance", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/inheritance-in-java.php",
   "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-21",
 "dateCreated": "2019-11-21",
 "dateModified": "2019-11-21",
 "description": "Inheritance is a process of writing a new class by using existing class functionality.",
 "articleBody": "The process by which one class acquires the properties(instance variables) and functionalities of another class is called inheritance’. This happens when one class adopts the non-private properties and methods of one class."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
