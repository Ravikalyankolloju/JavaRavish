<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Static Keyword in Java</title>
<meta name="description" content="Static in Java is a keyword that indicates that variables or functions are shared between all the instances of a particular class since it belongs to type, not object.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Static Keyword in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/statickeyword-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Static in Java is a keyword that indicates that variables or functions are shared between all the instances of a particular class since it belongs to type, not object.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Static Keyword in Java">
<meta name="twitter:description" content="Static in Java is a keyword that indicates that variables or functions are shared between all the instances of a particular class since it belongs to type, not object.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/statickeyword-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 

<div class="container-fluid">

<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="statickeyword-in-java.php">
<span itemprop="name">What is Static Keyword?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Static Keyword</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>


<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Static Keyword in Java</h1>
<div class="card-body">
<div id="Div1">
<p class="card-text"><h2 class="breadcrumb">Things to remember:</h2>
<ul>
<li>Static is a keyword used for memory management.</li>
<li>Static means single copy storage for variable or method.</li>
<li>Static keyword can be applied to variables, methods, inner class and blocks.</li>
<li>Static members belongs to class rather than instance of class.</li>
</ul>
</p><hr>
<p class="card-text">Static in java is a keyword that indicates that the variables or functions are shared between all the instances of a particular class since it belongs to the type, not the object. It is used when the programmer wants to share the same variable or method of a class.</p>
<hr>
<div class="tab" role="tabpanel">

<div class="text-center">
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#StaticVariable" role="tab" data-toggle="tab">Static Variable</a></li>
<li role="presentation"><a href="#StaticMethod" role="tab" data-toggle="tab">Static Method</a></li>
<li role="presentation"><a href="#StaticBlock" role="tab" data-toggle="tab">Static Block</a></li>
<li role="presentation"><a href="#StaticInnerClass" role="tab" data-toggle="tab">Static Inner Class</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="StaticVariable">
<div class="card-text"><h2 class="breadcrumb">Static Variable</h2>
The variable preceded by ‘static’ keyword is ‘static variable’<br>
<pre><code>static int a=10;   // variable
static void m1(){   // method 
  }</code></pre><hr>
Static variable is used to refer common property of all objects of class.<br><br>
<ul>
<li><h3><b class="breadcrumb">How to access static variable?</b></h3>
There are two ways to access static variable:
<ol>
<li><p>Static variable can be accessed by Class name<br>
A. a ; [A is class name]<br>
Where A is the class name and ‘a’ is a static variable declared in that class
</p></li>
<li><p>Static variable can be accessed by object<br>
I have a class name called ‘Sample’. Now, we can create the object of the Sample class<br>
<pre><code>Sample h=new Sample ();
System.out.println(h.a); //’a’ is static variable inside ‘sample’ class
                    </code></pre></p></li>
</ol>
</p>
</li>
<li><h3><b class="breadcrumb">How can I access static variable in two ways?</b></h3></li>
We will see in the following program:<br><br>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<div>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Static;
    /*
    * @author Java By Kiran
    */
    public class Staticvar 
    { 
        static int i=10;
        public static void main(String[] args)
        { 
           Staticvar s =new Staticvar(); 
           System.out.println(s.i); //Not Recommended
           System.out.println(Staticvar.i); //Recommended
        }
    } </code></pre>
</div>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     10 
     10 
    </code></pre>
<ul>
<li><p>In the above program, we printed the value of variable by using object name and by using class name</p></li>
<li><p>Static variable gets loaded into the memory at the time of class loading</p></li>
<li><p>So, we can access static variable by reference variables as well.</p></li>
<li><p>In the above program, if we create only the reference of class like <br>
<pre><code>Staticvar s1=null;
System.out.println(s1.i); // possible
System.out.println(Staticvar.i); //possible</code></pre>
The above example compiles and executes successfully because the static variable get loaded into the memory at the time of class loading.
</p></li>
<li><p>Static variable and method doesn't belong to Object/Instance of the class since static variables are shared across all the instances of Object</p></li>
</ul>
</ul><hr>
<div>
<p><b>Example 1</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
    <code>package com.jbk;
/*
* @author Java By Kiran
*/
public class StaticVar_Demo{ 
  int a =10;
  static int b =10;
public static void main(String[]args){ 
    StaticVar_Demo st= new StaticVar_Demo();     
    System.out.println(st.a); 
    System.out.println(st.b);
    StaticVar_Demo st1 = new StaticVar_Demo(); 
    int x = st1.a++;
    System.out.println(x); 
    int y = st1.b++; 
    System.out.println(y);
    StaticVar_Demo st2 = new StaticVar_Demo(); 
    int p = st2.a++;
    System.out.println(p); 
    int q = st2.b++; 
    System.out.println(q);
    StaticVar_Demo st3 = new StaticVar_Demo(); 
    int c = st3.a++;
    System.out.println(c); 
    int d = st3.b++; 
    System.out.println(d);
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     10
     10
     10
     10
     10
     11
     10
     12
</code></pre>
</div><hr>
<div>
<p><b>Example 2</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
    <code>package com.javabykiran.Static;
/*
* @author Java By Kiran
*/
public class Staticvar { 
    static int i=10;
    int b=20; 
  void m1(){
    System.out.println(i);
   }
    static void m2(){ 
        System.out.println(i);
   }
   public static void main(String[] args) { 
       Staticvar s =new Staticvar();
       s.m1();
       Staticvar s1=new Staticvar();
       s1.m2();
    }
 }
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     10
     10
</code></pre>
</div>
<ul>
<li><p>Local variables cannot be declared as static else the compiler displays a modifier error [at compile time]</p></li>
<li><p>We cannot call non-static members from static members because static variables get stored into memory before object creation and non-static member get stored into memory after object creation</p></li>
<li><p>So, when we access a non-static member through a static member, it leads to a compile time error as they are not present in the memory.</p></li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
    <code>package com.javabykiran.Static;
/*
* @author Java By Kiran
*/
public class Staticvar {
    static int i = 10;  // static variable 
    int b = 20;         // non static variable 
  void display() {      // non static method
     static int a = 50;  //here a compile time error shows
     System.out.println(i);
  }
  static void show() {      // static method 
    System.out.println(i); // OK
    System.out.println(b);
    //if I want access non static variable in static method,
    //compiler throw error
 }
public static void main(String[] args) { 
    Staticvar s1 = new Staticvar(); 
 
    s1.show();
    s1.display();
  }
}
</code></pre>
</div></div>
</div>
<div role="tabpanel" class="tab-pane fade" id="StaticMethod">
<div class="card-text"><h2 class="breadcrumb">Static Method</h2>
<ul>
<li>If you apply static keyword with any method, it will be treated as static method</li>
<li>Static method belongs to a class rather than object of a class</li>
<li>Static method can be invoked without creating instance of the class</li>
<li>Static method can access static data member and can change its value</li>
<li>Static methods also load into memory before object creation</li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Static;
/*
* @author Java By Kiran
*/
 public class Staticvar {
    static int i=10; 
    int b=20;	 
   void display(){		
     System.out.println(i);
   }
   static void show(){  //static method 
    System.out.println(i); 
    System.out.println(b);//if we want access non static
    //variable in static method, compiler throw error
   }
 public static void main(String[] args){
    Staticvar s1=new Staticvar(); 
    s1.show();
    s1.display();
  }
}
</code></pre>
</p></div>
<ul type="disc">
<li><p>Static method can be accessed by nullable reference like <br>
<pre><code>Staticvar s1=null;
s1.show();
</code></pre></p>
</li>
<li><p>By using non-static member we can access static members, but by using static member we cannot access non-static members</p></li>
</ul>
<div>
<p><b>Example</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Static;
/*
* @author Java By Kiran
*/
 public class StaticMethod {
    static int i=10; //static variable 
    int b=20;       //global variable 
void display() 
{  
  System.out.println("This is display method");
}
static void show() { //static method 
  System.out.println("Hello,This is JAVA BY KIRAN classes");
  }
public static void main(String[] args) 
 { 
  StaticMethod s =new StaticMethod(); 
    s.display();
    s.show();
    StaticMethod s1 = null; 
    s1.show();
 } 
}  </code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     This is display method
     Hello, This is JAVA BY KIRAN classes
     Hello, This is JAVA BY KIRAN classes
   </code></pre>
</div></div>
</div>
<div role="tabpanel" class="tab-pane fade" id="StaticBlock">
<div class="card-text"><h2 class="breadcrumb">Static Block</h2>
<ul>
<li>Java's static block is the group of statements that gets executed when the class is loaded into memory by Java ClassLoader.</li>
<li>It is used to initialize static variables of the class. Mostly it's used to create static resources when the class is loaded</li>
<li>We can't access non-static variables in static block</li>
<li>We can have multiple static blocks in a class, although it doesn't make much sense</li>
<li>Static block code is executed only once when the class is loaded into memory</li>
<li>Static block always get executed first because they get stored into the memory at the time of class loading or before object creation</li>
</ul>
<div>
<p><b>Example</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
   <code>package Static;
public class StaticBolckLab2 { 
   StaticBolckLab2()
   {
    System.out.println("This is constructor");
   }
   {
    System.out.println("This is Non static Block");
   }
   static
   {
    System.out.println("This is static Block");
   }
public static void main(String[] args) { 
   StaticBolckLab2 s= new StaticBolckLab2(); 
   StaticBolckLab2 s1=new StaticBolckLab2();
 }  </code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     This is static Block
     This is Non staticBlock
     This is constructor
     This is Non static Block
     This is constructor
 </code></pre>
</div>
<ul>
<li>In the above example, we can prove that static members have one copy storage</li>
<li>A static block cannot access non-static variables and methods</li>
</ul>
<div>
<p><b>Example</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
   <code>package com.javabykiran.Static;
/*
* @author Java By Kiran
*/
public class StaticBlock {
    static int i=10;  //static variable 
    int b=20;	      //global variable
    void display(){	
        System.out.println("This is display method");
    }
    static void show(){  //static method       
    System.out.println("JAVA BY KIRAN classes Pune");
    //System.out.println(b);   //if we want access variable ‘b’,non-static method is needed
    //if there is a variable in the static method, JVM throws a compile time error
   }
    {
        display();
    }
    static{
        display();   //this is a compile time error, we cannot call non-static methods
		System.out.println(i); // no error
        System.out.println(" "+b);  //this compile time error shows we cannot access non-static //variable in static block
      }
public static void main(String[] args) { 
    StaticBlock s =new StaticBlock(); 
    s.display();
    s.show();
    StaticBlock s1 = null; 
    s1.show();
   } 
 }
</code></pre>
</div>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="StaticInnerClass">
<div class="card-text"><h2 class="breadcrumb">Static Inner Class</h2>
<ul>
<li>Outer class cannot be declared as static</li>
<li>But inner classes can be used as static</li>
</ul>
</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
    <code> package com.javabykiran.Static;
/*
* @author Java By Kiran
*/
public class StaticInnerclass { 
   static class A {  //start of static inner class
   static int a=10; 
   int b=20;
   void display(){ 
     System.out.println("This is local method");
   }
   static void show(){ 
       int c=63;
       System.out.println("This is static method");
   }
}
public static void main(String[] args){
     A a =new A(); 
     System.out.println(a.b); 
     System.out.println(a.a); 
     a.display();
     a.show();
  } 
} </code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     20      
     10       
     This is local method 
     This is static method
  </code></pre>
</div>
<ul><li>Inner class can access their local variables and methods</li></ul>
<hr>
<div>
<p><b>Example</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
   <code>package com.javabykiran.Static;
/*
* @author Java By Kiran
*/
class StaticClassDemo { 
    static class JBKway{  //start of inner class 
     static int a=10; 
     int b=20;
     void display(){
        System.out.println("This is local method");
    }
    static void show(){ 
        int c=63;
        System.out.println("This is static method");
        System.out.println("C="+c);
    }	
}
public static void main(String[]args) {
   JBKway a1 =null;
   //System.out.println(a1.b);//runtime error
   System.out.println(a1.a);
   // a1.display(); //runtime error 
      a1.show();
  System.out.println(a1.a);
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     10
     This is static method 
     C=63
     10
  </code></pre>
</div>
<p class="card-text"><h3 class="breadcrumb"><b>Note:</b></h3>
<ul>
<li>Local variable cannot be static</li>
<li>Constructor cannot be static</li>
<li>Outer class cannot be static</li>
</ul>
</div>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#StaticVariable" role="tab" data-toggle="tab">Static Variable</a></li>
<li role="presentation"><a href="#StaticMethod" role="tab" data-toggle="tab">Static Method</a></li>
<li role="presentation"><a href="#StaticBlock" role="tab" data-toggle="tab">Static Block</a></li>
<li role="presentation"><a href="#StaticInnerClass" role="tab" data-toggle="tab">Static Inner Class</a></li>
</ul>
</div>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="access-modifiers-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="final-keyword-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{ "@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Static Keyword - Java",
 "alternativeHeadline": "What is static keyword in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java static keyword", 
 "keywords": "static keyword, static keyword in java, java static keyword, keyword static, static", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/statickeyword-in-java.php",
   "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-19",
 "dateCreated": "2019-11-19",
 "dateModified": "2019-11-19",
 "description": "Static is a keyword used for memory management.",
 "articleBody": "Static in java is a keyword that indicates that the variables or functions are shared between all the instances of a particular class since it belongs to the type, not the object."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
