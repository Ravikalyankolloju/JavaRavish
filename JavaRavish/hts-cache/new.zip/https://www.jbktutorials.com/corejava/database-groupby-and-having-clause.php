<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Database Group by & Having Clause</title>
<meta name="description" content="The Group by clause is used to divide table into multiple groups based on specified columns. The having clause is used to specify the condition placed on groups.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Database Group by & Having Clause" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/database-groupby-and-having-clause.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="The Group by clause is used to divide table into multiple groups based on specified columns. The having clause is used to specify the condition placed on groups.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Database Group by & Having Clause">
<meta name="twitter:description" content="The Group by clause is used to divide table into multiple groups based on specified columns. The having clause is used to specify the condition placed on groups.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/database-groupby-and-having-clause.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="introduction-to-java.php">
<span itemprop="name">Core Java</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Database - Group by & Having Clause</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Database Group by & Having Clause</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<p><a href="database-in-java.php" class="btn btn-outline-danger">&larr; Go back to Database Chapter</a></p>
<hr>
<div>
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#GroupByandHavingClause" role="tab" data-toggle="tab">Group By & Having Clause</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="GroupByandHavingClause">
<div>
<h2 class="breadcrumb">Group By and Having Clause</h2>
<h3>Group By</h3>
<p>The Group by clause is used to divide the table into multiple groups based on the specified columns.</p>
<h3>Having</h3>
<p>The having clause is used to specify the condition placed on the groups.</p>
<p><b>Example:</b></p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img1.webp" alt="groupby and having class example in java" title="Student Table Data"></div><br>
<div name="QuestionsAndAnswers">
<p><b>Question 1:</b> <i>Display the total fee collected.</i><br>
<b>Answer:</b> <code>Select sum (fee paid) from students;</code>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img2.webp" alt="groupby and having class example in java" title="Answer for Question 1"></div><br>
</p>
<p><b>Question 2:</b> <i>Display the total fee collected from the Madiwala branch.</i><br>
<b>Answer:</b> <code>Select sum (fee paid) from students where branch = 'madiwala'</code>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img3.webp" alt="groupby and having class example in java" title="Answer for Question 2"></div><br>
</p>
<p><b>Question 3:</b> <i>Display the branch wise collection in the following formats:</i><br>
<table class="table-borderless" style="width:50%;">
<tr><td>KarveNagar</td> <td>20000</td></tr> <tr><td>Madiwala</td> <td>28000</td></tr> <tr><td>Macerthali</td> <td>12000</td></tr>
</table>
<b>Answer:</b> <code>Select sum (fee paid) from student group by branch;</code>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img4.webp" alt="groupby and having class example in java" title="Answer for Question 3"></div><br>
</p>
<p><b>Question 4:</b> <i>Select branch, sum (fee paid) from student group by branch.</i><br>
<b>Answer:</b>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img5.webp" alt="groupby and having class example in java" title="Answer for Question 4"></div><br>
</p>
<p><b>Question 5:</b> <i>Select branch as "Branch Name", sum (fee paid) "Total collection" from student group by branch.</i><br>
<b>Answer:</b>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img6.webp" alt="groupby and having class example in java" title="Answer for Question 5"></div><br>
</p>
<p><b>Question 6:</b> <i>Display the fee collected from KarveNagar and Madiwala branch.</i><br>
<b>Answer:</b><br> <code>Select sum ( Fee paid) from students where branch in ('madiwala', 'KarveNagar'); <br><b>(or)</b> <br>
Select branch as "Branch Name", sum (fee paid) "Total collection" from student group by branch having branch in ('madiwala', 'KarveNagar'); </code>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img7.webp" alt="groupby and having class example in java" title="Answer for Question 6"></div><br>
</p>
<p><b>Question 7:</b> <i>Display the city wise fee balances in the following format:</i> <br>
<table class="table-borderless" style="width:50%;">
<tr><th>City Name</th> <th>Total Balance</th></tr>
<tr><td>KarveNagar</td> <td>20000</td></tr>
<tr><td>Madiwala</td> <td>28000</td></tr>
<tr><td>Macerthali</td> <td>12000</td></tr>
</table>
<b>Answer:</b><br> <code>Select city as "City Name ", Sum (fee paid) as "Total Balance" from student group by city;</code>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img8.webp" alt="groupby and having class example in java" title="Answer for Question 7"></div><br>
</p>
<p><b>Question 8:</b> <i>Display city as "City Name" sum (fee balance) as "Total Balance " from student group by city.</i> <br>
<b>Answer:</b>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img9.webp" alt="groupby and having class example in java" title="Answer for Question 8"></div><br>
</p>
</div>
</div>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#GroupByandHavingClause" role="tab" data-toggle="tab">Group By & Having Clause</a></li>
</ul>
</div><hr>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item disabled">
<a class="page-link btn-outline-primary" href="jdbc-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Database Group by and Having Clause",
 "alternativeHeadline": "What are group by and having clauses in database?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "database group by and having clause", 
 "keywords": "database group by and having clause, group by and having clause, group by clause, having clause, clause in sql", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/database-groupby-and-having-clause.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-12-12",
 "dateCreated": "2019-12-12",
 "dateModified": "2019-12-12",
 "description": "The Group by clause is a SQL command that is used to group rows that have the same values.",
 "articleBody": "The Group by clause is used to divide the table into multiple groups based on the specified columns. The having clause is used to specify the condition placed on the groups."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
