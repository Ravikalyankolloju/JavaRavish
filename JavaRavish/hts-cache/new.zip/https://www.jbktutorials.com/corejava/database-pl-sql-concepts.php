<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Database PL/SQL</title>
<meta name="description" content="PL/SQL is a programming long with SQL which allows you to write sets of statements as one block called as a PL / SQL block.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Database PL/SQL" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/database-pl-sql-concepts.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="PL/SQL is a programming long with SQL which allows you to write sets of statements as one block called as a PL / SQL block.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Database PL/SQL">
<meta name="twitter:description" content="PL/SQL is a programming long with SQL which allows you to write sets of statements as one block called as a PL / SQL block.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/database-pl-sql-concepts.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="introduction-to-java.php">
<span itemprop="name">Core Java</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Database PL/SQL</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Database PL/SQL Concepts</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<p><a href="database-in-java.php" class="btn btn-outline-danger">&larr; Go back to Database Chapter</a></p>
<hr>
<div>
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#PLSQL" role="tab" data-toggle="tab">PL/SQL</a></li>
<li role="presentation"><a href="#ConditionalStatements" role="tab" data-toggle="tab">Conditional Statements</a></li>
<li role="presentation"><a href="#LoopingStatements" role="tab" data-toggle="tab">Looping Statements</a></li>
<li role="presentation"><a href="#StoredProcedures" role="tab" data-toggle="tab">Stored Procedures</a></li>
<li role="presentation"><a href="#StoredProcedureAdvantages" role="tab" data-toggle="tab">Stored Procedure Advantages</a></li>
<li role="presentation"><a href="#Parameters" role="tab" data-toggle="tab">Parameters</a></li>
<li role="presentation"><a href="#Trigger" role="tab" data-toggle="tab">Trigger</a></li>
<li role="presentation"><a href="#TransactionalStatements" role="tab" data-toggle="tab">Transactional Statements</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="PLSQL">
<div>
<h2 class="breadcrumb">PL/SQL</h2>
<p>PL / SQL is a programming long with SQL which allows you to write sets of statements as one block called as a PL / SQL block.</p>
<p>PL / SQL blocks contain the following :
<ol>
<li><p>Variables</p></li>
<li><p>Constants</p></li>
<li><p>Conditional stats</p></li>
<li><p>Looping stats</p></li>
<li><p>SQL states</p></li>
<li><p>All SQL operators & functions etc</p></li>
</ol>
</p>
<p><b>Syntax:</b> <br>
<ul><code>Declare <br>
Variable declaration Constant declaration<br>
------ <br>
Begin <br>
------ <br>
End;
</code></ul></p>
<div>
<p><b>Q.</b> <i>Write a PL / SQL block for the following requirements:</i></p>
<ol>
<li>Declare 3 variables with the names a,b and c</li>
<li>Assign the same values to a and b</li>
<li>Find the sum of a and b starting in variable c</li>
<li>Display the sum Set server output on;</li>
</ol>
<p><b>Answer.</b></p>
<ul>
<b>Declare</b>
<ol type="a">
<li>Number (4);</li> <li>Number (4);</li> <li>Number (6);</li>
</ol>
<b>Begin</b>
<ul>
<li>a: = 10;</li> <li>b: = 20;</li> <li>c: = a+b; dbms_output_line (c);</li>
</ul>
<b>end;</b>
<p>It is used to alter end and then enter this is for execution SQD Set serveroutput on;
You have to write this before PL / SQL block (before declare)</p>
</ul>
</div>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="ConditionalStatements">
<div>
<h2 class="breadcrumb">Conditional Statements</h2>
<p><b>if Syntax</b></p>
<code>If (condition) then S1; <br>
S2;<br>
End if;
</code><br>
or<br>
<code>
If (condition) then <br>
S1; <br>
else <br>
S2 <br>
end if <br>
S3 <br>
End if;
</code><br>
or<br>
<code>
if (condition) then <br>
S1; <br>
else if (condition) <br>
S2: <br>
else <br>
S3 <br>
End if;
</code><br><br>
<p><b>Example:</b></p>
<code>declare <br>
a number (4); <br>
b number (4); <br>
begin <br>
a:=10; b:=20; <br>
if (a>b) then dbms_output.put_line (a); <br>
else <br>
dbms output.put_line (b); <br>
end if; <br>
</code><br>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="LoopingStatements">
<div>
<h2 class="breadcrumb">Looping Statements</h2>
<ul>
<li><p><b>Simple Loop:</b></p>
<ul><code>Loop <br>
S1; <br>
S2; <br>
Exit when condition End loop;
</code></ul></li><br>
<li><p><b>While loop</b></p>
<ul><code>while (condition) loop <br>
S1; <br>
S2; <br>
End loop;
</code></ul><br>
</li><br>
<li><p><b>For Loop</b></p>
<ul><b>Syntax:</b><br>
<code>For value in (Reverse) Start Value end value Loop<br>
----<br>
----<br>
End loop;
</code></ul>
</li><br>
<p><b>Q.</b> <i>Display the five divisible from 1 to 100</i></p>
<p><b>Answer.</b></p>
<ul>
<li>
<code>
declare <br>
i number (4);<br>
begin <br>
I:=1; <br>
loop <br>
if (i mod 5=0) then dbms_output. Put_line (i); end if; <br>
i:=i+1 <br>
exit when i=100; end loop; <br>
end;
</code>
</li><br>
<li>
<code>
declare <br>
i number (4); <br>
begin <br>
i : = 1; <br>
while (i<=100) loop <br>
if (i mod 5=0) then dbms_output.put_line(i); end if;<br>
end loop; end;
</code>
</li><br>
<li>
<code>
Declare <br>
i number (4); <br>
begin <br>
for i in 1….100 loop <br>
dbms_output.put_line(i); <br>
end loop; end;
</code>
</li>
</ul>
</ul>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="StoredProcedures">
<div>
<h2 class="breadcrumb">Stored Procedures</h2>
<p>The stored procedure is PL/SQL block name which takes some parameter and returns some parameters.</p>
<p><b>Syntax:</b> <br>
<ul><code>Create or replace procedure pro_name (var_name(in/out/inout) data type, …….) <br>
as <br>
------------- <br>
------------- <br>
Begin <br>
------------- <br>
end;
</code></ul></p><br>
<div name="QuestionsAndAnswers">
<div>
<p><b>Q. 1)</b> <i>Write a stored procedure with the following requirements:<br>
a. It has to take two parameters, m and n<br>
b. Display the number from n to m
</i></p>
<p><b>Ans.</b></p>
<ul>
<code>
Create or replace procedure P1 (m number in number) as <br>
i number (4); <br>
begin <br>
for i in reverse m….n loop dbms_output.put_line(i); <br>
end loop; <br>
end; <br><br>
Call P1 (10, 25);
</code>
<p>(This is used for changing the values without changing the complete block)</p>
</ul>
</div><br>
<div>
<p><b>Q. 2)</b> <i>Write a stored procedure with the following requirements:<br>
<div class="table-responsive">
<table class="table table-bordered">
Considering the following table:
<tr><th>ID</th> <th>A</th> <th>B</th> <th>C</th> <th>D</th> </tr>
<tr><td>1.</td> <td>10</td> <td>20</td> <td>NULL</td> <td>NULL</td> </tr>
<tr><td>2.</td> <td>20</td> <td>40</td> <td>NULL</td> <td>NULL</td> </tr>
<tr><td>3.</td> <td>0</td> <td>0</td> <td>NULL</td> <td>NULL</td> </tr>
<tr><td>4.</td> <td>-</td> <td>5</td> <td>NULL</td> <td>NULL</td> </tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> </tr>
</table></div>
</i></p>
<ol type="a">
<li>The procedure has to take ID as parameter and has to fetch a and b values of the given ID</li>
<li>It has to find do addition and sub of a and b</li>
<li>Results have to be updated with the hello table</li>
<li>If the sum is recorded, then delete the record</li>
</ol><br>
<p><b>Ans.</b></p>
<ul>
<code>
Create or replace procedure P2 (id, number) as<br>
a1 number (4); <br>
b1 number (4); <br>
c1 number (4); <br>
d1 number (4); <br>
begin <br>
select a,b into a1, b1 from hello where ID = x;<br>
C1:=a1+b1 D1:=a1-b1; <br>
If (c1=0) then <br>
delete from hello where id=x; <br>
else <br>
update hello set c=c1, d=d1 where id=x;<br>
end if;<br>
end; <br>
call p2(1);
</code>
</ul>
</div>
</div>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="StoredProcedureAdvantages">
<div>
<h2 class="breadcrumb">Advantages of stored procedure</h2>
<p>With Stored Procedure</p>
<ul>
<ul>= 5 ms + 0 ms + 5000 ms + 5 ms</ul>
<ul>= 5010 ms</ul>
</ul>
<ul>
<li><p>When you submit your SQL stat to SQL engine, it will be compiled and executed when
different users are submitting same query repeatedly. The query will be compiled every time which is unnecessary.</p></li>
<li><p>When one user is submitting a set of queries, then all queries will be compiled every time. <br>
This will increase the request processing time
</p></li>
<li><p>If you write a stored procedure with a set of SQL then you can reduce the request processing time because stored procedure and SQL stat used in the stored procedure will be compiled only once and will be executed every time directly.</p></li>
</ul><br>
<div>
<p><b>Q.</b> <i>Write the stored procedure with the following requirements:</i></p>
<p>Considering the following student table</p>
<div class="table-responsive">
<table class="table table-bordered">
<tr><th>Student ID</th> <th>Student Name</th> <th>M1</th> <th>M2</th> <th>M3</th> <th>M4</th> <th>Total</th> <th>Average</th> <th>Status</th> </tr>
<tr><td>101</td> <td>A</td> <td>50</td> <td>80</td> <td>70</td> <td>80</td> <td>Null</td> <td>Null</td> <td>Null</td> </tr>
</table></div><br>
<p>The procedure has to take student ID as parameter and do the following tasks:</p>
<ol type="a">
<li>Collects marks m1, m2, m3 and m4</li>
<li>Find the total and average</li>
<li>Find the status depending on the average</li>
<li>Update the results table depending on the status</li>
<li>Update the student table total, average, fails ID</li>
</ol><br>
<p><b>Ans.</b></p>
<ul>
<li><p><b>Create the table called students</b></p>
<code>Create table students (<br>
Student ID number (4), Primary key, student name char 912) m1 number (2), m2 number (2), m3 number (2), m4 number (2), <br>
Total number (3),<br>
Average number (3),<br>
Status char (10));
</code></li><br>
<li><p>Insert sample records</p>
<ul>
<li><code>Insert into students (SID, name, m1, m2, m3, m4) values (101, 'A', 90,70,80,90);</code></li>
<li><code>Insert into students (SID, name, m1, m2, m3, m4) values (102,'B',10,30,20,50);</code></li>
<li><code>Insert into students (SID, name, m1, m2, m3, m4) values (103, 'c', 199,90, 90,70);</code></li>
</ul>
</li><br>
<li><p>Create the table called results</p>
<code>Create table results (passed a number (2), fail number (2));</code>
</li><br>
<li><p>Insert one sample record</p>
<code>Insert into results values (0,0);</code>
</li><br>
<li>
<code>
Create a replace procedure P3 (ID number) as <br>
mm1 number (2); <br>
mm2 number (2); <br>
mm3 number (2); <br>
mm4 number (2); <br>
total number (2) <br>
average number (2);<br>
Stat char (10) <br>
X number (2); <br>
Begin<br>
Select m1, m2, m3, m4 into mm1, mm2, mm3, mm4, from students <br>
Where SID = ID;<br>
Total : = mm1 + mm2 + mm3 + mm4; <br>
Average : = Total /4; <br>
If (avg<50) then Stat:="passed"; <br>
End if; <br>
Update students select total =101, average = avg status = stat <br>
Where SID = ID;<br>
if (stat='passed') then <br>
select passed into x from results; <br>
x=x+1; <br>
update results set passed = x; <br>
else <br>
select failed into x from results; <br>
x=x+1; <br>
update results set failed = x; <br>
end if; <br>
end; <br>
Call P3 (101); <br>
Call P3 (102); <br>
Call P3 (103);
</code>
</li><br>
</ul>
</div>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Parameters">
<div>
<h2 class="breadcrumb">Parameters</h2>
<p>Types of Parameters:</p>
<ul>
<li><p>In parameters</p></li>
<li><p>Out parameters</p></li>
<li><p>Inout parameters</p></li>
</ul>
<h3>In Parameters:</h3>
<p>In parameters carry the data from the caller of the procedure to the procedure.
Create procedure P1 (a in num, b number) as By default all the parameters are in parameter.</p><br>
<h3>Out Parameter:</h3>
<p>Out parameter carries the data from a procedure to the caller.</p>
<p>Example:<br>
<code>Create procedure P1 (a in number, b number, c out number, d out number);</code></p><br>
<h3>Inout Parameter:</h3>
<p>Inout parameter is used to carry the data from caller to procedure and from procedure to caller.</p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Trigger">
<div>
<h2 class="breadcrumb">Trigger</h2>
<ul>
<li><p>Trigger is a PL / SQL block within same name</p></li>
<li><p>Trigger will be called automatically whenever you do insert, update or delete operations on the table</p></li>
</ul>
<p><b>Syntax:</b> <br>
<ul><code>Create or replace trigger name
[after / before] <br>
[insert / update / delete]<br>
On table_name <br>
[for each row] <br>
declare <br>
-------- <br>
Variable declarations <br>
-------- <br>
Begin <br>
End;
</code></ul></p><br>
<p><b>Write a trigger with following requirements:</b></p>
<p>1) Consider the following tables:</p>
<div class="table-responsive">
<table class="table table-bordered">
Students
<tr><th>Student ID</th> <th>Student Name</th> <th>Email</th> <th>Phone</th> </tr>
<tr><td>101</td> <td>A</td> <td>&nbsp;</td> <td>1111111111</td> </tr>
</table></div><br>
<div class="table-responsive">
<table class="table table-bordered">
student_backup
<tr><th>Student ID</th> <th>Student Name</th> <th>Email</th> <th>Phone</th> <th>Phone</th> <th>Phone</th> </tr>
<tr><td>101</td> <td>A</td> <td>&nbsp;</td> <td>1111</td> <td>Update</td> <td>8 feb</td> </tr>
<tr><td>102</td> <td>A</td> <td>&nbsp;</td> <td>1234</td> <td>Update</td> <td>8 feb</td> </tr>
<tr><td>103</td> <td>A</td> <td>&nbsp;</td> <td>1234</td> <td>Update</td> <td>8 feb</td> </tr>
</table></div><br>
<p>Old is an object representing 1 row and it is only for update and delete open <br>
New used for insert open</p>
<p>2) Whenever update or delete operation is issued on ONLYFORJAVA student table, then the trigger has to be invoked automatically and has to move the existing records into the ONLYFORJAVA student_backup table.</p>
<p><b>Ans.</b></p>
<code>
Create ONLYFORJAVA student table and insert for the record and then ONLYFORJAVA student_backup table and insert six records
create or replace trigger <br>
before update or delete <br>
on ONLYFORJAVAstudents <br>
declare <br>
ID number (3); <br>
Sn Char (10); <br>
Ph number (7); <br>
Op char (10); <br>
Opd char (10); <br>
begin<br>
id : = :old.sid; <br>
sn : = old.sname; <br>
em : = old.email; <br>
ph : = old.phone; <br>
if (updating) then op : ='update';<br>
end if; <br>
if (deleting) then op : = 'delete'; <br>
end if; <br>
opd : = sysdate;<br>
insert into ONLYFORJAVA students_backup <br>
Values (ID, Student name, email, phone, OP, OPD); <br>
End;
</code>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="TransactionalStatements">
<div>
<h2 class="breadcrumb">Transactional Statements</h2>
<p>There are three transactional statements:</p>
<ul>
<li><p>Commitment</p></li>
<li><p>Rollback</p></li>
<li><p>Save point</p></li>
</ul>
<p><b>Definitions:</b></p>
<p>The transaction is the process of performing a set of database operations as one unit
When all the database operations in this unit are successful. Then we make the operation permanent by issuing commit
</p>
<p>When any one database operation unit fails, then we have to cancel the operation by issuing rollback.</p>
<code>
SQL > S1 <br>
SQL > S2 <br>
SQL > S3<br>
SQL > Commit; (roll back;)<br>
SQL > Select<br>
SQL > Savepoint SP1;<br>
SQL > S1 <br>
SWL > S2 <br>
SQL > S3 <br>
SQL > Select <br>
SQL > Commit: (Rollback):<br>
SQL > Savepoint SP1; (Rollback SP1);<br>
SQL > Select <br>
SQL > Savepoint SP2; (rollback SP2)<br>
</code>
</div><br>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#PLSQL" role="tab" data-toggle="tab">PL/SQL</a></li>
<li role="presentation"><a href="#ConditionalStatements" role="tab" data-toggle="tab">Conditional Statements</a></li>
<li role="presentation"><a href="#LoopingStatements" role="tab" data-toggle="tab">Looping Statements</a></li>
<li role="presentation"><a href="#StoredProcedures" role="tab" data-toggle="tab">Stored Procedures</a></li>
<li role="presentation"><a href="#StoredProcedureAdvantages" role="tab" data-toggle="tab">Stored Procedure Advantages</a></li>
<li role="presentation"><a href="#Parameters" role="tab" data-toggle="tab">Parameters</a></li>
<li role="presentation"><a href="#Trigger" role="tab" data-toggle="tab">Trigger</a></li>
<li role="presentation"><a href="#TransactionalStatements" role="tab" data-toggle="tab">Transactional Statements</a></li>
</ul>
</div><hr>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="jdbc-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Database PL/SQL - Java",
 "alternativeHeadline": "What is plsql in database?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  }, 
 "genre": "java database pl/sql", 
 "keywords": "java database pl/sql, database pl/sql, pl/sql, stored procedures, paramters, triggers, transactional statements, conditional statements, looping statements", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/database-in-java.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-12-12",
 "dateCreated": "2019-12-12",
 "dateModified": "2019-12-12",
 "description": "PL/SQL is a combination of SQL along with the procedural features of programming languages.",
 "articleBody": "PL/SQL is a programming long with SQL which allows you to write sets of statements as one block called as a PL/SQL block."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
