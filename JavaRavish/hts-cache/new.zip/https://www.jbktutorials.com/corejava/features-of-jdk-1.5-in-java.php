<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Java Development Kit - jdk1.5</title>
<meta name="description" content="jdk 1.5 - The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Java Development Kit - jdk1.5" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/features-of-jdk-1.5-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="jdk 1.5 - The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Java Development Kit - jdk1.5">
<meta name="twitter:description" content="jdk 1.5 - The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/features-of-jdk-1.5-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="features-of-jdk-1.5-in-java.php">
<span itemprop="name">What are features of jdk1.5?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Features and Enhancement in jdk1.5</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Features and Enhancement in jdk1.5</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<div>
<p>There are a few features and enhancements that are added in jdk1.5. These are listed below:
<ul>
<li>Java Language Features</li>
<li>Performance Enhancement</li>
<li>Virtual Machine</li>
<li>Base Libraries</li>
<li>User Interface</li>
<li>Deployment</li>
<li>Tools Architecture</li>
<li>OS and Hardware Platforms</li>
</ul>
</p>
<p>Java Language Features were introduced for the ease of programmers and to make it simpler. They include the following:</p>
<ul>
<li>Generics</li>
<li>Enhanced for loop</li>
<li>Autoboxing/unboxing</li>
<li>Typesafe Enums</li>
<li>Varargs</li>
<li>Static import</li>
<li>Annotations</li>
</ul>
</div><hr>
<div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Generics</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">For each loop</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">Autoboxing</a></li>
<li role="presentation"><a href="#Section4" role="tab" data-toggle="tab">TypeSafe Enums</a></li>
<li role="presentation"><a href="#Section5" role="tab" data-toggle="tab">Varargs</a></li>
<li role="presentation"><a href="#Section6" role="tab" data-toggle="tab">Static Import</a></li>
<li role="presentation"><a href="#Section7" role="tab" data-toggle="tab">Annotations</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="Section1">
<div id="Div1">
<h2 class="breadcrumb">Generics</h2>
<p>This feature of Java was introduced in 2004 and is used providing compile-time type safety,”.<br>
Read on to find out more about it, its uses as well as disadvantages.
</p>
<ul>
<li><p>When you take an element out of a Collection, you must cast that element to the type of element that is stored in the collection.</p></li>
<li><p>Besides being inconvenient, this is unsafe. The compiler does not check if your cast is the same as the collection's type, so it can fail at run time.</p></li>
<li><p>Generics provide a way for you to communicate the type of a collection to the compiler so that it can be checked.</p></li>
<li><p>Once the compiler knows the element type of the collection, the compiler can crosscheck whether you have used the collection consistently and can then insert the correct casts on values being taken out of the collection.</p></li>
<li><p>The code using generics is clearer and safer. We have eliminated an unsafe cast and a number of extra parentheses.</p></li>
</ul>
<p><div><pre><xmp>When you see <Type>, read as "of type"
    For example:  ArrayList <String>al = new ArrayList<String>() ;
    Read as : al is type of String.
                  </xmp></pre></div>
<div>
<p><b>Example of collection without Generics</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.javabykiran; 
import java.util.ArrayList; 
import java.util.Iterator; 
  public class GenericsLab1 {
    public static void main(String[] args) {
       ArrayList al= new ArrayList(); // without Generics     
         al.add("java");
         al.add(new Long("88888809416")); 
         Iterator itr = al.iterator();
       while(itr.hasNext()){
         String s =" ";
         Object o =itr.next(); 
          if(o instanceof String){
            s = (String) o ;   
            System.out.println(s);
        }
       if(o instanceof Long){      
            System.out.println((Long)o);
       }
    }
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     java 
     88888809416
  </code></pre>
</div><br>
<div>
<p><b>Example of collection with Generics:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<xmp>package com.javabykiran; 
import java.util.ArrayList; 
import java.util.Iterator; 
public class GenericsLab2 {
  public static void main(String[] args) {
    ArrayList<String> al =new ArrayList<String>(); //with Generics
      al.add("java"); 
      al.add("8888809416");
    Iterator<String> itr = al.iterator();      
      while(itr.hasNext()){
      String p= itr.next();
      System.out.println(p);
    }
  }
}
</xmp></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     java 
     88888809416
  </code></pre>
<p><b>Note:</b>
<ol>
<li>boolean hasNext() returns true if there are more elements, otherwise it returns as false.</li>
<li>Object next() returns the next element. It Throws NoSuchElement Exception if there is no next element present.</li>
</ol>
</div><br>
<div>
<h4>Why should we use Generics?</h4>
<p>There are a number of reasons why we would use generics.</p>
<ul>
<li>Stronger type checks at compile time
<ul>
<li>A Java compiler applies strong type checking to generic code and issues errors if the code violates type safety.</li>
<li>Fixing compile-time errors is easier than fixing runtime errors, which can be difficult to find.</li>
</ul>
</li>
<li>Elimination of casts</li>
</ul><br>
<div>
<p><b>The following code snippet without generics requires casting:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<xmp>List list = new ArrayList(); list.add("hello");
String s = (String) list.get(0);

When re-written to use generics, the code does not require casting: 

  List<String> list = new ArrayList<String>();
  list.add("hello");
  String s = list.get(0); // no cast
</xmp></pre>
</div>
</div>
<ul>
<li><p><b>java.util.ArrayList.get(int index)</b><br>
The method returns the element at the specified position in this list.</p></li>
<li><p><b>public void add(int index, E element);</b><br>
This adds the element to the specified index in the list.</p></li>
</ul>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section2">
<div id="Div2">
<h2 class="breadcrumb">For each loop or Enhanced For Loop</h2>
<ul>
<li>The enhanced for loop is a popular feature introduced with the Java SE platform in version 5.0.</li>
<li>It is also called as for each loop.</li>
</ul>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<xmp>package com.javabykiran; 
import java.util.ArrayList; 
public class ForEachLab3 {
public static void main(String[] args) { 
   ArrayList<String> al = new ArrayList<String>();
     al.add("www.javabykiran.com");   
     al.add("8888809416");
   for (String string : al) { //for each loop 
     System.out.println(string);
    }
  }
}
</xmp></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     www.javabykiran.com 
     8888809416
  </code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section3">
<div id="Div3">
<h2 class="breadcrumb">Autoboxing</h2>
<p>Features and Enhancements Added In Jdk1.5</p>
<ul>
<li><p>The automatic conversion of primitive datatypes into its equivalent wrapper type is called as autoboxing. Its reverse operation is called as Unboxing.</p></li>
<li><p>As you know, we can't put an int (or other primitive value) into a collection. Collections can only hold object references, so you have to box primitive values into the appropriate wrapper class (which is an Integer in the case of int). When you take the object out of the collection, you get the Integer that you put in; if you need an int, you must unbox the Integer using the intValue method.</p></li>
</ul><br>
<div>
<p><b>Example of Autoboxing and Unboxing:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>package com.javabykiran; 
public class BoxingLab1 {
  public static void main(String[] args) {
    int a = 10; 
    Integer i = a;
    //Boxing-- internally : 
    Integer j = Integer.valueOf(a);

    System.out.println(j);
    int c1 = i;	//Unboxing -- : 
    int c2 = i.intValue(); 
    System.out.println(c2);
  }
}
</code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section4">
<div id="Div4">
<h2 class="breadcrumb">TypeSafe Enums</h2>
<ul>
<li><p>An enum is a data type which contains fixed set of constants.</p></li>
<li><p>It can be used for days of the week (SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY and SATURDAY), or directions (NORTH, SOUTH, EAST and WEST) etc.</p></li>
<li><p>The enum constants are static and final implicitly</p></li>
<li><p>It is available from JDK 1.5. It can be thought of as a class, i.e, enum can have constructors, methods and variables.</p></li>
<li><p>Enum improves type safety; it can be easily used with a switch statement.</p></li>
</ul><br>
<div>
<p><b>Example</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;   
  enum Day {
        SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY }
  public class EnumLab1 {
    public static void main(String[] args) { 
      for (Day d : Day.values()) {         
      System.out.println(d);
      }
   } 
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     SUNDAY 
     MONDAY 
     TUESDAY 
     WEDNESDAY 
     THURSDAY 
     FRIDAY 
     SATURDAY
</code></pre>
<p><b>Note:</b>
<ol>
<li>enum have static ‘values’ method that returns an array containing all of the values of the enum in the order that they are declared in.</li>
<li>This method is commonly used in combination with the for-each construct to iterate over the values of an enum type.</li>
</ol>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section5">
<div id="Div5">
<h2 class="breadcrumb">Varargs</h2>
<p>Varargs are Variable Arguments which accepts none or more arguments.</p>
<ul>
<li><p>Varargs can be used for methods that can take zero or more arguments.</p></li>
<li><p>Before varargs was introduced, we had to overload the methods.</p></li>
<li><p>If we are uncertain about the number of arguments we would need, only then should we go for varargs.</p></li>
</ul><br>
<div>
<p><b>Example 1:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com.javabykiran; 
public class VarargsLab {
  void m1(String...s){ 
    System.out.println("in a m1 method");
      for(String val :s){      
        System.out.println(val);
     }
}
public static void main(String...args) {
  //varargs can be apply to main method 
  VarargsLab v = new VarargsLab();
   v.m1();	                    //0-args
   i.m1("www");	                   //1-args
   v.m1("www",".","javabykiran")  //3-args
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     in a m1 method 
     in a m1 method 
     www
     in a m1 method 
     www 
     Javabykiran
</code></pre>
</div><br>
<div>
<p><b>Example 2:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;   
   public class VarargLab {
    int add (int...i){ 
    int sum=0;
      for (int add : i ){
        sum= sum+add;
    }
      return sum;
  }
public static void main(String...args){ 
    VarargLab vl =new VarargLab();
     int add2=vl.add(1,2); 
    System.out.println(add2); 
      int add3=vl.add(1,2,3);       
    System.out.println(add3); 
      int add4=vl.add(1,2,3,4); 
    System.out.println(add4);
   }
 }
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     3
     6
     10
</code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section6">
<div id="Div6">
<h2 class="breadcrumb">Static Import</h2>
<p><b>The static import</b> feature lets fields and methods specified in a class as public static, and is used without naming the class in which the field is defined.</p>
<ul>
<li><p>It is used for accessing static members of any class.</p></li>
<li><p>It is necessary to give the class name from where they came, if we don’t use this concept.</p></li>
<li><p>By using static import we can access static members directly, without giving the class name.</p></li>
<li><p>Static imports can be applied only to static members.</p></li>
</ul><br>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
import static java.lang.System.out; 
import static java.math.BigDecimal.TEN; 
public class StaImpLab {
  public static void main(String[] args){
    out.println("www.javabykiran.com");
    //no need to write System class
    //Because it has already been imported.
    out.println(TEN);
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     www.javabykiran.com 
     10
</code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section7">
<div id="Div7">
<h2 class="breadcrumb">Annotations</h2>
<p><b>Annotations</b> are a form of metadata which gives information about programs which is not a part of the current program.</p>
<ul>
<li><p>It is a form of metadata.</p></li>
<li><p>It provides data about a program that is not part of the program itself. Annotations have no direct effect on the operation of the code they annotate. Java Annotation is a tag that represents the metadata i.e. attached with class, interface, methods or fields to indicate some additional information which can be used by java compiler and JVM.</p></li>
<li><p>There are many built in annotations present and we can also create custom annotations.<br></p>
Annotations are useful in the following ways :
<ol>
<li><p><b>They have information for the compiler -</b><br>
Annotations can be used by the compiler to detect errors or suppress warnings.
</p></li>
<li><p><b>They send Compile-time and deployment-time processing -</b><br>
Software tools can process annotation information to generate code, XML files, and so forth.
</p></li>
<li><p><b>Runtime processing -</b><br>
Some annotations are available to be examined at runtime.
</p></li>
</ol>
</li>
</ul>
<ul>For example : @Override<br>
It assures that a subclass method is overriding the parent class method. <br>
If it is not so, then the compiler will give an error.
</ul>
<br>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>package com.javabykiran; 
  class A {
    void learn(){   
    System.out.println("C");
   }
 }
  public class AnnotationLab extends A { 
   @Override 
   void learn(){
      System.out.println("java by Kiran Sir");
   }
   //error void teach() method does not exist in the     
   //parent class.
   /*@Override 
   void teach(){
   }*/
   public static void main(String[] args) { 
   AnnotationLab lab = new AnnotationLab();
   lab.learn();
 }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     java by Kiran Sir

</code></pre>
</div></div></div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Generics</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">For each loop</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">Autoboxing</a></li>
<li role="presentation"><a href="#Section4" role="tab" data-toggle="tab">TypeSafe Enums</a></li>
<li role="presentation"><a href="#Section5" role="tab" data-toggle="tab">Varargs</a></li>
<li role="presentation"><a href="#Section6" role="tab" data-toggle="tab">Static Import</a></li>
<li role="presentation"><a href="#Section7" role="tab" data-toggle="tab">Annotations</a></li>
</ul>
</div></div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="strings-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="features-of-jdk-1.6-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "jdk 1.5 - Java",
 "alternativeHeadline": "What are the features and enhancements in jdk 1.5 in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java jdk 1.5", 
 "keywords": "java jdk 1.5, jdk 1.5, jdk 1.5 in java, generics, foreach loop, typesafe enums, varargs, static import", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/features-of-jdk-1.5-in-java.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.",
 "articleBody": "There are a few features and enhancements that are added in jdk1.5. These are java language features, performance enhancements, virtual machine, base libraries, user interface, deployment, tools architecture, etc."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
