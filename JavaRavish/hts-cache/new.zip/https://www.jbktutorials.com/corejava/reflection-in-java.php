<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Reflection in Java</title>
<meta name="description" content="Reflection in java is an API that examines or modifies the behavior of classes, methods, fields and interfaces during runtime.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Reflection in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/reflection-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Reflection in java is an API that examines or modifies the behavior of classes, methods, fields and interfaces during runtime.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Reflection in Java">
<meta name="twitter:description" content="Reflection in java is an API that examines or modifies the behavior of classes, methods, fields and interfaces during runtime.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/reflection-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="reflection-in-java.php">
<span itemprop="name">What is Reflection?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Reflection</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Reflection in Java</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<p><b>Reflection</b> in java is an API that examines or modifies the behavior of classes, methods, fields and interfaces during runtime. It is called reflection because of its ability to examine other code, or itself, within the same system. This can be done even when a particular class is inaccessible.</p>
<hr>
<div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Need of Reflection</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">Private Methods & Variables</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">Dynamic Class Loading</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="Section1">
<div id="Div1">
<h2 class="breadcrumb">Why do we need Reflection?</h2>
Let's say we have a requirement as shown below. Observe the class given:</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.reflect;
    /*
    * @author Java By Kiran
    */
    public class Employee {
    public void m1() {
     System.out.println("I am in m1");
    }
    public void m2() {
     System.out.println("I am in m2");
    }
    public void m3() {
     System.out.println("I am in m3");
    }
    public void m4() {
     System.out.println("I am in m4");
    }
   }
</code></pre>
<p>Now we have been asked to call all methods of this class as per client requirement.</p>
<ol type="a">
<li>Client 1 says I need order of calling methods like:<br>
i. m1,m2,m4,m3
</li><br>
<li>Client 2 says I need order of calling methods like:<br>
i. m4,m2,m4
</li><br>
<li>Client 3 says I need order of calling methods like:<br>
i. m1,m2,m3,m4
</li>
</ol>
</div><br>
<div>
<p>If you observe order of methods of every client, you’ll find that they’are all different. To fulfill the above given requirement, we will follow the steps given below :</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.reflect;
/*
* @author Java By Kiran
*/
public class EmployeeTest {
  public static void main(String[] args) {
    // Client 1 - requirement 
    System.out.println("Client 1 Requirement"); 
    Employee employee=new Employee(); 
    employee.m1();
    employee.m2(); 
    employee.m4(); 
    employee.m3();
    // Client 2 - requirement 
    System.out.println("Client 2 Requirement"); 
    Employee employee1=new Employee(); 
    employee1.m4();
    employee1.m2(); 
    employee1.m4();
    // Client 3 - requirement 
    System.out.println("Client 3 Requirement"); 
    Employee employee2=new Employee(); 
    employee2.m1();
    employee2.m2(); 
    employee2.m3(); 
    employee2.m4();
    // Like above for all clients...
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     Client 1 Requirement 
     I am in m1
     I am in m2 
     I am in m4 
     I am in m3
     Client 2 Requirement 
     I am in m4
     I am in m2 
     I am in m4
     Client 3 Requirement 
     I am in m1
     I am in m2 
     I am in m3 
     I am in m4
  </code></pre>
<p>Let’s say there are many clients and their requirements will be different. We will go on writing code as shown above EmployeeTest.java</p>
<p>This is not dynamic. Tomorrow, any addition of client causes our code to change. This is what we don't want to do. Hence, this coding practice is not good.</p>
<p>To solve this requirement we must use reflection. We will be able to solve the above given requirement at a later stage of this chapter once we understand reflection completely.</p>
</div><hr>
<div>
<p><b>Next Requirement</b><br>
We have an excel sheet below:</p>
<div class="tablediv">
<table class="table-bordered" style="width:100%;">
<colgroup>
<col style="width: 10%" />
<col style="width: 30%" />
<col style="width: 30%" />
<col style="width: 30%" />
</colgroup>
<tr>
<th class="center">Roll No</th>
<th class="center">Student</th>
<th class="center">Student Phone No</th>
<th class="center">Remark</th>
</tr>
<tr>
<td>1733</td>
<td>Kiran</td>
<td>8888809416</td>
<td>Java by kiran</td>
</tr>
<tr>
<td>1738</td>
<td>Jayshree</td>
<td>9552343698</td>
<td>www.javabykiran.com</td>
</tr>
</table>
</div><br>
<p>Now we want to insert data from the excel sheet to table Student as shown below:</p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/reflection_excelsheetimg.webp" alt="excel sheet data for reflection example in java" title="Excel sheet data for Reflection Example"></div><br>
<p>To use core java logic for insertion easily with less optimized code, you must use reflection.</p>
</div><hr>
<div>
<p><b>Important points to remember about Reflection:</b></p>
<ol>
<li><p>Java Reflection makes it possible to inspect classes, interfaces, fields and methods at runtime, without knowing the names of the classes, methods, etc.</p></li>
<li><p>We can create objects dynamically by using reflection</p></li>
<li><p>We can create an object of a class having private constructors as well, from outside a class.
Hence, we can instantiate class from outside. This is not possible by simply creating an object by using new operator.</p>
<p>This chapter will explain the basics of Java Reflection including how to work with arrays, annotations, generics and dynamic proxies, and how to do dynamic class loading and reloading. It will also show you how to do more specific tasks, like reading all getter methods of a class, or accessing private fields and methods of a class.</p>
<p>This chapter will also clear up some of the confusion out there about what Generics information is available at runtime. Some people claim that all Generics information is lost at runtime. This is not true.</p>
</li>
<li><p>Package in which all reflection classes are existing : <br>
<b>java.lang.reflect</b>
</p></li>
<li><p><b>For reflection we must know class [Class] first.</b><br>
Class is class name in java and exists in java.lang package.
Instances of the class Class represent classes and interfaces in a running Java application.
In reflection we will deal with preexisting classes like Method, Field, and Constructor and so on.
</p></li>
</ol>
</div><br>
<div>
<p> Let's say we have simple class as shown below:</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.reflect;
public class B {    
   B() {
     System.out.println ("B Zero parameter const");
   }
   B(int x) {
     System.out.println ("B One parameter const");
   }
   int a=90;

   void m1() { 
     System.out.println ("B -m1");
}

   int m2() {
     System.out.println ("B - m2");
   return 10;
  } 
}
</code></pre>
</div><br>
<div>
<p><b>To use reflection we must first get object of Class class.</b><br>
The example below shows two ways.</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.reflect;
 public class A {
  public static void main(String[] args) {
   //First scenario Class c = B.class;
   //Second scenario
   B b=new B();
   Class cl = b.getClass();
  }
}
</code></pre>
</div>
<p>In this example we will get all the information about class B by using c and c1 reference variables by using methods of Class class.
<ol type="a">
<li><p>Above given is class B (every information means --> two constructors, two methods and one variable).</p></li>
<li><p>Here we can see the complete class B but sometimes you only know class name not members of that class. Then we must go for reflection.</p></li>
<li><p>To complete this we use the below methods of class Class [In the second step we have added some reflection code in existing class A].</p></li>
</ol>
<br>
<div>
<p><b>i. To Fetch All methods use the class below:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.reflect; 
import java.lang.reflect.Method; 
public class A {
  public static void main(String[] args) {
    // First scenario 
    Class c = B.class;
    // Second scenario 
    B b = new B();
    Class c1 = b.getClass();
  // GET ALL METHODS OF CLASS B
  // return all public methods of B and inherited methods
    Method[] methodList = c1.getMethods();
  // for each loop you can use simple for loop as //well
for (Method method : methodList) { 
    System.out.println("method name >> " + method.getName());
}
  // below code returns all public/private/protected/default methods of B only
    Method[] methodListAll = c1.getDeclaredMethods();
  // for each loop you can also use simple for loop
     for(Method method : methodListAll) { 
       System.out.println("declared method name >> " +  method.getName());
    }
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     B Zero parameter const
     method name >> wait
     method name >> wait
     method name >> wait
     method name >> equals
     method name >> toString
     method name >> hashCode
     method name >> getClass
     method name >> notify
     method name >> notifyAll
     declared method name >> m1
     declared method name >> m2

  </code></pre>
</div><br>
<div>
<p><b>ii. To Fetch All Variables in class B</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>Add the lines below n class A
// GET ALL VARIABLES OF CLASS B
Field [] fields=c1.getDeclaredFields ();
for(Field field:fields){
    System.out.println("field  name >> "+field.getName());
}
</code></pre>
</div><br>
<div>
<p><b>iii. Getting and Setting Field Values</b><br>
Once you have obtained a Field reference you can get and set its values using the Field.get() and Field.set()methods, like this: // to execute this add variables in class B</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>Class aClass = B.class;	
Field field = aClass.getField("a"); //we are getting one variable
   B bb = new B();     
   field.set(bb, 45)
</code></pre>
</div></div></div>
<div role="tabpanel" class="tab-pane fade" id="Section2">
<div id="Div2">
<h2 class="breadcrumb">Call private methods and variables</h2>
To access a private method you will need to call the Class.getDeclaredMethod(String name, Class[] parameterTypes) or Class.getDeclaredMethods() method.<br>
The methods Class.getMethod(String name, Class[] parameterTypes) and Class.getMethods() methods only return public methods, so they won't work.<br>
Here is a simple example of a class with a private method, and below that is the code to access that method via Java reflection.
</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.reflect; 
import java.lang.reflect.Method; 
public class PrivateObject {
  private String privateString = null; 
  public PrivateObject(String privateString)
 {
    this.privateString = privateString;
 }
  private String getPrivateString() {
    return this.privateString;
 }
  public static void main(String[] args) throws Exception {
    PrivateObject privateObject = new PrivateObject("The Private Value");
    Method privateMethod = PrivateObject.class.getDeclaredMethod("getPrivateString", null);
    privateMethod.setAccessible(true);
    String val=(String)privateMethod.invoke(privateObject, null); 
    System.out.println("returnValue = " + val);
  }
}
</code></pre><br>
<p>This code example will print out the text "return Value = The Private Value", which is the value returned by the method getPrivateString () when invoked on the PrivateObject instance created at the beginning of the code sample.</p>
<p>Notice the use of the method PrivateObject.class.getDeclaredMethod ("privateString"). This method helps to call private method.</p>
<p>It only returns methods declared in that particular class, not methods declared in any superclasses.</p>
<p>Observe the line in bold too. By calling Method.setAcessible (true), you turn off the access checks for this particular Method instance for reflection calls only. Now you can access it even if it is private, protected or package scope, even if the caller is not a part of those scopes. You can't access the method using normal code. The compiler won't allow it.</p>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section3">
<div id="Div3">
<h2 class="breadcrumb">Dynamic Class Loading</h2>
<p><b>Dynamic class loading</b> is a very helpful feature in java that lets us load java code which we are unaware of before the starting of a program. It is invoked at runtime.<br><br>
Use Class.forName in this case.</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.reflect;
/*
* @author Java By Kiran
*/
public class DynaLoad {

Object anyClassObject(String clsName)throws Exception { 
  Object object = Class.forName(clsName).newInstance();
  return object;
}
  public static void main(String[]args)throws Exception {
    DynaLoad dynaLoad=new DynaLoad();
    /* This will give A class object we will pass class name as a String*/
    A a=(A)dynaLoad.anyClassObject("com.jbk.A");
    // now do operations with a

    /*This will give A class object we will pass class name as a String*/

    Employee employee=(Employee)dynaLoad.anyClassObject ("com.jbk.Employee");
    // now do operations with employee
  }
}
</code></pre><br>
<p>In this example we see that the single method we used to get a class object. If we do not use this way we need to hard code like:</p>
<p><code>A a =new A();</code> // can't be changed later // we must know class name</p>
<p><code>Employee employee =new Employee ();</code> // can't be changed later // we must know class name. </p>
<p>If somebody asks why we use class.forname, the answer will be dynamic class object creation.</p><hr>
</div>
</div></div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Need of Reflection</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">Private Methods & Variables</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">Dynamic Class Loading</a></li>
</ul>
</div></div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="annotations-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="arrays-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Reflection - Java",
 "alternativeHeadline": "What reflection in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java reflection", 
 "keywords": "java reflection, reflection, reflection in java, need of reflection, private methods and variables, private methods, private variables, dynamic class loading", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/reflection-in-java",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "Reflection in java is an API that examines or modifies the behavior of classes, methods, fields and interfaces during runtime.",
 "articleBody": "It is called reflection because of its ability to examine other code, or itself, within the same system. This can be done even when a particular class is inaccessible."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
