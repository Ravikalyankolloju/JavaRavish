<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Database Constraints</title>
<meta name="description" content="Constraints are the rules enforced on the data columns of a table. They ensure the accuracy and reliability of the data in the database.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Database Constraints" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/database-constraints.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Constraints are the rules enforced on the data columns of a table. They ensure the accuracy and reliability of the data in the database.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Database Constraints">
<meta name="twitter:description" content="Constraints are the rules enforced on the data columns of a table. They ensure the accuracy and reliability of the data in the database.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/database-constraints.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="introduction-to-java.php">
<span itemprop="name">Core Java</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Database - Constraints</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Database Constraints</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<p><a href="database-in-java.php" class="btn btn-outline-danger">&larr; Go back to Database Chapter</a></p>
<div>
<h2 class="breadcrumb">Constraints</h2>
<p>Constraints are the rules which can be applied to the data getting inserted in the table or while updating the table. The types of constraints are given below:</p>
<ul>
<li><p>Not null constraint</p></li> <li><p>Unique constraint</p></li> <li><p>Primary key constraint</p></li> <li><p>Foreign key constraint</p></li> <li><p>Check constraint</p></li>
</ul>
</div>
<hr>
<div>
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#NotNullConstraint" role="tab" data-toggle="tab">Not Null Constraint</a></li>
<li role="presentation"><a href="#UniqueConstraint" role="tab" data-toggle="tab">Unique Constraint</a></li>
<li role="presentation"><a href="#PrimaryKeyConstraint" role="tab" data-toggle="tab">Primary Key Constraint</a></li>
<li role="presentation"><a href="#ForeignKeyConstraint" role="tab" data-toggle="tab">Foreign Key Constraint</a></li>
<li role="presentation"><a href="#CheckConstraint" role="tab" data-toggle="tab">Check Constraint</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="NotNullConstraint">
<div>
<h2 class="breadcrumb">Not Null Constraints</h2>
<p>The not null constraint makes sure that a field is never empty or null, but is always assigned a value. It also ensures that null values are not accepted by a column.</p>
<ul>
<li><p>Whenever the programmer has not provided a value for any columns, then null will be automatically inserted by the DBMS</p></li>
<li><p>Null means value is not available</p></li>
<li><p>Null is not equivalent to zero or space or any other thing</p></li>
<li><p>If you do not want another value for any given column and force the user to supply the value then you can apply not null constraints</p></li>
<li><p>Usage of the Not Null constraint:<br>
<code>CREATE TABLE students (sid INT, sname, CHAR (10) NOT NULL , totalfee DOUBLE NOT NULL_ _ _ _ _ _ _ _);</code></p></li>
</ul>
<p><b>Question:</b><i> What will happen when we try to insert a record into students table without total fee?</i><br>
<b>Answer:</b> An error will occur as it is not null specified and you have to provide a value.</p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="UniqueConstraint">
<div>
<h2 class="breadcrumb">Unique Constraints</h2>
<p>If you want to provide only unique values for any given column then you can apply the unique constraint.</p>
<ul>
<li><p>Usage of Unique constraints:<br>
<code>Create table students S. ID int not null unique, S. Name Char (10) not null, Email char (10) not null unique, Phone long unique, );</code></p></li>
</ul>
<p><b>Question 1:</b><i> What will happen when two students provide the same number? </i><br>
<b>Answer:</b> The second student’s record insertion will fail.</p>
<p><b>Question 2:</b><i> Can I have multiple null values for the phone number columns? </i><br>
<b>Answer:</b> Yes.</p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="PrimaryKeyConstraint">
<div>
<h2 class="breadcrumb">Primary Key Constraints</h2>
<p>The Primary key constraints checks both not null and unique constraints. It should have a unique value and cannot be null. It provides a unique identification for every row in the table.</p>
<p>Primary Key = Not Null + Unique</p>
<p>Therefore, it has properties of both not null and unique constraints.</p>
<ul><li><p>Usages:<br>
<code>Create table students ( sid INT PRIMARY KEY, sname CHAR(10) NOT NULL, email CHAR (10) NOT NULL UNIQUE, phone LONG NOT NULL UNIQUE,_ _ _ _ _ _ _ _ _);</code></p></li></ul>
<p>The table should contain only one primary key.</p>
<p>There are two types of primary key:</p>
<ul>
<li><p>Simple primary key</p></li> <li><p>Composite primary key</p></li>
</ul>
<h3>Simple primary key:</h3>
<p>When you specify the key for a single column then it is called simple primary key.</p>
<p><b>Example:</b><br>
<code>Create table students (sid INT PRIMARY KEY, sname CHAR (10) NOT NULL UNIQUE_ _ _ _ _ _ _);</code></p>
<h3>Composite Primary Key:</h3>
<p>When you specify the primary key for a combination of two or more columns, then it is called composite primary key.</p>
<p><b>Example:</b><br>
<code>Create table, accounts ( Bcode int, acc no int, atype int, bal double not null, primary key (bcode, atype, accno));</code><br><br>
<b>Only for balance,</b><br>
<code>Select balance of accounts where balance code = 0047 and account types = 01 and account no = 530255</code><br>
Output: <code>Full Accounts No: 004701530255</code>
</p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="ForeignKeyConstraint">
<div>
<h2 class="breadcrumb">Foreign Key Constraints</h2>
<p>The Foreign key constraint is used to the establish the relationship among the tables.</p>
<div class="table-responsive">
<table class="table table-bordered">
<b>Customers</b>
<tr><th>Customer ID</th> <th>Customer Name</th> <th>Email</th> <th>Phone</th></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
</table></div><br>
<div class="table-responsive">
<table class="table table-bordered">
<b>Accounts</b>
<tr><th>Customer ID</th> <th>Account Type</th> <th>Account Type</th> <th>Amount</th> <th>Balance</th></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
</table></div><br>
<div class="table-responsive">
<table class="table table-bordered">
<b>Transactions</b>
<tr><th>Branch Code</th> <th>Account Type</th> <th>Account No</th> <th>Trans. ID</th> <th>Trans. Date</th> <th>Trans. Type</th> <th>Amount</th> <th>Total</th></tr>
<tr><td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
</table></div><br>
<p>Usages:</p>
<p><code>Create table customers (customerid, interest int primary key, customername char (10) not null);</code></p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img10.webp" alt="primary key constraints in sql" title="Create table customers with primary key constraints"></div><br>
<p><code>Create table accounts (customer int references customers, branch code int, account type int, balance double not null, primary key (branch code, account type, account no));</code></p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img11.webp" alt="foreign key constraints in sql" title="Create table accounts with foreign key constraints"></div><br>
<p><code>Create table transactions (branchcode int, accounttype int, account no int, TxID int, Txdate date, Tx type char (2), amount double, foreign key accounts (branch code, account type, account no));</code></p>
<p><b>Note:</b> A Table can contain many foreign keys but only one primary key.</p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="CheckConstraint">
<div>
<h2 class="breadcrumb">Check Constraints</h2>
<p>The Check constraint checks the specified condition on the specified columns. These conditions have to be met by the column. However, it can be placed only on one particular table, and not all the tables.</p>
<p>Usage:<br>
<code>Create table students (student ID int primary key, student name char (10) not null, total fee double check total fee >=1500; fee paid double check fee paid double check fee paid >= 1000, city character (20) check city in ('Banglalore', 'mysore'));</code></p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img11.5.webp" alt="check constraints in sql" title="Create table students with check constraints"></div><br>
<ul>
<li><p>It will make sure that total fee inserted should be greater than or equal to 1500</p></li>
<li><p>It will make sure that the fee paid should be greater than or equal to 1000.</p></li>
<li><p>The city name can only be Pune or mysore.</p></li>
<li><p>31 January 2011</p></li>
</ul>
<ul><li>
<ul>ZIPCODE : Substr (Zipcode, 1, 3) 11 '-' substr (zipcode,4) </ul>
<ul>To- date (‘20-Jul-11’ ‘DD-MONTH-YYYY’)</ul>
<ul>Ltrim - side space </ul>
<ul>Ltrim - left side space </ul>
<ul>Diagram -20</ul>
</li></ul><br>
<p>Select sum (fee paid) 'total' from student group by branch order by total;</p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img12.webp" alt="select all sql command" title="Student Table Data"></div><br>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img13.webp" alt="group by and order by sql command" title="order by total output"></div><br>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/database_img14.webp" alt="group by and order by sql command" title="order by total in descending order output"></div><br>
<ul>
<li><p>Always use Desc and asc after the order by and column name;</p></li>
<li><p>Occupation - create certified professional</p></li>
</ul>
</div>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#NotNullConstraint" role="tab" data-toggle="tab">Not Null Constraint</a></li>
<li role="presentation"><a href="#UniqueConstraint" role="tab" data-toggle="tab">Unique Constraint</a></li>
<li role="presentation"><a href="#PrimaryKeyConstraint" role="tab" data-toggle="tab">Primary Key Constraint</a></li>
<li role="presentation"><a href="#ForeignKeyConstraint" role="tab" data-toggle="tab">Foreign Key Constraint</a></li>
<li role="presentation"><a href="#CheckConstraint" role="tab" data-toggle="tab">Check Constraint</a></li>
</ul>
</div><hr>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item disabled">
<a class="page-link btn-outline-primary" href="jdbc-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Database Constraints - Java",
 "alternativeHeadline": "What are constraints in database?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java database constraints", 
 "keywords": "java database constraints, database constraints, constraints, not null constraint, unique constraint, primary key constraint, foreign key constraint, check constraint", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/database-constraints.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-12-12",
 "dateCreated": "2019-12-12",
 "dateModified": "2019-12-12",
 "description": "Constraints are the rules enforced on the data columns of a table.",
 "articleBody": "Constraints are the rules which can be applied to the data getting inserted in the table or while updating the table. "
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
