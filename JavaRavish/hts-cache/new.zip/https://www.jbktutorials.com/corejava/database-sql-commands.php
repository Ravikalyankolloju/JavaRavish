<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Database SQL Commands</title>
<meta name="description" content="SQL commands are instructions. It is used to communicate with the database. It is also used to perform specific tasks, functions, and queries of data.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Database SQL Commands" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/database-sql-commands.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="SQL commands are instructions. It is used to communicate with the database. It is also used to perform specific tasks, functions, and queries of data.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Database SQL Commands">
<meta name="twitter:description" content="SQL commands are instructions. It is used to communicate with the database. It is also used to perform specific tasks, functions, and queries of data.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/database-sql-commands.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="introduction-to-java.php">
<span itemprop="name">Core Java</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Database - SQL Commands</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Database SQL Commands</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<p><a href="database-in-java.php" class="btn btn-outline-danger">&larr; Go back to Database Chapter</a></p>
<hr>
<div>
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#CreateCommand" role="tab" data-toggle="tab">Create Command</a></li>
<li role="presentation"><a href="#InsertCommand" role="tab" data-toggle="tab">Insert Command</a></li>
<li role="presentation"><a href="#UpdateCommand" role="tab" data-toggle="tab">Update Command</a></li>
<li role="presentation"><a href="#DeleteCommand" role="tab" data-toggle="tab">Delete Command</a></li>
<li role="presentation"><a href="#DropCommand" role="tab" data-toggle="tab">Drop Command</a></li>
<li role="presentation"><a href="#TruncateTable" role="tab" data-toggle="tab">Truncate Table</a></li>
<li role="presentation"><a href="#Example" role="tab" data-toggle="tab">Example</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="CreateCommand">
<div>
<h2 class="breadcrumb">Create Command</h2>
<p><b>Syntax</b> to create a table in MySql is as follows:<br>
<code>CREATE TABLE tablename (column name datatype (size)… );</code></p>
<p><b>Example:</b><br>
<code>CREATE TABLE authors (aid INT, aname CHAR(20), dod DATE, quali CHAR(20), email CHAR(20), phonenumber VARCHAR(12));</code></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="InsertCommand">
<div>
<h2 class="breadcrumb">Insert Command</h2>
<p><b>Syntax</b> to insert value:
<code>Insert Into tablename (Col1, Col2……) values (Val1,Val2……);</code></p>
<p><b>Example:</b><br>
<b>In Mysql:</b><br> <code>Insert into authors values (101, 'Kiran', '2001-10-10 ', 'M.Sc', '<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ddb6b4afbcb39dbbb1b8f3beb2b0">[email&#160;protected]</a>', 123456);</code><br><br>
<b>In Oracle:</b><br> <code>Insert into authors values (102, 'vas', '10-oct-2001', 'M.Sc', '<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="a9dfc8dae9cfc5cc87cac6c4">[email&#160;protected]</a>', 123456);</code>
</p>
<p>Authors Table With Data</p>
<div class="tablediv">
<table class="table-bordered table-responsive-xl" style="width:100%;">
<colgroup>
<col style="width: 10%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 15%" />
<col style="width: 30%" />
<col style="width: 10%" />
</colgroup>
<tr>
<td>Aid</td> <td>Aname</td> <td>DOB</td> <td>Quail</td> <td>Email</td> <td>Phone</td>
</tr>
<tr>
<td>101</td> <td>Kiran</td> <td>2001-10-10</td> <td>M.Sc</td> <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="355e5c47545b755359501b565a58">[email&#160;protected]</a></td> <td>123456</td>
</tr>
</table>
</div><br>
<ul>
<li><p><b>Rectify It :</b> IRectify It :nsert into authors values (103, 'sd', 'M.Sc' 12345);</p></li>
<li><p><b>Rectified :</b> Insert Into authors (aid, aname, quali, phonenumber) VALUES (103, 'sd', 'M.Sc', 12345);</p></li>
</ul>
<hr>
<h3>Notes:</h3>
<ol>
<li><p>Char & date type values must be enclosed in single quotation marks.</p></li>
<li><p>Whenever you are inserting date type values, you should make sure that the correct date format is used.</p></li>
<li><p>Whenever you are not providing values for all the columns, you must specify the first column name and add that table name.</p></li>
<li><p>Whenever you are not supplying values for a column, a null will be placed in that column.</p></li>
</ol><hr>
<p><b>Question:</b> <i>What will happen when you give the following command:</i> <br>
<code>INSERT INTO authors (phonenumber, aname, aid) VALUES (1234, 'sd',104);</code></p>
<p><b>Answer:</b> It will execute successfully.</p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="UpdateCommand">
<div>
<h2 class="breadcrumb">Update Command</h2>
<p><b>Syntax</b> to insert value:
<code>Update table-name set col1 = Val1, Col2 = val2 Where condition;</code></p>
<p><b>Example:</b> <br>
<p><b>Single Update:</b><br>
<code>UPDATE authors SET email = '<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="e68d8f948788a6808a83c885898b">[email&#160;protected]</a>', phonenumber = 999 WHERE aid = 101;</code></p>
<p><b>Multiple Update:</b><br>
<code>UPDATE authors SET phonenumber = 999;</code></p>
<p><b>Note:</b></p>
<ol>
<li><p>Using one update state, you can update zero or more records.</p></li>
<li><p>ROLLBACK - insert, delete and update not for create and drop</p></li>
</ol>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="DeleteCommand">
<div>
<h2 class="breadcrumb">Delete Command</h2>
<p><b>Syntax</b> to insert value:
<code>DELETE FROM tablename WHERE CONDITIONS;</code></p>
<p><b>Example:</b> <br>
<p><b>Single Update:</b><br>
<code>DELETE FROM authors WHERE aid = 103;</code></p>
<p><b>Multiple Update:</b><br>
<code>DELETE FROM authors;</code> (DELETES ALL DATA IN AUTHOR’S TABLE)</p>
<p><b>Note:</b>
<ol>Using one delete statement, you can delete zero or more records.</ol>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="DropCommand">
<div>
<h2 class="breadcrumb">Drop Command</h2>
<p><b>Syntax:</b>
<code> DROP TABLE tablename;</code></p>
<p><b>Example:</b>
<code> DROP TABLE authors;</code></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="TruncateTable">
<div>
<h2 class="breadcrumb">Truncate the Table</h2>
<p><b>Syntax:</b>
<code> TRUNCATE TABLE tablename;</code></p>
<p><b>Example:</b>
<code>TRUNCATE TABLE authors; DELETE FROM authors;</code></p>
<ol>
<li><p>Both the statements will give you an empty tab at the end.</p></li>
<li><p>The Delete statement deletes all records one by one, whereas the Truncate state does the table simply and creates a new table.</p></li>
<li><p>Delete takes more time than the Truncate state.</p></li>
<li><p>Delete operation can be cancelled i.e. it can be called back, whereas Truncate operations cannot be callback.</p></li>
<li><p>DELETE deletes the entire table with its structure whereas TRUNCATE deletes only the data that is inside that particular table.</p></li>
</ol>
<p><b>Syntax :</b><br>
<code>Select (or) cal1, col2 _ _ _ _ _ _ _ _ _ tab1, tab2<br>
Where condition Order by col-name Group by col-name Having condition;</code></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Example">
<div>
<h2 class="breadcrumb">Example</h2>
<div class="tablediv">
<p><b>Books Table</b></p>
<table class="table-bordered table-responsive-xl" style="width:100%;">
<colgroup>
<col style="width: 20%" />
<col style="width: 5%" />
<col style="width: 5%" />
<col style="width: 10%" />
<col style="width: 10%" />
<col style="width: 10%" />
<col style="width: 10%" />
<col style="width: 30%" />
<col style="width: 10%" />
</colgroup>
<tr>
<th>BookID</th> <th></th> <th></th> <th>Cost</th> <th>Isbn</th> <th>Pub</th> <th>Qty</th> <th>Edition</th> <th>Tob</th>
</tr>
<tr>
<td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td>
</tr>
</table>
</div><br>
<div name="QuestionsAndAnswers">
<p><b>Question 1:</b> <i>Display complete information of all the books.</i><br>
<b>Answer:</b> <code>Select * from books;</code>
</p>
<p><b>Question 2:</b> <i>Display the bookID, bookname, cost and the edition of all the books.</i><br>
<b>Answer:</b> <code>Select bookID, bookname, cost, edition, from books;</code>
</p>
<p><b>Question 3:</b> <i>Display the books published by DLC.</i><br>
<b>Answer:</b> <code>Select * from books where pub= 'ONLYFORJAVA';</code>
</p>
<p><b>Question 4:</b> <i>Display the books written by Kiran.</i><br>
<b>Answer:</b> <code>Select * from books where author = 'kiran';</code>
</p>
<p><b>Question 5:</b> <i>Display the books written by Kiran in 2010.</i><br>
<b>Answer:</b> <code>Select * from books where author = 'kiran' and YOP = 2010;</code>
</p>
<p><b>Question 6:</b> <i>Display the book whose name you learnt in the beginning.</i><br>
<b>Answer:</b> <code>Select * from books where book name like 'learn %';</code>
</p>
<p><b>Question 7:</b> <i>Display the books which cost less than INR 200 and are written by an author whose name ends with Vas.</i><br>
<b>Answer:</b> <code>Select cost, author from book where cost <200 and author like '%Vas';</code>
</p>
<p><b>Question 8:</b> <i>Display the books published between 2005 and 2010.</i><br>
<b>Answer:</b> <code>Select * from books where YOP>=2005 and YOP<=2010; <br><b>or</b><br> Select * from books where YOP between 2005 and 2010;</code>
</p>
<p><b>Question 9:</b> <i>Display the books published by "TATA", "ONLYFORJAVA" and "P5".</i><br>
<b>Answer:</b> <code>Select * from books where pub='TATA' or pub='ONLYFORJAVA' or pube='P5'; <br><b>or</b><br> Select * from books where pub in ('TATA', 'ONLYFORJAVA', 'P5');</code>
</p>
<p><b>Question 10:</b> <i>Display the books which cost from INR50 to 300 in ascending order of cost.</i><br>
<b>Answer:</b> <code>Select * from books where cost between 50 and 300 order by cost asc;</code>
</p>
<p><b>Question 11:</b> <i>Display the books published in 2009 in descending order of their costs.</i><br>
<b>Answer:</b> <code>Select * from books where YOP=200g order by cost describtion;</code>
</p>
<p>To Display the books which are not published by ONLYFORJAVA <br>
<code>Select * from books where PUB< >'ONLYFORJAVA'</code> <br> <b>or</b><br>
<code>Where PUB not in 'ONLYFORJAVA';</code></p>
<p>To Display the books written by the author whose name second character is S. <br>
<code>Select * from books where author like '-s%';</code></p>
</div>
</div>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#CreateCommand" role="tab" data-toggle="tab">Create Command</a></li>
<li role="presentation"><a href="#InsertCommand" role="tab" data-toggle="tab">Insert Command</a></li>
<li role="presentation"><a href="#UpdateCommand" role="tab" data-toggle="tab">Update Command</a></li>
<li role="presentation"><a href="#DeleteCommand" role="tab" data-toggle="tab">Delete Command</a></li>
<li role="presentation"><a href="#DropCommand" role="tab" data-toggle="tab">Drop Command</a></li>
<li role="presentation"><a href="#TruncateTable" role="tab" data-toggle="tab">Truncate Table</a></li>
<li role="presentation"><a href="#Example" role="tab" data-toggle="tab">Example</a></li>
</ul>
</div><hr>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item disabled">
<a class="page-link btn-outline-primary" href="jdbc-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Database SQL Commands - Java",
 "alternativeHeadline": "What are sql commands?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  }, 
 "genre": "java database sql commands", 
 "keywords": "java database sql commands, database sql commands, sql commands, create command, insert command, update command, delete command, drop command, truncate", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/database-sql-commands.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-12-12",
 "dateCreated": "2019-12-12",
 "dateModified": "2019-12-12",
 "description": "SQL commands are instructions. It is used to communicate with the database.",
 "articleBody": "It is also used to perform specific tasks, functions, and queries of data."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
