<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Exception in Java</title>
<meta name="description" content="Exceptions are events occurring during a program execution which interrupt the regular flow of data.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Exception in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/exception-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Exceptions are events occurring during a program execution which interrupt the regular flow of data.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Exception in Java">
<meta name="twitter:description" content="Exceptions are events occurring during a program execution which interrupt the regular flow of data.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/exception-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="exception-in-java.php">
<span itemprop="name">How to handle Exceptions?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Exception</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Exception in Java</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<div id="Div1">
<p><b>Exceptions</b> are events occurring during a program execution which interrupt the regular flow of data. In java, exceptions are objects which wrap error events that happen inside a method and contain details about the error and its type.
<hr><div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#Throwable" role="tab" data-toggle="tab">Throwable</a></li>
<li role="presentation"><a href="#Error" role="tab" data-toggle="tab">Error</a></li>
<li role="presentation"><a href="#InternalFlowOfJVM" role="tab" data-toggle="tab">Internal Flow Of JVM</a></li>
<li role="presentation"><a href="#Syntax" role="tab" data-toggle="tab">Syntax</a></li>
<li role="presentation"><a href="#BusinessUse" role="tab" data-toggle="tab">Business Use</a></li>
<li role="presentation"><a href="#Finally" role="tab" data-toggle="tab">Finally</a></li>
<li role="presentation"><a href="#ThrowandThrows" role="tab" data-toggle="tab">Throw and Throws</a></li>
<li role="presentation"><a href="#RuntimeException" role="tab" data-toggle="tab">Runtime/Unchecked Exception</a></li>
<li role="presentation"><a href="#CompileTimeException" role="tab" data-toggle="tab">Compile time/Checked Exception</a></li>
<li role="presentation"><a href="#ExceptionvsError" role="tab" data-toggle="tab">Exception vs Error</a></li>
</ul>
</div><hr>
<ul>
<li><p>There are some exceptional cases in java which throw an exception</p></li>
<li><p>In mathematics, 1/0 is infinity, but in java this is an exceptional case. This terminates a program.<br>
In this chapter, we will learn about of ‘try’, ‘catch’, ‘finally’, ‘throws’ and ‘throw’ and the use of these five keywords in industry or business.</p></li>
<li><p>All exceptions occur only at runtime while syntax errors occur at compile time.</p></li>
</ul>
<hr>
<div>
<p>Why do we need to Learn Exception?<br>
<b>Consider the program below. It executes properly and prints the output</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception;
/**
* @author Java By Kiran
*/
public class ExceptionWithoutError { 
  public static void main(String[] args) {
    System.out.println("111"); 
    System.out.println("222"); 
    System.out.println("333"); 
    System.out.println("444");
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     111
     222
     333
     444
  </code></pre>
</div><br>
<div>
<p>Now add one exceptional code in between, which is shown in bold.</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception;
/**
* @author Java By Kiran
*/
 public class ExceptionDivideByZero { 
    public static void main(String[] args){
        System.out.println("111"); 
        System.out.println("222"); 
        <b>int a=1/0;</b> 
        System.out.println("333"); 
        System.out.println("444");
     }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     111
     222
  </code></pre>
</div>
<p>Exception in thread "main" java.lang.ArithmeticException: / by zero at com.javabykiran.Exception.Exception.main(Exception.java:10).
<ul>
<li><p>In this case we are not able to get an output as expected as the exceptional case is in the middle. After learning this chapter we will be able to run anything and everything by handling such exceptional conditions.</p></li>
<li><p>Here you can see that the client will see this error message and it is not user friendly. It is better to show a more user friendly message.</p></li>
<li>We summarise the two uses
<ul>
<li>to make a continuation of a program</li>
<li>to avoid java error messages and to provide good, user friendly messages</li>
</ul>
</li>
</ul>
<hr>
<div class="docs-galley">
Shown below is the hierarchy<img class="docs-pictures clearfix centerimage" src="../images/java/exceptionhierarchy1.webp" alt="throwable exception hierarchy in java" title="Throwable Exception hierarchy"></div>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/exceptionhierarchy2.webp" alt="throwable error hierarchy in java" title="Throwable Error hierarchy"></div>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="Throwable">
<h2 class="breadcrumb">Throwable:</h2>
<ul>
<li><p>In the above given Hierarchy Throwable is a class which is at the top of the exception hierarchy, from which all exception classes are derived.</p></li>
<li><p>It is the super class of all Exceptions.</p></li>
<li><p>Only objects which are instances of this class can throw exception by using the throw statement.</p></li>
<li><p>Only object of this class or one of its subclasses can be the argument type in a catch block.</p></li>
<li>Problems faced during the program execution be divided into two types:
<ul>
<li>Exceptions</li>
<li>Errors</li>
</ul>
</li><br>
<li><p>Both Exception and Errors are java classes which are derived from the Throwable class</p></li>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="Error">
<h2 class="breadcrumb">Error:</h2>
<ul>
<li><p>Error is subclass of throwable class and it terminates the program if there is a problem related to system or resources. It signifies a serious problem in the application and are mostly abnormal conditions.</p></li>
<li><p>Error does not occur because of the programmer’s mistakes, but when system is not working properly or a resource is not allocated properly.</p></li>
<li><p>Memory out of bound exception, stack overflow etc., are examples of Error.</p></li>
<li><p>Only object of this class or one of its subclasses can be the argument type in a catch block.</p></li>
<li><p>It is common to make errors while developing or typing a program and this may cause the program to produce unexpected results. It is therefore necessary to detect and manage the error conditions in the program so that the program doesn’t terminate during the execution.</p></li>
<li><p>Sun Microsystems has categorized all exceptions in different categories. For example, for all arithmetic operations are under class called ArithmaticException.java</p></li>
<li><p>For all sql type of exceptions, they created a class called SQLExcption.java, and so on.</p></li>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="InternalFlowOfJVM">
<h2 class="breadcrumb">Internal Flow by JVM:</h2>
<ol type="1">
<li><p>Take a look at the above class ExceptionDivideByZero.java [in the beginning of this chapter]</p></li>
<li><p>When the interpreter reads the line int a=1/0;</p></li>
<li><p>The control goes to JVM and it searches for a category of exception. In this case it is Arithmetic exception.</p></li>
<li><p>The JVM creates an Object of that class, then it comes back to the same line again with a reference variable of ArithmaticException class.</p></li>
<li><p>It does check if this line is in the try block.</p></li>
<li><p><b>If No,</b> then it goes to the console and prints a message by the getMessage method of ArithmaticException class.</p></li>
<li><p>The program terminates and won’t come back to our program again.</p></li>
<li><p><b>If Yes,</b> refers to the program given below with try and catch</p></li>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception;
/**
@author Java By Kiran
*/
public class ExceptionWithTryCatch { 
  public static void main(String[] args) {   
    System.out.println("111");   
    System.out.println("222");
  try {
    System.out.println("before divide");    
      int a = 1 / 0; 
    System.out.println("after divide");
  } 
  catch (Exception e) {  
    System.out.println("I am in catch block");
    }
    System.out.println("333");   
    System.out.println("444");
   } 
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     111
     222
     before divide
     I am in catch block 
     333
     444
  </code></pre>
</div>
<li><p>In this case, it looks for the corresponding catch block and then it sees which class is there in this case (Exception).</p></li>
<li><p>In this case, the compiler assigns Arithmetic class’s object to Exception reference variable.</p></li>
<li><p><code>Exception e = new ArithmeticException();</code></p></li>
<li><p>If the above (11) is correct, then it enters in the catch block.</p></li>
<li><p>If it is not correct, then it considers that the try catch is not written and goes back to console and prints error. Point : 5</p></li>
<li><p>After executing catch block, the cursor goes to the next line and the execution continues 333 then 444.</p></li>
<li><p>This is because as soon the interpreter see the exception, it goes for catch block, not in between sentences. In our case it is ‘after divide’<br>
Some rules are below:
<ul>
<li><p>Try should be followed by only catch or only finally block or multiple catch or multiple catch and single finally</p></li>
<li><p>When exception is not raised in the try block statements then catch block will not be executed</p></li>
<li><p>You can write multiple try-catch blocks</p></li>
<li><p>When you are writing a multiple catch block, then order or exception must first be subclass and then superclass</p></li>
<li><p>When exception is raised in the try block statements then only one matching catch block will be executed</p></li>
<li><p>You should not write any statement between try block and catch block </p></li>
<li><p>We can write this combination anywhere inside the method. Given below are various combinations that are allowed</p></li>
</ul>
</li>
</ol></div>
<div role="tabpanel" class="tab-pane fade" id="Syntax">
<h2 class="breadcrumb">Syntax</h2>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>// Not Allowed as try must followed by catch or finally
   try {
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>// <b>Allowed</b> 
try {
  }
catch(Exception e){
  }
finally{
  }
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>// <b>Not Allowed</b> 
try {
}
catch(Exception e){
}
Finally {
  }catch(Exception e){
 }
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>// <b>Allowed</b> 
try {
}catch(NullPointerException npe) {
} catch(ArithmeticException e) {
} catch(Exception e){
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>// <b>Not allowed</b> – Reason: The bigger exception cannot be in the 
// first catch because it will accommodate all exceptions and there
//  will be no chance to reach the second catch of NullpointerException 
try{
}
catch(Exception e) {
}
catch(NullPointerException npe) {
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>void m1(){
   for ( int i=0;i<100;i++){
   try{
     //Insertion Logic
   }catch(Exception e){
     //Student name with error for loop continues
     //again for other students
   }
  }// for loop end
}// m1 ends
</code></pre>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="BusinessUse">
<h2 class="breadcrumb">Business Use</h2>
<p>If we have a requirement of inserting 100 students to DB subject to the condition that if there is any issue in insertion for any student, it should not impact the other students.
Now,the requirement is to Add 100 student but if any student fails, other students should not get inserted
</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>void m1(){
    try{
      for (int i=0;i<100;i++){
    //Insertion Logic, if fails should go to catch block
      }// for loop end
    }catch(Exception e){
    //Student name with error; after this it will not go in 
    //for loop again
    }
} // m1 ends
</code></pre>
</div>
<div role="tabpanel" class="tab-pane fade" id="Finally">
<h2 class="breadcrumb">Finally</h2>
<p>The finally block is used when an important part of the code needs to be executed. It is always executed whether or not the exceptions are handled.
<ul>
<li><p>Finally block will always get executed until we shut down JVM. To shut down JVM in java we call System.exit (); or we have infinite loop in try block.</p></li>
<li><p>Occurs irrespective of any exception.</p></li>
<li><p>Occurs irrespective of any return value in try or catch.</p></li>
<li><p>Normally, finally block contains the code to release resources like DB connections, IO streams etc.</p></li>
<li><p>You can also write resource cleanup code inside the finalize() method. But finally block is recommended rather than the finalize method for resource cleanup.</p></li>
</ul><br>
<div class="tablediv">
<p><b>Question.</b> What is the difference Between Catch and Finally in java?</p>
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 4%" />
<col style="width: 48%" />
<col style="width: 48%" />
</colgroup>
<tr>
<th class="center">Sr. No.</th>
<th class="center">Catch</th>
<th class="center">Finally</th>
</tr>
<tr>
<td>1</td>
<td>Catch block handles the error when it occurs in try block</td>
<td>There is no need of exception thrown by try block</td>
</tr>
<tr>
<td>2</td>
<td>Catch block is executed only when the if exception is thrown by try block, otherwise it is not executed</td>
<td>Finally block is always executed whether exception occurs or not</td>
</tr>
<tr>
<td>3</td>
<td>We can use multiple catch block for only one try block</td>
<td>Only one finally block is used for one try block</td>
</tr>
<tr>
<td>4</td>
<td>We can handle multiple exceptions by using catch blocks</td>
<td>It is not for exception handling</td>
</tr>
</table>
</div>
<hr>
<div>
<p><b>Examples:</b> check compile time error and runtime output in some cases<br>
<b>Question:</b> Will it compile?</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception;
/**
* @author Java By Kiran
*/
public class FinallyTest { 
int m1() {
  try {
    return 10;
  } catch (Exception e) { 
      return 20;
  } finally { 
      return 30;
  }
  return 40;
  }
}
</code></pre>
<p><b>Answer:</b> It will not compile (Unreachable code)<br> <code>return 40;</code></p>
</div><br>
<div>
<b>Question:</b> What will this method return?</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code11" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code11" class="breadcrumb pretagcodebox">
<code>int m1() {
   try {
    return 10;
   } catch (Exception e) { 
      return 20;
   } finally { 
      return 30;
   }
}
</code></pre>
<p><b>Answer:</b> <code>30</code></p>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="ThrowandThrows">
<h2 class="breadcrumb">Throw and Throws:</h2>
<p><b>Why are they needed?</b><br>
To delegate exception from one class to another we use throw and throws.<br>
Consider the case below:
</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code12" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code12" class="breadcrumb pretagcodebox">
<code>class A{
   // calls m1 of class B
}
class B{
   // calls m2 of class C
}
class C{
   // calls m3 of class D
}
class D{
   // some logic
}
</code></pre>
</div>
<ul>
<li><p>Consider the above code where A is sending a request to B and</p></li>
<li><p>then to C and then to D</p></li>
<li><p>If the exception occurs at class C m3 method, then what message will A get? Nothing,Program will get terminated at C class</p></li>
<li><p>If we use try and catch at every class and every method then exceptions will get handled but message will not be transferred in the reverse direction, which is from C to B and then to A</p></li>
<li><p>So, to delegate these types of exceptions to caller of the method we use throw and throws from one class to another</p></li>
<li><p>Here, C will delegate its exception to B’s m2 and then B’s m2 will delegate to A’s m1 (); there we will write try and catch and will give an user friendly message</p></li>
<li><p>This scenario is more appropriate when there is remote calling. For example, FLIPKART calls to ICICI bank then ICICI to AIRTEL for sms and to mastercard for authorisation</p></li>
<li><p>In this case, the whole infrastructure is different. This means that there is different ram and different hard disk for every entity. So, if we click a button in FLIPKART and something happens at the ICICI’s end, we will just keep waiting. But by using throw, throws we will get a message that is delegated by ICICI</p></li>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="RuntimeException">
<h2 class="breadcrumb">Runtime / Unchecked Exception</h2>
<p><b>RuntimeException</b> is a superclass of exceptions that may be thrown in the regular course of operation of JVM. Runtime exceptions and its subclasses are known as unchecked exceptions.</p>
<ul>
<li><p>This exception occurs at runtime. Actually, even checked exception occurs at runtime</p></li>
<li><p>All exceptions under runtime exception class are called runtime exceptions or unchecked exceptions</p></li>
<li><p>In the industry, it is not expected that the developer leave these exceptions in the program 1/0 operation … developer should check before this that whether no is zero</p>
<pre><code>if( b > 0 ){
    int c=a/b 
 }
</code></pre>
</li>
<li><p>If any method throws runtime exception, then the caller is not restricted to handle that exception.</p></li>
</ul>
<div>
<p>See the example below:</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code13" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code13" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception; 
  public class RuntimeEx {
    void m1() throws NullPointerException { 
    }
    void m2(){
      m1(); // no error as m1 throws 
      //runtime exception
   }
}
</code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="CompileTimeException">
<h2 class="breadcrumb">Compile time / Checked Exception</h2>
<p>All exceptions which are not runtime exceptions are <b>compile time exceptions.</b><br>
They are checked at compile time.
</p>
<ul>
<li><p>These exceptions are those which are not under runtime exception class hierarchy</p></li>
<li><p>If thrown from any method, they must be handled by caller of the method otherwise it gives compile time error</p></li>
<li><p>The most confusing thing is that some people say it occurs at compile time. That is wrong; exception always occurs at runtime only</p></li>
<li><p>If any method throws runtime exception, then the caller is not restricted to handle that exception.</p></li>
</ul>
<div>
<p>See the example below:</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code14" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code14" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception; 
public class RuntimeEx {
    void m1() throws ClassNotFoundException {
  }
    void m2(){
      m1(); // Error as m1 throws compile time exception
  }
}
</code></pre>
</div>
<p class="center"><b>OR</b></p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code15" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code15" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception; 
 public class RuntimeEx {
  void m1() throws ClassNotFoundException {
  }
  void m2() throws ClassNotFoundException{ 
    m1();
  }
}
</code></pre>
</div><br>
<div>
<h4>Throw:</h4>
<p><b>The throw keyword</b> declares an exception. It tells the user about the error and helps the user create an exception handling code from the outset.</p>
<ul>
<li><p>Throw keyword is used to throw the exceptions</p></li>
<li><p>Normally JVM is responsible for identifying the exceptional java class, creating its objects and throwing that object</p></li>
<li><p>You can use the throw keyword with this syntax: throw object;<br>
Example:</p>
<pre><code>throw new ArithmeticException(); 
           <b>or</b>
ArithmeticException ae = new ArithmeticException(); 
throw ae;
throw new StudentNotFoundException():    
</code></pre>
</li>
</ul>
</div><br>
<div>
<h4>Throws:</h4>
<ul>
<li><p><b>Throws keyword</b> is used to specify the method level exceptions</p></li>
<li><p>If any method throws compile time exception then caller should :</p>
<ol type="1">
<li><p>Handle that exception by writing try a block inside the method</p></li>
<li><p>Or propagate the exception to caller of the method level exception using throws keyword</p></li>
</ol>
</li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code16" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code16" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Exception; 
  public class ThrowsTest {
       void m1() throws ArithmeticException,ArrayIndexOutOfBoundsException {
    try { 
        m2();
    } catch (ArrayIndexOutOfBoundsException e) { 
    if (1 == 2) {
       throw new ArrayIndexOutOfBoundsException();
    } else {
       throw new ArithmeticException("Don’t do");
    }
}
    return null;
}
     void m2()throws ArrayIndexOutOfBoundsException {   
        System.out.println("its ok");
   // void m3()throws ArrayIndexOutOfBoundsException {} 
     try {
         m4();
     } catch (ArithmeticException e) { 
         System.out.println("m3-ok-ok");
         throw new ArrayIndexOutOfBoundsException();
       }	
}
      void m4() throws ArithmeticException { 
          m5();
      }
      void m5() throws ArithmeticException { 
         int x = 10 / 0;
      }
   }
 }
package com.javabykiran.Exception;
  public class ExceptionLab3 {
    public static void  main(String[] args) { 
     try {
         ThrowsTest ex = new ThrowsTest(); 
         ex.m1();
      } catch (Exception e) { 
            System.out.println(e);         
            System.out.println(e.getMessage());
            e.printStackTrace();
       }
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     its ok
     java.lang.ArithmeticException: Don’t do
                                     at 
     com.javabykiran.Exception.ThrowsTest.m1(ThrowsTest.java:12)
                                     at 
     com.javabykiran.Exception.ExceptionLab3.main(ExceptionLab3.java:7) m3-ok-ok
     java.lang.ArithmeticException: Don’t do 
     Don’t do
</code></pre>
</div>
</div><br>
<div class="tablediv">
<p><b>Question :</b> What is the difference between Checked Exception and Unchecked Exception keyword?</p>
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 4%" />
<col style="width: 48%" />
<col style="width: 48%" />
</colgroup>
<tr>
<th class="center">Sr. No.</th>
<th class="center">Checked Exception</th>
<th class="center">Unchecked Exception</th>
</tr>
<tr>
<td>1</td>
<td>Checked Exceptions are checked at compile time.</td>
<td>Unchecked exceptions are not checked at compile time.</td>
</tr>
<tr>
<td>2</td>
<td>Checked exceptions must be explicitly caught or propagated as described in Basic try-catch-finally Exception Handling.</td>
<td>Unchecked Exception doesn’t have to be caught or declared thrown.</td>
</tr>
<tr>
<td>3</td>
<td>Checked exceptions in Java extend the java.lang.Exception class.</td>
<td>Unchecked exceptions extend the java.lang.RuntimeException.</td>
</tr>
<tr>
<td>4</td>
<td>Checked Exception represents a scenario with higher failure rate.</td>
<td>Unchecked Exception occurs mostly due to programming mistakes.</td>
</tr>
<tr>
<td>5</td>
<td>Checked Exception needs to be handled by the caller.</td>
<td>Unchecked exceptions are not handled by the caller.</td>
</tr>
</table>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="ExceptionvsError">
<div class="tablediv">
<h2 class="breadcrumb">Difference between Exception and Error</h2>
<ul>
<li><p>Exception represents the problem which can be solved whereas error represents the problem which cannot be solved. </p>
<p>Exceptions can be handled and can contain the program execution where as errors cannot be handled </p>
<p>Some examples of exceptions are: <br>
ArithmeticException, IOException, etc. </p>
<p>Some examples of errors are: <br>
NoSuchMethodError, ClassDefNotFoundError, OutOfMemoryError StackOverflowError, etc.</p>
</li>
<li><p>All exceptions and errors will always be thrown at runtime only.</p></li>
<li><p>Error comes at runtime and syntactical error comes at compile time.</p></li>
</ul>
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 4%" />
<col style="width: 48%" />
<col style="width: 48%" />
</colgroup>
<tr>
<th class="center">Sr. No.</th>
<th class="center">Exception</th>
<th class="center">Error</th>
</tr>
<tr>
<td>1</td>
<td>Exceptions are related to the application.</td>
<td>Error is related to the environment in which the application is running.</td>
</tr>
<tr>
<td>2</td>
<td>Exceptions may not be fatal in all cases.</td>
<td>An Error can't be recovered as it is fatal in nature.</td>
</tr>
<tr>
<td>3</td>
<td>An Exception is basically divided into two categories,
i.e. Checked and Unchecked Exceptions. A Checked Exception has a special place in the Java programming language and requires a mandatory try catch finally code block to handle it
Unchecked Exception is a subclass of Runtime Exception that usually represents programming errors.</td>
<td>An error is basically divided into 2 categories
<ol>
<li>Compile Time</li> <li>Runtime</li>
</ol>
</td>
</tr>
<tr>
<td>4</td>
<td>Exceptions can be checked or unchecked. Programmer should handled at the application level.</td>
<td>Errors are always unchecked and usually indicate a system error or a problem with a low level resource and should be handled at the system level, if possible.</td>
</tr>
<tr>
<td>5</td>
<td></td>
<td>Handling an Error is not a good idea because recovery from an Error is usually not possible.</td>
</tr>
</table>
</div></div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#Throwable" role="tab" data-toggle="tab">Throwable</a></li>
<li role="presentation"><a href="#Error" role="tab" data-toggle="tab">Error</a></li>
<li role="presentation"><a href="#InternalFlowOfJVM" role="tab" data-toggle="tab">Internal Flow Of JVM</a></li>
<li role="presentation"><a href="#Syntax" role="tab" data-toggle="tab">Syntax</a></li>
<li role="presentation"><a href="#BusinessUse" role="tab" data-toggle="tab">Business Use</a></li>
<li role="presentation"><a href="#Finally" role="tab" data-toggle="tab">Finally</a></li>
<li role="presentation"><a href="#ThrowandThrows" role="tab" data-toggle="tab">Throw and Throws</a></li>
<li role="presentation"><a href="#RuntimeException" role="tab" data-toggle="tab">Runtime/Unchecked Exception</a></li>
<li role="presentation"><a href="#CompileTimeException" role="tab" data-toggle="tab">Compile time/Checked Exception</a></li>
<li role="presentation"><a href="#ExceptionvsError" role="tab" data-toggle="tab">Exception vs Error</a></li>
</ul>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="serialization-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="annotations-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Exception - Java",
 "alternativeHeadline": "What is exception in java?",
 "image": "https://www.jbktutorials.com/images/java/exceptionhierarchy2.webp",
  "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java exception", 
 "keywords": "java exception, exception, exceptions in java, throwable exception, error, finally, runtime exception, unchecked exception, compile time exception, checked exception", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/exception-in-java",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "Exceptions are events occurring during a program execution which interrupt the regular flow of data.",
 "articleBody": "In java, exceptions are objects which wrap error events that happen inside a method and contain details about the error and its type."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
