<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Serialization in Java</title>
<meta name="description" content="Serialization is a mechanism of converting the state of an object into a byte stream. By implementing Externalizable interface we can persist and restore the object.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Serialization in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/serialization-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Serialization is a mechanism of converting the state of an object into a byte stream. By implementing Externalizable interface we can persist and restore the object.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Serialization in Java">
<meta name="twitter:description" content="Serialization is a mechanism of converting the state of an object into a byte stream. By implementing Externalizable interface we can persist and restore the object.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/serialization-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="serialization-in-java.php">
<span itemprop="name">What is Serialization?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Serialization</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Serialization in Java</h1>
<div class="card-body">
<div>
<p><b>Serialization</b></p>
<ul>
<li><p>Writing objects States into some other sources like Hard Disk, Socket, file etc., is called Serialization.</p></li>
<li><p>Serialization is needed when there is a problem in sending data from one class to another.<br>
Where the other class is on a different location or Hard Disk. i.e. in Distributed Systems</p></li>
<li><p>The reverse operation of serialisation is called deserialization</p></li>
<li><p>The String Class and all wrapper classes implement serializable interface by default</p></li>
<li><p>Serializable interface is also marker interface which provides the capability of Serialization to your class. So, we should implement a serializable interface if we want to send the state of an object over the network</p></li>
</ul>
<hr>
<div>
<p>Consider the following program of Serialization and Deserialization:<br>
<b>Example 1:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.javabykiran; 
import java.io.Serializable;
public class Student implements Serializable {
  String name; 
  int age;
  String location;
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
import java.io.FileOutputStream; 
import java.io.ObjectOutputStream; 
public class SerializeStudent {
  public static void main(String[] args) {
    Student s = new Student(); 
    s.name = "abc";
    s.age = 25; 
    s.location = "pune"; 
    try{
FileOutputStream fos = new FileOutputStream ("D:\\state.txt");
  ObjectOutputStream oos = new ObjectOutputStream(fos);
  oos.writeObject(s); 
  oos.flush();
  System.out.println("Serialization is done...");
    }
    catch (Exception e) { 
    e.printStackTrace();
   }
  }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
import java.io.FileInputStream; 
import java.io.ObjectInputStream; 
public class DeserializeStudent {
   public static void main(String[] args){
     try{
 FileInputStream fis = new FileInputStream("D:\\state.txt"); 
   ObjectInputStream ois = new ObjectInputStream(fis);
    Object o = ois.readObject(); //Read the object
    Student s=(Student)o;//convert to student
       System.out.println(s.name); 
       System.out.println(s.age);    
       System.out.println(s.location);
    }
     catch(Exception e){ 
          e.printStackTrace();
         }
       }
  }
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     abc 
     25
     pune
  </code></pre>
</div><br>
<ul>
<li><p>The ObjectOutputStream and ObjectInputStream are used to serialize and de-serialize objects respectively.</p></li>
<li><p>If the superclass implements serializable interface, then all its subclasses will be serializable by default.</p></li>
<li><p>All static members of class are not serialized because static members are related to class only, not to object.</p></li>
<li><p>If we don't want to serialize some fields of class then we use the <b>transient keyword</b>. If any member is declared as transient then it won't be serialized.</p></li>
<li><p>In case of array or collection, all the objects of array or collection must be serializable; if any object is not serializable then the serialization will fail.</p></li>
<li><p>The serialization associated with each serializable class has a version number called Serial Version UID.</p></li>
<li><p>It is used during de-serialization to verify that the sender and receiver of a serialized object have loaded classes for that and are compatible with respect to serialization.</p></li>
<li><p>If the receiver is loaded with different version of a class that has different serial version UIDs than the corresponding sender's class, then de-serialization will result in an invalid Class Exception.</p></li>
<li><p>A Serializable class can declare its own serial version UID explicitly by declaring a field named serial version UID that must be static, final and of type long.</p></li>
<li><p>If a superclass variable is made transient, then after de-serialization, it gives default value like zero or null.</p></li>
</ul><br>
<div>
<p>Consider the above same program in which we don't want to serialize the age of a student<br>
<b>Example 2:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>package com.javabykiran; 
import java.io.Serializable;
public class Student implements Serializable {
  String name; 
  transient int age; 
  String location;
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
import java.io.FileOutputStream; 
import java.io.ObjectOutputStream; 
public class SerializeStudent {
 public static void main(String[] args) { 
 Student s = new Student();
   s.name = "abc";
   s.age = 25;//wont be serialized 
   s.location = "pune";
   try{
 FileOutputStream fos = new FileOutputStream("D:\\state.txt");
   ObjectOutputStream oos = new ObjectOutputStream(fos); 
   oos.writeObject(s); 
   oos.flush();
   System.out.println("Serialization is done...");
   }
   catch (Exception e) { 
   e.printStackTrace();
   }
 }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
import java.io.FileInputStream;
import java.io.ObjectInputStream; 
public class DeserializeStudent {
  public static void main(String[] args) {
  try{
    FileInputStream fis = new FileInputStream("D:\\state.txt");
    ObjectInputStream ois = new ObjectInputStream(fis);
    Object o = ois.readObject(); //Read the object
    Student s = (Student)o;//convert to student 
    System.out.println(s.name); 
    System.out.println(s.age); //wont be deserialize,will printdefault value 
    System.out.println(s.location);
  }
  catch(Exception e){ 
    e.printStackTrace();
   }
  }
 }
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     abc
     0   // Not Serialized as transient
     Pune
  </code></pre>
</div>
</div>
<hr>
<div class="tab" role="tabpanel">
<div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#Externalization" role="tab" data-toggle="tab">Externalization</a></li>
<li role="presentation"><a href="#SerializationvsExternalization" role="tab" data-toggle="tab">Serialization vs Externalization</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="Externalization">
<div id="Div2">
<h2 class="breadcrumb">Externalization</h2>
<p>Externalization is serialization, except that it is an alternative for it.
<ul>
<li><p>Externalization is nothing but serialization but by implementing Externalizable interface we can persist and restore the object.</p></li>
<li><p>To externalize your object, you need to implement Externalizable interface that extends the Serializable interface.</p></li>
<li><p>Here we have complete control of what to serialize and what not to serialize.</p></li>
<li><p>But with serialization, the identity of all the classes, its superclasses, instance variables and then the contents for these items, is written to the serialization stream.</p></li>
<li><p>Externalizable interface is not a marker interface and it provides two methods: writeExternal and readExternal.</p></li>
<li><p>How does serialization happen? JVM first checks for the Externalizable interface and if the object supports Externalizable interface, then it serializes the object using write External method. If the object does not support Externalizable but implements
Serializable, then the object is saved using ObjectOutputStream.
</p></li>
<li><p>In case of Serializable, jvm has full control of serializing object, while in case of Externalizable, the application gets the control for persisting objects.</p></li>
<li><p>writeExternal(), readExternal() methods provides complete control on format and content of serialization process</p></li>
</ul><hr>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="SerializationvsExternalization">
<div id="Div3">
<h2 class="breadcrumb">Listed here are the differences between Serialization and Externalization:</h2>
<ul>
<li><p>In case of serializable, default serialization process is used. While in case of externalization, custom serialization process is used which is implemented by application.</p></li>
<li><p>JVM gives a call back to readExternal() and writeExternal of Externalizable interface (application implementation) for restoring and writing objects.</p></li>
<li><p>Though Externalizable provides complete control, list also has challenges to serialize super type state and take care of default values in case of transient variable and static variables in Java.</p></li>
<li><p>If used correctly, Externalizable interface can improve the performance of the serialization process.</p></li>
</ul><br>
<div>
<p><b>Example 3:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.externalization; 
import java.io.Externalizable;
import java.io.IOException; 
import java.io.ObjectInput; 
import java.io.ObjectOutput;
public class Person implements Externalizable{
  String name; 	
  int age;

  @Override
public void writeExternal(ObjectOutput out)throws IOException {
  out.writeObject(name); 
  out.writeInt(age);
  }

  @Override
public void readExternal(ObjectInput in) throws IOException,
  ClassNotFoundException  { 
  name = (String)in.readObject(); 
  age = in.readInt();
  }
}
</code></pre>
</div><br>
<div>
<p><b>Example 4:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.externalization; 
import java.io.FileOutputStream;
import java.io.ObjectOutputStream; 
public class SerializeP {
  public static void main(String[] args) {
    try{
      Person p = new Person(); 
      p.name = "Kiran";
      p.age= 24; 
FileOutputStream fos =new FileOutputStream("D:\\person.txt"); 
ObjectOutputStream oos = new ObjectOutputStream(fos);
  oos.writeObject(p); 
  System.out.println("successful");
    }
    catch(Exception e){ 
      e.printStackTrace();
    }
  }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.externalization; 
import java.io.FileInputStream;
import java.io.ObjectInputStream; 
public class DeserializeP {
  public static void main(String[] args) throws Exception {
    FileInputStream fis = new FileInputStream("D:\\person.txt");
    ObjectInputStream ois = new ObjectInputStream(fis);
    Person p =(Person) ois.readObject(); 
    System.out.println(p.name); 
    System.out.println(p.age);
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     Kiran
     24
  </code></pre>
</div>
</div></div></div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#Externalization" role="tab" data-toggle="tab">Externalization</a></li>
<li role="presentation"><a href="#SerializationvsExternalization" role="tab" data-toggle="tab">Serialization vs Externalization</a></li>
</ul>
</div>
<hr>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="collection-revisited-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="exception-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Serialization - Java",
 "alternativeHeadline": "What is serialization in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java serialization", 
 "keywords": "java serialization, serialization, serialization in java, externalization, serialization vs externalization, serialization and externalization", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/serialization-in-java",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "Serialization is a mechanism of converting the state of an object into a byte stream.",
 "articleBody": "Serialization is needed when there is a problem in sending data from one class to another where the other class is on a different location or Hard Disk. i.e. in Distributed Systems."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
