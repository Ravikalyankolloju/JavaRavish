<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Database Subquery</title>
<meta name="description" content="A subquery is used to return data that will be used in the main query as a condition to further restrict the data to be retrieved.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Database Subquery" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/database-sub-queries.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="A subquery is used to return data that will be used in the main query as a condition to further restrict the data to be retrieved.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Database Subquery">
<meta name="twitter:description" content="A subquery is used to return data that will be used in the main query as a condition to further restrict the data to be retrieved.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/database-sub-queries.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="introduction-to-java.php">
<span itemprop="name">Core Java</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Database - Subquery</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Database Sub Queries</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<p><a href="database-in-java.php" class="btn btn-outline-danger">&larr; Go back to Database Chapter</a></p>
<hr>
<div>
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#SubQueries" role="tab" data-toggle="tab">Sub Queries</a></li>
<li role="presentation"><a href="#Example" role="tab" data-toggle="tab">Example</a></li>
<li role="presentation"><a href="#AlterCommand" role="tab" data-toggle="tab">Alter Command</a></li>
<li role="presentation"><a href="#DropCommand" role="tab" data-toggle="tab">Drop Command</a></li>
<li role="presentation"><a href="#ModifyCommand" role="tab" data-toggle="tab">Modify Command</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="SubQueries">
<div>
<h2 class="breadcrumb">Sub Queries</h2>
<ul>
<li><p>You can include one query as part of another query, this is called a sub query.</p></li>
<li><p>The output of a sub query is used inside the main query.</p></li>
<li><p>It is also called inner query.</p></li>
</ul>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Example">
<div>
<h2 class="breadcrumb">Example</h2>
<ul>
<li><p>First, the sub query is evaluated and then the result of that sub query will be used to evaluate the main query.</p></li>
<li><p>Depending on the scenario, the sub query may return one or more results.</p></li>
</ul>
<div name="QuestionsAndAnswers">
<div>
<p><b>Question 1:</b> <i>What is the name of the customer whose account no is 8?</i><br>
<b>Answer:</b><br> <code>Select customer name from customers where <br>
CID = (select cid from accounts where acc. No. = 8);
</code></p>
</div>
<div>
<p><b>Question 2:</b> <i>Display the account number and balance of the customers who are active.</i><br>
<b>Answer:</b><br> <code>Select account no, balance of accounts <br>
Where customer ID in (select C.ID from customers where status = 'enabled'); <br>
</code>(In operator is used for more than one record)</p>
</div>
<div>
<p><b>Question 3:</b> <i>Display the balance of customers who are staying in Pune.</i><br>
<b>Answer:</b><br><code>Select balance of accounts where C. ID in (Select C. ID from address <br>
Where city = 'pune');
</code></p>
</div>
<div>
<p><b>Question 4:</b> <i>Display the name and status of the customers who are staying in Pune and Mysore.</i><br>
<b>Answer:</b><br><code>Select customer name, status from customer <br>
Where C.ID in (select city from address Where city in ('pune','mysore','pune');
</code></p>
</div>
<div>
<p><b>Question 5:</b> <i>Display the name and email of the customer who has a saving accounts and balance between 5000 and 10000.</i><br>
<b>Answer:</b><br><code>Select customer name, email from customer <br>
where C.ID in (Select atype, balance of accounts where account type ='SA' and balance between 5000 & 10000)
</code></p>
</div>
<div>
<p><b>Question 6:</b> <i>How can we create aTable From another Table Using Sub Queries?</i><br>
<b>Answer:</b><br>
<ul>
<li><b>With Data:</b><br>
<code>Create table customer 1 as select from customers;</code>
</li><br>
<li><b>With Data:</b><br>
<code>Create table customer 1 as Select C.ID, Customer name, status from customer where Status = 'enabled';</code>
</li><br>
<li><b>Without Data:</b><br>
<code>Create table customer 3 as Select from customers where 1 = 2; </code><br> (condition false: empty records Create dummy records here).
</li><br>
<li><b>With Data:</b><br>
<code>Create table customer 4 as <br>
Select customer name, email, acc.no. balance <br>
from Customers Cust., accounts acc., <br>
Where customer C.ID = account C.ID;
</code>
</li>
</ul>
</p>
</div>
<div>
<p><b>Question 7:</b> <i>Display the name and balance of the customers who are staying in Pune.</i><br>
<b>Answer:</b><br>
<code>Select customer name, balance from customer cust, accounts acc <br>
where customer C.ID = account C.ID and C.ID in ( Select C.ID from address where City = 'pune');
</code>
</p>
</div>
</div>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="AlterCommand">
<div>
<h2 class="breadcrumb">Alter Command</h2>
<p>The alter command modifies the table by adding, deleting or modifying columns in a table which already exists.</p>
<code>Create table student (S.ID int, S.name char (10));</code><br><br>
<p><b>Adding the columns : Syntax:</b><br>
<code>alter table tab_name add (col_name type (size), col_name type (size));</code>
</p>
<p><b>Example:</b><br>
<code>Alter table students add (email char (15)); Alter table students add fee double,
After student name;</code> (in MYSQL)</p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="DropCommand">
<div>
<h2 class="breadcrumb">Drop Command</h2>
<p>The drop command removes a table from the database.</p>
<p><b>Syntax:</b><br>
<code>Alter table tab_name drop column col_name;</code></p>
<p><b>Example:</b><br>
<code>Alter table student drop column fee;</code></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="ModifyCommand">
<div>
<h2 class="breadcrumb">Modify Command</h2>
<p>The drop command removes a table from the database.</p>
<p><b>Syntax:</b><br>
<code>Alter table tab_name modify Col_name type (size);</code></p>
<p><b>Example:</b><br>
<ul>
<li><code>Alter table students modify C.ID int;</code><li>
<li><code>Alter table students modify student name char (2);</code></li>
</ul>
<ol>
<li>
<b>Adding the Primary Key:</b>
<p><b>Syntax:</b><br>
<code>Alter table tablename add primary key Column name;</code></p>
<p><b>Example:</b><br>
<code>Alter table tablename add primary key Column name;</code></p>
</li>
<li>
<b>Dropping the Primary Key:</b>
<p><b>Syntax:</b><br>
<code>Alter table tab_name drop primary key;</code></p>
<p><b>Example:</b><br>
<code>Alter table student drop primary key;</code></p>
</li>
<li>
<b>Adding the constraint:</b>
<p><b>Syntax:</b><br>
<code>Alter table tab_name add constraint constraint_name<br>
_ _ _ _ _ _ your constraint here _ _ _ _ _ _;
</code></p>
<p><b>Example:</b><br>
<code>Alter table student add constraint ck 1, email, not null;</code></p>
</li>
<li>
<b>Adding the constraint:</b>
<p><b>Syntax:</b><br>
<code>Alter table tab_name drop Constraint cons_name;</code></p>
<p><b>Example:</b><br>
<code>Alter table student drop constraint CK1;</code></p>
</li>
</ol></p>
</div>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#SubQueries" role="tab" data-toggle="tab">Sub Queries</a></li>
<li role="presentation"><a href="#Example" role="tab" data-toggle="tab">Example</a></li>
<li role="presentation"><a href="#AlterCommand" role="tab" data-toggle="tab">Alter Command</a></li>
<li role="presentation"><a href="#DropCommand" role="tab" data-toggle="tab">Drop Command</a></li>
<li role="presentation"><a href="#ModifyCommand" role="tab" data-toggle="tab">Modify Command</a></li>
</ul>
</div><hr>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item disabled">
<a class="page-link btn-outline-primary" href="jdbc-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Database Sub Queries - Java",
 "alternativeHeadline": "What are sub queries in database?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java database sub queries", 
 "keywords": "java database sub queries, database sub queries, sub queries, inner query", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/database-sub-queries.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-12-12",
 "dateCreated": "2019-12-12",
 "dateModified": "2019-12-12",
 "description": "A subquery is used to return data that will be used in the main query as a condition to further restrict the data to be retrieved.",
 "articleBody": "You can include one query as part of another query, this is called a sub query. The output of a sub query is used inside the main query. It is also called inner query."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
