<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Abstraction in Java</title>
<meta name="description" content="In simple words, abstraction captures only those details about an object that are relevant to the current perspective. Learn more about abstraction in java.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Abstraction in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/abstraction-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="In simple words, abstraction captures only those details about an object that are relevant to the current perspective. Learn more about abstraction in java.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Abstraction in Java">
<meta name="twitter:description" content="In simple words, abstraction captures only those details about an object that are relevant to the current perspective. Learn more about abstraction in java.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/abstraction-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="abstraction-in-java.php">
<span itemprop="name">What is Abstraction?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Abstraction</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Abstraction in Java</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<p><b>Abstraction</b> is a process of hiding details about implementation from the user while letting them utilise the services or functions. Therefore, the user will know what an object does, but not how it does it. It is done to simplify the user interface while hiding the complex processes.</p>
<ul><li>Exposing only required or important things is called abstraction</li>
<li>Abstraction can be done in two ways :
<ul>
<li>Abstract class</li>
<li>Interface</li>
</ul>
</li>
<li>It is used for maintaining the standards of coding in project</li>
</ul>
<hr>
<div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#Interface" role="tab" data-toggle="tab">Interface</a></li>
<li role="presentation"><a href="#WhyInterface" role="tab" data-toggle="tab">Why Interface ?</a></li>
<li role="presentation"><a href="#AbstractClass" role="tab" data-toggle="tab">Abstract Class</a></li>
<li role="presentation"><a href="#AbstractandInterfaceDifference" role="tab" data-toggle="tab">Abstract & Interface Difference</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="Interface">
<div id="Div1">
<h2 class="breadcrumb">Interface</h2>
<ul>
<li><p>One of the java principles says that we must follow the I to C design. This means that every class should be implemented from Interface</p></li>
<li><p>In the industry, architect level people create interfaces and then it is given to the developers for writing classes by implementing interfaces provided</p></li>
<li><p>This is best way to expose our project’s API to some other projects. For example, ICICI bank can expose methods or interfaces to various shopping carts</p></li>
<li><p>The interface is the same as ordinary class but remember below points</p></li>
<li><p>We cannot instantiate Interface but we can create reference variables</p></li>
<li><p>The interface doesn't have a constructor</p></li>
<li><p>It can be compiled but cannot run</p></li>
<li><p>Interface can extends interface</p></li>
<li><p>The interface can extend multiple interfaces</p>
<ul>
Example: <pre class><code>void m1();   //No body Method</code></pre>
<li>In case of classes, we must define the body of method
<pre class><code>package com.abstraction; 
    public class X   { 
         void m1();   // compile time error method should have body
}               
</code></pre>
</li>
<li>In case of classes, if we want the above written lines to compile when we have method without body, then we must explicitly define that method as abstract in case of classes, but not in case of interface
<pre class><code>package com.abstraction;
    public class X { 
        abstract void m1();  // compile time error  
}     
</code></pre>
</li>
<li>In case of classes, if method is abstract then class must be declared as abstract as well.
<pre class><code>package com.abstraction;
     public abstract class X { 
        abstract void m1();  // No error  
}     
</code></pre>
</li>
<li>In case of interface we don't need to do explicit declaration for methods like class but they are, by default, abstract
<pre class><code>package com.InterFace; 
    interface Xi {
        void m1(); // abstract keyword invisibly present 
}     
</code></pre>
</li>
<li>All methods are public in interface. If you want to mention access specifiers, mention them as public, or do not mention any access specifier and JVM will automatically consider it as public, every time</li>
</ul>
</li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.InterFace;    
    interface xyz {
        void m1(); // public and abstract invisibly put by JVM 
    }
package com.InterFace;    
public interface x {
    public abstract void m1();	//OK 
        public void m3();	//OK  
        abstract void m6();//OK
        void m7();//OK
}
</code></pre>
</div>
<ul>
<li>Variables are public final static in interface and act like constants</li>
<li>If we want to use methods of interface, we have to implement that interface in any class, and methods of interface must be implemented in a class by using the implements keyword</li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.InterFace; 
  interface Xi {
        void m1();
    }
package com.InterFace;
  public class	XImpl implements xi{
    //Not compiled as we have not implemented all the methods
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com.InterFace; 
  public interface Ai {
     void m1();  //OK
}
package com.InterFace; 
  public interface Bi {
     void m1();	 //OK
  }
package com.InterFace;
  public interface Ci extends Ai,Bi {   //OK     
     void m1();
  }
</code></pre>
</div>
<p>This is allowed in java </p>
<ul>
<li>interface can extend interface1 and interface2</li>
<li>class extends class implements interface</li>
<li>class implements interface</li>
<li>class extends class implements interface1 and interface2</li>
</ul><hr>
<ul>
<li><p><i><b>Q.</b> Why do we need Interface?</i><br>
<b>A:</b> To expose the third party API</p></li>
<li><p><i><b>Q.</b> Why not constructor?</i><br>
<b>A:</b> In interface it will not get called by using super by using hierarchy</p></li>
<li><p><i><b>Q.</b> As an interface has abstract method, how will you use the abstract method of interface? </i><br>
<b>A:</b> Implement that method in class, or in other words override methods, and then create object of that class and call all methods</p></li>
<li><p><i><b>Q.</b> Have you ever used others third party API code?</i><br>
<b>A:</b>Yes, they have their Interface and API and we can use that.</p></li>
</ul>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="WhyInterface">
<div id="Div2">
<h2 class="breadcrumb">Why interface?</h2>
<p>
Suppose there is a requirement for Flipkart to integrate ICICI bank code into their shopping cart.Their customers want to make payment for products they purchased. Now, to make payment, Flipkart does not have their own bank, so it must take help of other banks.<br>
Let's say ICICI develops code like below:
<pre class><code>class Transaction { 
    void withdrawAmt(int amtToWithdraw) {
        void m1(); // abstract keyword invisibly present 
            //logic of withdraw
            //ICICI DB connection and updating in their DB
    }
}   
</code></pre>
<p>Flipkart needs this class so they request ICICI bank for the same. The problem with ICICI is that if they give this complete code to flipkart they risk exposing everything of their own database to them as well as their logic, which is a security violation.</p>
<p>Now, what exactly Flipkart needs is the method name and class name. But to compile their class they must get one like below:
<pre class><code>Transaction t=new Transaction();  //1
t.withdrawAmt(500);   //2
</code></pre>
<p>If the first line to compile at Flipkart ends, then they must have this class which ICICI cannot give. The best solution here is for ICICI to develop an Interface of Transaction class as shown below:</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>interface Transactioni {
     void withdrawAmt(int amtToWithdraw) ;
}
class TransactionImpl implements Transactioni { 
    void withdrawAmt(int amtToWithdraw) {
        //logic of withdraw
        //ICICI DB connection and updating in their DB
    } 
}
</code></pre>
</div>
<ul>
<li><p>Flipkart will now get the interface but not class, and they can use it as shown below:<br>
<code>Transactioni ti = new TransactionImpl();</code> // the result on the right hand side may be achieved by webservices or EJB TransactionImpl physically not present at Flipkart<br>
<code>ti.withdrawAmt(500);</code></p>
</li>
<li><p>In this case, both parties achieved their goal, Flipkart which only needs method name and parameter and they got it</p></li>
<li><p>ICICI only wants to give them the name but not their logic, which they provided. Also it does not matter to ICICI what you purchased, they just want to have amount to be deducted</p></li>
</ul>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="AbstractClass">
<div id="Div3">
<h2 class="breadcrumb">Abstract Class</h2>
<ul>
<li><p>Abstract class is just like a normal class but with some extra features which we will see in this chapter</p></li>
<li><p>Abstract class can have constructor</p></li>
<li><p>It can have abstract methods or concrete methods or nothing [empty class] or mix of both methods</p></li>
<li><p>To use abstract method of class, we must extend the abstract class with ordinary class or must implement all abstract methods in that ordinary class</p></li>
<li><p>If we don't want to implement or override that method, make those methods as abstract</p></li>
<li><p>If any method is abstract in a class then that class must be declared as abstract</p></li>
<li><p>We cannot instantiate abstract class</p></li>
<li><p>Multiple inheritances are not allowed in abstract class but allowed in interfaces</p></li>
<li><p>Abstract classes are useful if we want others to not call our class directly but though Inheritance</p></li>
<li><p>Abstract static final combinations are not allowed in java</p></li>
</ul><hr>
<ul>
<li><p><i><b>Q.</b> Why does the abstract class have a constructor even though you cannot create object?</i><br>
<b>A:</b> Abstract class can only be extended by class and that class will have its own constructor and that constructor will have super (); which is calling constructor of abstract class. If the abstract class doesn't have constructor then the class extending that abstract class will not get compiled. Therefore, abstract classes have constructors.</p></li>
<li><p><i><b>Q.</b> Can the abstract class have concrete methods only [concrete method means method with body]?</i><br>
<b>A:</b> Yes.</p></li>
<li><p><i><b>Q.</b> If abstract class can have both types of methods [one having body and other without body] then what is use of those methods? </i><br>
<b>A:</b> We can use those methods by (1) extending abstract class or (2) making that method as a static so that we will not need to create an object.</p></li>
<li><p><i><b>Q.</b> How to call m2() which is concrete of abstract class?</i><br>
<b>A:</b> Make it as static and call as <code>Kiran.m2 (); //where Kiran is class name</code></p></li>
<li><p><i><b>Q.</b> Can abstract class extend ordinary class?</i><br>
<b>A:</b> Yes.</p></li>
</ul>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="AbstractandInterfaceDifference">
<div id="Div4" class="tablediv">
<h2 class="breadcrumb">Difference between Abstract Class & Interface </h2>
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tr>
<th class="center">Abstract Class </th>
<th class="center">Interface</th>
</tr>
<tr>
<td><ul><li>Constructor Present</li></ul></td>
<td><ul><li>No Constructor Present</li></ul></td>
</tr>
<tr>
<td><ul><li>Multiple inheritance not allowed in case of classes</li></ul></td>
<td><ul><li>Multiple inheritance allowed</li></ul></td>
</tr>
<tr>
<td><ul><li>It has abstract and concrete methods. To use this class we extend it</li></ul></td>
<td><ul><li>Methods are abstract only We implement interfaces in class</li></ul></td>
</tr>
<tr>
<td><ul><li>After extending abstract class, access specifiers of overridden method must be bigger than or same as that of access specifiers mentioned in method of abstract class</li></ul></td>
<td><ul><li>In implementing class all method must be public</li></ul></td>
</tr>
</table>
</div>
</div></div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#Interface" role="tab" data-toggle="tab">Interface</a></li>
<li role="presentation"><a href="#WhyInterface" role="tab" data-toggle="tab">Why Interface ?</a></li>
<li role="presentation"><a href="#AbstractClass" role="tab" data-toggle="tab">Abstract Class</a></li>
<li role="presentation"><a href="#AbstractandInterfaceDifference" role="tab" data-toggle="tab">Abstract & Interface Difference</a></li>
</ul>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="polymorphism-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="garbage-collection-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{ "@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Abstraction - Java",
 "alternativeHeadline": "What is abstraction in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java abstraction", 
 "keywords": "java abstraction, abstraction, abstract class, interface, abstraction in java, abstraction example", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/abstraction-in-java.php",
   "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "Abstraction is selecting data from a larger pool to show only the relevant details to the object.",
 "articleBody": "Abstraction is a process of hiding details about implementation from the user while letting them utilise the services or functions. It is done to simplify the user interface while hiding the complex processes."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
