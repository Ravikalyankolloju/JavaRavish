<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Java Development Kit - jdk1.8</title>
<meta name="description" content="jdk 1.8 - The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Java Development Kit - jdk1.8" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/features-of-jdk-1.8-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="jdk 1.8 - The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Java Development Kit - jdk1.8">
<meta name="twitter:description" content="jdk 1.8 - The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/features-of-jdk-1.8-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="features-of-jdk-1.8-in-java.php">
<span itemprop="name">What are features of jdk1.8?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Features and Enhancement in jdk1.8</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Features and Enhancement in jdk1.8</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<div>
<p>Before we look into Java Stream API Examples, let’s see why it was required. Suppose we want to iterate over a list of integers and find out sum of all the integers greater than 10. All the Java Stream API interfaces and classes are in the java.util.stream package.</p><br>
<div>
<p><b>Prior to Java 8, the approach for getting 1 to 10 sum, it would be:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>int addNumbersNojdk8(List< Integer > list) {
    int sum = 0;
    for (int number : list) {
	if (number > 10) {
	    sum = sum + number;
	}
    }
    return sum;
}
</code></pre>
</div><br>
<div>
<p><b>After java 8 it would be:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>int addNumbersWithjdk8(List< Integer > list) {
     return list.stream().filter(p->p>10).mapToInt(p -> p).sum();
    }
</code></pre>
</div><br>
<div>
<p>One more example where we will see use of IntStream. Let’s say we want to find a valid string having only alphabets.</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.jdk8.ex;
public class testStringWithAlphabets {
  public static boolean isStringOnlyAlphabet(String str){
  return ((str != null) && (!str.equals("")) && (str.chars().<b>allMatch</b>(Character::isLetter)));	
  }

  public static void main(String[] args) {
    System.out.println(isStringOnlyAlphabet("kiran"));
  }
}
</code></pre>
</div><br>
<p>In above program highlighted allMatch is from Stream package and chars method is added in jdk1.8.</p>
<p>Now we need to understand about functional programing. Java 8 supports functional programing where Stream API’s are majorly used.</p>
<p>Stream explanation will be discussed in later part of this chapter.</p>
</div><hr>
<div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Functional Programming</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">Functional Interface</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">Lambda expressions</a></li>
<li role="presentation"><a href="#Section4" role="tab" data-toggle="tab">default method</a></li>
<li role="presentation"><a href="#Section5" role="tab" data-toggle="tab">Static default method</a></li>
<li role="presentation"><a href="#Section6" role="tab" data-toggle="tab">Stream API</a></li>
<li role="presentation"><a href="#Section7" role="tab" data-toggle="tab">Predicate</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="Section1">
<div id="Div1">
<h2 class="breadcrumb">Functional programming</h2>
<div>
<p><b>Program with Functional Programming</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>public double CalWithFunctionalPrograming(double x,double y){
    return x * x + y * y;
}   
</code></pre>
</div><br>
<div>
<p><b>Program without Functional Programming</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>public double CalWithOutFunctionalPrograming(double x,double y) {
    double z=x+x; 
    double z1=y+y;
    double z2=z+z1;
    return z2;
   } 
</code></pre>
</div><br>
<p>Remember for functional programming:</p>
<ul>A programming style that treats computation as the evaluation of mathematical functions and avoids changing-state and mutable data.
<ul><li><code>F(x)=y or g(f(y(x))) = z</code></li></ul>
</ul>
<ul>Based on lambda calculus.( Some inputs are transformed to some output without modifying the input)
<ul><li>No iteration, No for loop, no variables</li></ul>
</ul>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section2">
<div id="Div2">
<h2 class="breadcrumb">Functional Interface</h2>
<p>Before proceeding, one more concept we need to understand is functional interface. An interface with exactly one abstract method is called <b>Functional Interface</b>.</p>
<p>@FunctionalInterface annotation is added so that we can mark an interface as functional interface.</p>
<p>It is not mandatory to use it, but it’s recommended to avoid addition of extra methods accidentally. If the interface is annotated with @FunctionalInterface annotation and we try to have more than one abstract method, it throws compiler error.</p>
<p>Java 8 Collections API has been rewritten and new Stream API is introduced that uses a lot of functional interfaces. Java 8 has defined a lot of functional interfaces in java.util.function Package. Some of the useful java 8 functional interfaces are Consumer, Supplier, Function and Predicate.</p>
<p>java.lang.Runnable is a great example of functional interface with single abstract method run().</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>@FunctionalInterface
public interface MyFirstFunctionalInterface {
    public void firstWork();
}
</code></pre>
</div><br>
<p>Also, since default methods are not abstract you’re free to add default methods to your functional interface as many as you like.</p><br>
<div>
<p><b>Below program will have compile time errors.</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.FunctionInterfaceEx;
@FunctionalInterface
public interface TestI {
	int add(int a, int b);
	int sub(int a, int b); // Not allowed
}
</code></pre>
</div><br>
<div>
<p><b>Try to understand below example :</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.FunctionInterfaceEx;
@FunctionalInterface
public interface TestI {
    int doOperation(int a, int b); //only one allowed

    default String multiply() { // have a body
	return null;
    }
    default String divide() { // have a body
        return null;
    }
    @Override
    public String toString(); 
    // toString can’t have body as it is from  object class
}
</code></pre>
</div><br>
<p>Summarizing below points about functional interface.</p>
<ul>
<li><p>Functional interface have only one abstract method, No need to count object class methods here [toString method in above example]</p></li>
<li><p>Can have any no of default methods [default methods with body]</p></li>
<li><p>Cannot have same name for default methods for those methods which are in object class [in above example toString method we just write without body]</p></li>
<li><p>@FunctionalInterface annotation is added so that we can mark an interface as functional interface which is not mandatory.</p></li>
</ul>
<p>After functional interface understanding we will try to understand Lambda expressions. Lambda expression facilitates functional programming, and simplifies the development a lot.</p>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section3">
<div id="Div3">
<h2 class="breadcrumb">Lambda expressions</h2>
<p><b>Syntax:</b></p>
<ul>
<i>Option 1:</i>
<ul>Input parameter - > expression on input parameters</ul>
</ul>
<ul>
<i>Option 2:</i>
<ul>Function Interface = Input parameter - > expression on input parameters</ul>
</ul>
<p>Lambda expressions are used primarily to define inline implementation of a functional interface, i.e., an interface with a single abstract method only.</p><br>
<div>
<div>
<p><b>How to use functional interface with lambda expressions</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.FunctionInterfaceEx;
@FunctionalInterface
public interface TestI {
    int doOperation(int a, int b);
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.FunctionInterfaceEx;
public class TestImpl {
    public static void main(String[] args) {
	TestI testI = (a, b) -> a + b;
          System.out.println(testI.doOperation(334, 556));
	TestI testISub = (a, b) -> a - b;
	  System.out.println(testISub.doOperation(334, 556));
    }
}
</code></pre>
</div>
</div><br>
<div>
<p><b>Question:</b> <i>What advantage you think we get from functional interface and lambda expression here?</i></p>
<p><b>Answer:</b> We can have different implementation of doOperation method inline here. Anonymous inner class can also do same but lot more code we needed to write here.</p>
<p>We will see different flavors to call this operation.</p>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code11" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code11" class="breadcrumb pretagcodebox">
<code>public class TestImpl {
    public static void main(String[] args) {
	// with type declaration
	  TestI add = (int a, int b) -> a + b;
	// without type declaration
	  TestI sub = (a, b) -> a - b;
          
	// with return statement along with curly braces
	  TestI mul = (a, b) -> {return a + b;};
	//without return statement and without curly braces
	  TestI divide= (a, b) -> a / b;
    }
}
</code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section4">
<div id="Div4">
<h2 class="breadcrumb">default method</h2>
<div>
<div>
<p><b>Example to use default method</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code12" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code12" class="breadcrumb pretagcodebox">
<code>public interface TestI {
    default String multiply() {
       return “I am in TestI mulitply”;
    }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code13" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code13" class="breadcrumb pretagcodebox">
<code>public class TestImplTest implements TestI {
    public static void main(String[] args) {
	TestImplTest tit = new TestImplTest();
	tit.multiply();
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     I am in TestI  mulitply
  </code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code14" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code14" class="breadcrumb pretagcodebox">
<code>// If TestImplTest wants to implements its own behavior then 
// we can implement it as below
public class TestImplTest implements TestI {
    String multiply() {
	return “I am in TestImplTest mulitply”;
    }
    public static void main(String[] args) {
	TestImplTest tit = new TestImplTest();
	tit.multiply(); // calling default method
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     I am in TestImplTest multiply
  </code></pre>
</div>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section5">
<div id="Div5">
<h2 class="breadcrumb">Static default method</h2>
<ul>
<li><p>We can have only static or default or abstract method in interfaces in jdk 8.</p></li>
<li><p>Static or default method will have a body</p></li>
<li><p>Only one keyword can be used at a time. Static or default</p></li>
<li><p>You can define static default methods in interface which will be available to all instances of class which implement this interface.</p>
<ul>
<li><p>This makes it easier for you to organize helper methods in your libraries; you can keep static methods specific to an interface in the same interface rather than in a separate class.</p></li>
<li><p>This enables you to define methods out of your class and yet share with all child classes.</p></li>
<li><p>They provide you a highly desired capability of adding a capability to number of classes without even touching their code. Simply add a default method in interface which they all implement.</p></li>
</ul>
</li>
</ul><br>
<div>
<div>
<p><b>Example to use static default method.</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code15" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code15" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.FunctionInterfaceEx;
public interface TestI {
    static String multiply() {
        return null;
    }
    default String divide() {
	return null;
    }
    @Override
	public String toString();
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code16" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code16" class="breadcrumb pretagcodebox">
<code>public class TestImplTest  {
    public static void main(String[] args) {
	TestI.multiply();//  calling static method
    }
}
</code></pre>
</div>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section6">
<div id="Div6">
<h2 class="breadcrumb">Stream API</h2>
<p>Majorly we use three methods in this- map, filter and collect method</p>
<div>
<p><b>See below example :</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code17" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code17" class="breadcrumb pretagcodebox">
<code>ArrayList< Employee  > alEmpList = new ArrayList<> ();
ArrayList < Integer > alEmp = (ArrayList< Integer >) 
      alEmpList.stream().map(age -> age.getAge()).filter(age -> age > 30).collect(Collectors.toList());
</code></pre>
</div>
<p>Explanation is ,</p>
<p>In this example we want to filter all age greater than 30.Expectation is output should be all numbers greater than 30.</p>
<ol>
<li><p><b>Stream Method :</b> It is converting array list of Employees into small chunks and making it ready for next processing.</p></li>
<li><p><b>Map method :</b> It is used to take out some elements from stream of collection. With example we will try to understand.</p>
<ol type="a">
<li><p>ArrayList contain Employee and Employee contains age if we use map on Stream of ArrayList then we get collection of age.</p></li>
<li><p>ArrayList contain Employee and Employee contains Phone and Phone contain mobile no as integer if we use map on Stream of ArrayList then we get collection of Phone then again use Map on Phone to get collection of mobile nos.</p></li>
</ol>
</li>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code18" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code18" class="breadcrumb pretagcodebox">
<code>alEmpList.stream().map(phone->phone.getPhone())
		  .map(mobileNo->mobileNo.getMobileNo())
		  .filter(mobileNo -> mobileNo > 30)
	          .collect(Collectors.toList());
</code></pre>
</div>
<li><p><b>Filter Method :</b> It is used to filters a data from map here we can use lambda expressions to make it short. We can pass predicates as well here see next section.</p></li>
<li><p><b>Collect Method :</b> It is used to collection all elements in a list.</p></li>
</ol><br>
<div>
<p>Below is complete example for all above methods :</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code19" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code19" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
 public class Employee {
    int age;
    String loc;
    String name;
    Phone phone;

  public Phone getPhone() {
	return phone;
  }
  public void setPhone(Phone phone) {
	this.phone = phone;
  }
  public Employee() {
  super();
  // TODO Auto-generated constructor stub
}
  public Employee(int age, String loc, String name) {
	super();
	this.age = age;
	this.loc = loc;
        this.name = name;
  }
  public Employee(int age, String loc, String name, Phone phone) {
  super();
  this.age = age;
  this.loc = loc;
  this.name = name;
  this.phone = phone;
}

  public int getAge() {
	return age;
  }
  public void setAge(int age) {
	this.age = age;
  }
  public String getLoc() {
	return loc;
  }
  public void setLoc(String loc) {
	this.loc = loc;
  }
  public String getName() {
	return name;
  }
  public void setName(String name) {
	this.name = name;
  }
  
  @Override
    public String toString() {
       return "Employee [age=" + age + ", loc=" + loc + ", name=" + name + ", phone=" + phone + "]";
    }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code20" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code20" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
public class Phone {
    int mobileNo;

    public int getMobileNo() {
	return mobileNo;
    }
    public void setMobileNo(int mobileNo) {
	this.mobileNo = mobileNo;
    }
    @Override
    public String toString() {
	return "Phone [mobileNo=" + mobileNo + "]";
    }
}
</code></pre>
</div><br>
<div>
<p>Above classes were just POJO now we will see how we can do different operations with collections</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code21" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code21" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
public class MapFilterCollectEx {
    public static ArrayList< Employee > createEmployees(){
	ArrayList< Employee > alEmp = new ArrayList<>();
  Phone ph=new Phone();
    ph.mobileNo=963720;
	alEmp.add(new Employee(20, "Pune", "Kiran",ph));
  Phone ph1=new Phone();
    ph1.mobileNo=889574;
	alEmp.add(new Employee(46, "Nagpur", "Kiran1",ph1));
  Phone ph2=new Phone();
    ph2.mobileNo=986895;
	alEmp.add(new Employee(34, "Mumbai", "Kiran2",ph2));
	return alEmp;
    }
    // return all emp of more age than 30
    public static ArrayList< Employee > allEmpAge() {
	ArrayList< Employee > alEmpList = createEmployees();
	alEmpList = (ArrayList< Employee >)   
        alEmpList.stream().filter(finalAge -> finalAge.getAge()>30)
			.collect(Collectors.toList());
	return alEmpList;
    }

    // return all elements
    public static List< Integer > allEmpMobileNo() {
	ArrayList< Employee > alEmpList = createEmployees();
	List< Integer > alEmp = alEmpList.stream().map
          (phone ->phone.getPhone()).map(mobileNo -> mobileNo.getMobileNo()).filter(mobileNo -> 
           mobileNo > 30).collect(Collectors.toList());
	return alEmp;
    }

    // return all emp of more age than 30
    public static ArrayList< Integer > allEmpAgeGreaterThan30() {
	ArrayList< Employee > alEmpList = createEmployees();
	ArrayList< Integer > alEmp = (ArrayList< Integer >)   alEmpList.stream().map(age -> age.getAge())
	   .filter(age -> age > 30).collect(Collectors.toList());
	return alEmp;
    }

public static void main(String[] args) {
    for (int age : allEmpAgeGreaterThan30()) {
	System.out.println(age);
    }
    for (Employee empAge : allEmpAge()) {
	System.out.println(empAge.getAge());
    }
    for (int empMobNo : allEmpMobileNo()) {
	System.out.println(empMobNo);
    }
  }
}
</code></pre>
</div><br>
<div>
<p>Above classes were just POJO now we will see how we can do different operations with collections</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code22" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code22" class="breadcrumb pretagcodebox">
<code>int addNumbersWithjdk8(List< Integer > list) {
    return list.stream()
               .filter(p->p>10)
               .mapToInt(p -> p).sum();
    }
List< Integer > getListGreaterthan10(List< Integer > list){
    return list.stream()
               .filter(p->p>10)
               .collect(Collectors.toList());
    }
</code></pre>
</div>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section7">
<div id="Div7">
<h2 class="breadcrumb">Predicate</h2>
<div>
<p><b>How to design predicate :</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code23" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code23" class="breadcrumb pretagcodebox">
<code>public static Predicate< Employee > getAllOldEmp() {
    return p -> p.getAge() > 30;
    }

public static Predicate< Employee > getAllOldEmp1() {
    return p -> p.getAge() > 45;
    }
</code></pre>
<p>In this case P can be anything may be x or y or z. </p>
<p>P indicates Employee in this case. Automatically it behaves like employee object.</p>
</div><br>
<div>
<p><b>Now to filter employees how I can use above predicate?</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code24" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code24" class="breadcrumb pretagcodebox">
<code>public static List< Employee > filterEmployees(List< Employee > employees, Predicate< Employee > predicate) {
            
       return employees.stream().filter (getAllOldEmp())
                         .collect (Collectors.toList ());
  }
</code></pre>
<p>Above method filters employee as per predicates provided.</p>
</div><br>
<div>
<p><b>Some more simple examples of predicate</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code25" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code25" class="breadcrumb pretagcodebox">
<code>public class PredicateExample1 { 

public static void main(String[] args) { 
    //Predicate String 
    Predicate< String > predicateString =
    s -> { return s.equals("Hello"); };
    System.out.println(predicateString.test("Hello")); 
    System.out.println(predicateString.test("Hello World")); 

    //Predicate integer 
     Predicate< Integer > predicateInt =i -> { return i > 0; }; 
    System.out.println(predicateInt.test(5)); 
    System.out.println(predicateInt.test(-5));
  } 
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     true
     false
     true
     false

</code></pre>
</div></div></div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Functional Programming</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">Functional Interface</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">Lambda expressions</a></li>
<li role="presentation"><a href="#Section4" role="tab" data-toggle="tab">default method</a></li>
<li role="presentation"><a href="#Section5" role="tab" data-toggle="tab">Static default method</a></li>
<li role="presentation"><a href="#Section6" role="tab" data-toggle="tab">Stream API</a></li>
<li role="presentation"><a href="#Section7" role="tab" data-toggle="tab">Predicate</a></li>
</ul>
</div></div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="features-of-jdk-1.7-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="multithreading-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "jdk 1.8 - Java",
 "alternativeHeadline": "What are the features and enhancements in jdk 1.8 in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java jdk 1.8", 
 "keywords": "java jdk 1.8, jdk 1.8, jdk 1.8 in java, functional programming, functional interface, lambda expressions, default method, stream api, predicate, static default method", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/features-of-jdk-1.8-in-java.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "The JDK includes tools useful for developing and testing programs written in the Java programming language and running on the JavaTM platform.",
 "articleBody": "Before we look into Java Stream API Examples, let’s see why it was required. Suppose we want to iterate over a list of integers and find out sum of all the integers greater than 10. All the Java Stream API interfaces and classes are in the java.util.stream package."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
