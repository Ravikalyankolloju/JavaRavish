<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Strings in Java</title>
<meta name="description" content="Generally, String is a sequence of characters. But in java, String is an object that represents a sequence of characters. String class is used to create string object.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Strings in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/strings-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Generally, String is a sequence of characters. But in java, String is an object that represents a sequence of characters. String class is used to create string object.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Strings in Java">
<meta name="twitter:description" content="Generally, String is a sequence of characters. But in java, String is an object that represents a sequence of characters. String class is used to create string object.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/strings-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="strings-in-java.php">
<span itemprop="name">What are Strings?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">String, StringBuffer, StringBuilder</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">String, StringBuffer, StringBuilder</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<ul>
<li><p>Generally, String is a sequence of characters. But in java, String is an object that represents a sequence of characters. String class is used to create string object.</p></li>
<li><p><b>String</b> can be defined as a ‘sequence of characters that is treated as a single data item and initialized by null’ like <code>String x = null;</code></p></li>
<li><p>String class is an immutable class which is present inside java.lang package. Immutable means it cannot be changed.</p></li>
<li><p>Now, the question arises as to why the String class is immutable. Memory in Java is divided into three parts, Heap, Stack and String Pool. String is so important in java that it has its own dedicated memory location. What String pool does it that whenever a string gets repeated, it does not allocate new memory for that string. Instead, it uses the same string by making a reference to it, thereby saving memory.</p></li>
<li><p>We can create String object in two ways : </p>
<ol>
<li><code>String s1 = "javabykiran";</code></li>
<li><code>String s2 = new String("javabykiran");</code></li>
</ol>
</li><br>
<li><p>Internally, String class uses the String Pool concept. In String pool, we do not have duplicate strings.<br>
<ul>For example:
<ul><code>String s1 = "javabykiran";</code></ul>
<ul><code>String s2 = "javabykiran";</code> //will not create new instance.</ul><br>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/strings_img1.webp" alt="string pool in java" title="String pool Example 1"></div>
</ul><br>
<p>In the above example, only one instance will be created. First, JVM will not find any string with the value "javabykiran" in string constant pool, so it will create a new instance. After that, for s2, it will find the string with the value "javabykiran" in the pool. This will not create a new instance but will return the reference to the same instance of s1.</p>
</li>
<li><p>In java, there are two equals () methods at two places. One in Object class and another in String class.</p></li>
<li><p>The equals () method of object will check reference of objects i.e. addresses. Whereas equals method of String will check contents of string with character sequence.</p></li>
</ul>
<hr>
<div class="text-center">

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Why is String called immutable?</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">StringBuffer</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">String vs StringBuffer</a></li>
<li role="presentation"><a href="#Section4" role="tab" data-toggle="tab">When to use Strings?</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="Section1">
<div id="Div1">
<h2 class="breadcrumb">Why is String called immutable?</h2>
<p>
<ul>
<li><p>In java, string objects are immutable. Immutable simply means unmodifiable or unchangeable. Once string object is created, its data or state can't be changed but a new string object is created. <br>
Example: Consider the above example of s1 and s2. Now, <code>String s3 = s1 + s2;</code> // s3 will be "javabykiranjavabykiran”.</p></li>
<li><p>In this case, s1 and s2 will not change and still exist after concatenation ('+' sign is overloaded in java, if it gets digits it adds two numbers and if strings then it concatenates).</p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/strings_img2.webp" alt="string pool example in java" title="String pool Example 2"></div>
</li>
</ul>
</div>
<div>
<h4>What are the advantages of String Pool?</h4>
<p><b>The advantages of a String Pool are stated below:</b>
<ul>
<li>Resource management</li>
<li>Not a heap memory</li>
<li>Memory efficient</li>
<li>Reusability</li>
<li>Duplicate objects are not allowed</li>
</ul>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>String st1="jbk"; 
String st2="pune"; 
String st3="kiran";    
    st1=st2;
    st3=st1;
  System.out.println(st1);    
  System.out.println(st2); 
  System.out.println(st3);
</code></pre>
</div><br>
<p>When you create a String object without a new operator, the following task happens</p>
<ul>
<li><p>String literal will be taken and verified in string constant pool.</p></li>
<li><p>If literal is not available in pool then a new object will be created in the pool and that address will be assigned to reference variable.</p></li>
<li><p>If string literal is available in the pool then the available object address will be assigned to reference variable.</p></li>
</ul>
<div>
<div>
<p><b>Program - Lab1</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran; 
class A {
 String s;
   public A(String s){    
     this.s = s;
   }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>
public class StringLab1 {
  public static void main(String[] args){
    A a = new A("kiran"); 
    A a1 = new A("jbk");
    A a2 = new A("kiran"); 
    String x = "javabykiran"; 
    String y = "jbk";
    String z = new String("javabykiran");
  //guess true or false without seeing output
    System.out.println(x==z);
    System.out.println(y==z);
    System.out.println(x.equals(y)); 
    System.out.println(x==y); 
    System.out.println(x.equals(z)); 
    System.out.println(a==a); 
    System.out.println(a==a1); 
    System.out.println(a1==a2);
    System.out.println(a.equals(a2)); 
    System.out.println(a1.equals(y));
   }
}
</code></pre>
</div>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     false
     false 
     false 
     false 
     true 
     true 
     false
     false 
     false
     false
  </code></pre>
<p>The "==" operator in Java is used to compare two objects. It checks to see if the objects refer to the same place in memory. In other words, it checks to see if the two object names are basically references to the same memory location.</p>
</div><br>
<div>
<p><b>Program -Lab2</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>package com;
public class StringLab2 {
    public static void main(String[] args) { 
      String s1 = "Hello"; // String literal 
      String s2 = "Hello"; // String literal 
      String s3 = s1; // same reference
      String s4 = new String("Hello"); // String object 
      String s5 = new String("Hello"); // String object
    System.out.println(s1 == s1); // true,same pointer
    System.out.println(s1 == s2); // true,s1 and s2 share          
                                  //storage in pool
    System.out.println(s1 == s3); //true, s3 is assigned same 
                                  //pointer as s1
    System.out.println(s1.equals(s3)); // true, same contents
    System.out.println(s1 == s4); //false, different pointers 
      s1.equals(s4); // true, same contents
    System.out.println(s4 == s5); // false, different pointers in 
                                  //heap
    System.out.println(s4.equals(s5)); // true, same contents
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     true 
     true
     true 
     true
     false 
     false
     true
  </code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section2">
<div id="Div2">
<h2 class="breadcrumb">StringBuffer</h2>
<ul>
<li><p>In java, StringBuffer is a class present in java.lang package. It provides the same functionality as String class but there are also some additional features in StringBuffer class.</p></li>
<li><p>It is slower than String as it has synchronised methods, so it is a Thread-safe class.</p></li>
<li><p>The String class is immutable, i.e objects are unmodifiable, whereas StringBuffer class provides mutable sequence of characters. A stringBuffer is like a String, but can be modified.</p></li>
<li><p>The principal operations on a StringBuffer are append() and insert() methods, which are
overloaded so as to accept data of any type. The append method always adds these characters
at the end of the buffer; the insert method adds the characters at a specified point. For example,
if "s" refers to a String Buffer object whose current contents are "java", then the method call s.append("kiran") would cause the String Buffer to contain "javakiran", whereas z.insert(4, "by") would alter the String Buffer to contain “javabykiran”.
</p></li>
<li>StringBuffer class has capacity concept. It always carries 16 extra reserve spaces for characters.<br>
Since the release of JDK 5, this class has been supplemented with an equivalent class designed for use by a multiple thread, StringBuilder. The StringBuilder class should generally be used in preference to this one, as it supports all of the same operations but it is faster as it has non-synchronised methods.</li>
</ul><br>
<div>
<div>
<p><b>Lab Examples:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>package com.javabykiran;
 //use of append method
public class StringBufferLab1 {
  public static void main(String[] args) { 
     StringBuffer sb = new StringBuffer("java");
     sb.append("bykiran"); //now original String is changed 
     System.out.println(sb); //will print javabykiran
  }
}
</code></pre>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>//using insert method 
package com.javabykiran;
  public class StringBufferLab2 {
   public static void main(String[] args) {    
     StringBuffer sb = new StringBuffer("java");
     sb.insert(4,"bykiran");//now original String is changed 
     System.out.println(sb); //will print javabykiran
 }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>//default capacity
package com.javabykiran;
public class StringBufferLab3 {
   public static void main(String[] args) {   
     StringBuffer sb = new StringBuffer();
     System.out.println(sb.capacity()); //default capacity is 16
     sb.append("java");   
     System.out.println(sb.capacity());// again will be 16 
     sb.append("is my best lang"); 
                                     //exceeds 16 
     System.out.println(sb.capacity());//so now (16*2+2)
 }
}
</code></pre>
</div>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     16
     16
     34
  </code></pre>
</div>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section3">
<div id="Div3">
<h2 class="breadcrumb">String vs StringBuffer</h2>
<div class="tablediv">
<table class="table-bordered table-responsive-xl table" style="width:100%;">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tr>
<th class="center">String</th>
<th class="center">StringBuffer</th>
</tr>
<tr>
<td>
1. It is an immutable class, i.e. its objects cannot be changed.<br>
Example:<br>
<code>package com; <br>
public class AA { <br>
public static void main(String[] args){ <br>
String s = new String("java"); <br>
s.concat("bykiran"); <br>
System.out.println(s);<br>
} <br>
} <br>
</code>
</td>
<td>
1. It is a mutable class, i.e its objects can be changed only once.<br>
Example:<br>
<code>package com; <br>
public class AA { <br>
public static void main(String[] args) { <br>
StringBuffer sb =newStringBuffer("java"); <br>
sb.append("bykiran"); <br>
System.out.println(sb); <br>
}<br>
}<br>
</code>
</td>
</tr>
<tr>
<td>2. String object can be created in two ways:
<ol type="i">
<li>Using new operator</li>
<li>Without using new operator</li>
</ol>
</td>
<td>2. StringBuffer object can be created in only one way
<ol type="i">
<li>Using new operator</li>
</ol>
</td>
</tr>
<tr>
<td>3. String object will use String constant pool.</td>
<td>3. In StringBuffer object there is no concept of String constant pool.</td>
</tr>
</table>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="Section4">
<div id="Div4">
<h2 class="breadcrumb">When to use String, StringBuffer and StringBuilder?</h2>
<p>The appropriate class should be used according to the given requirements. Study the points given below:
<ul>
<li><p>String class should be used when the content is fixed and will not change frequently.</p></li>
<li><p>StringBuffer should be used when the content is not fixed and frequently changes, but thread safety is required.</p></li>
<li><p>StringBuilder should be used when the content is not fixed and frequently changing and thread safety is not required.</p></li>
<li><p>String is immutable, whereas StringBuffer and StringBuilder are mutable.</p></li>
</ul>
</div></div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#Section1" role="tab" data-toggle="tab">Why is String called immutable?</a></li>
<li role="presentation"><a href="#Section2" role="tab" data-toggle="tab">StringBuffer</a></li>
<li role="presentation"><a href="#Section3" role="tab" data-toggle="tab">String vs StringBuffer</a></li>
<li role="presentation"><a href="#Section4" role="tab" data-toggle="tab">When to use Strings?</a></li>
</ul>
</div></div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="arrays-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="features-of-jdk-1.5-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Strings - Java",
 "alternativeHeadline": "What are strings in java?",
 "image": "https://www.jbktutorials.com/images/java/strings_img1.webp",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java strings", 
 "keywords": "java strings, strings, strings in java, string buffer, string builder, string vs string buffer", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/strings-in-java.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "String is an object that represents a sequence of characters.",
 "articleBody": "String can be defined as a sequence of characters that is treated as a single data item and initialized by null like String x = null; String class is an immutable class which is present inside java.lang package. Immutable means it cannot be changed."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
