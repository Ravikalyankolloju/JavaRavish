<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Operators in Java</title>
<meta name="description" content="Java Operator is a special type of symbol that is used to perform operations.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Operators in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/operators-in-java-language.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Java Operator is a special type of symbol that is used to perform operations.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Operators in Java">
<meta name="twitter:description" content="Java Operator is a special type of symbol that is used to perform operations.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/operators-in-java-language.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="introduction-to-java.php">
<span itemprop="name">Core Java</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Java Language- Operators</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Operators in Java</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<a href="java-language.php" class="btn btn-outline-danger">&larr; Back to Java Language Chapter</a>
<hr>
<p><b>Operators</b> are special symbols that perform operations.</p>
<hr>
<div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#ArithmeticOperator" role="tab" data-toggle="tab">Arithmetic Operator</a></li>
<li role="presentation"><a href="#RelationalOperator" role="tab" data-toggle="tab">Relational Operator</a></li>
<li role="presentation"><a href="#LogicalOperator" role="tab" data-toggle="tab">Logical Operator</a></li>
<li role="presentation"><a href="#AssignOperator" role="tab" data-toggle="tab">Assign Operator</a></li>
<li role="presentation"><a href="#IncrementDecrementOperator" role="tab" data-toggle="tab">Increment/Decrement Operator</a></li>
<li role="presentation"><a href="#TernaryOperator" role="tab" data-toggle="tab">Ternary Operator</a></li>
<li role="presentation"><a href="#BitwiseOperator" role="tab" data-toggle="tab">Bitwise Operator</a></li>
<li role="presentation"><a href="#NewOperator" role="tab" data-toggle="tab">New Operator</a></li>
<li role="presentation"><a href="#DotOperator" role="tab" data-toggle="tab">Dot Operator</a></li>
<li role="presentation"><a href="#EqualityOperator" role="tab" data-toggle="tab">Equality</a></li>
<li role="presentation"><a href="#OperatorPrecedence" role="tab" data-toggle="tab">Operator Precedence</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="ArithmeticOperator">
<h2 class="breadcrumb">Arithmetic Operator (+, -, *, /,%)</h2>
<ul>
<li><p>Arithmetic operation from arithmetic expression (a+b, a/b)</p></li>
<li><p>The result of arithmetic expression is integer literal or floating point literal.</p></li>
</ul>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
  public class Lab3Test {
    public static void main(String[] args) { 
    byte b1 = 10;
    byte b2 = b1 + 2;     // error type mismatch
    System.out.println(b2); 
    float f1 = 9.9f;
    float f2 = f1 + 10.0; // error type mismatch
    System.out.println(f1); 
    System.out.println(f2);
   } 
}
</code></pre>
</div><hr>
<h4>Modifying</h4>
<ul><code>byte b2=b1+2 <b>to</b> byte b2=(byte)(b1+2); // type casting<br>
float f2=f1+10.0 <b>to</b> float f2=(float)(f1+10.0);</code></ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
  public class Lab3Test {
    public static void main(String[ ] args) { 
    byte b1 = 10;
    //byte b2 = b1 + 2; 
    byte b2=(byte)(b1+2); 
    System.out.println(b2); 
    float f1 =9.9f;
    //float f2 = f1 + 10.0;
    float f2 = (float)(f1 + 10.0); //  type casting
    System.out.println(f1); 
    System.out.println(f2);
   }  
}
</code></pre>
</div><hr>
<h4>Remember the chart drawn below :</h4>
<div class="tablediv">
<table class="table-bordered table-fixed center" style="width:100%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<tr>
<th>Type <br>byte</th> <th>Operator +</th> <th>Type <br>byte</th> <th>Result Type <br>byte</th>
</tr>
<tr>
<td>byte</td> <td>+</td> <td>short</td> <td>Byte</td>
</tr>
<tr>
<td>byte</td> <td>+</td> <td>int</td> <td>Int</td>
</tr>
<tr>
<td>byte</td> <td>+</td> <td>long</td> <td>Long</td>
</tr>
<tr>
<td>byte</td> <td>+</td> <td>float</td> <td>Float</td>
</tr>
<tr>
<td>byte</td> <td>+</td> <td>double</td> <td>Double</td>
</tr>
<tr>
<td>short</td> <td>+</td> <td>short</td> <td>Short</td>
</tr>
<tr>
<td>short</td> <td>+</td> <td>int</td> <td>Int</td>
</tr>
<tr>
<td>short</td> <td>+</td> <td>long</td> <td>Long</td>
</tr>
<tr>
<td>short</td> <td>+</td> <td>float</td> <td>Float</td>
</tr>
<tr>
<td>short</td> <td>+</td> <td>double</td> <td>Double</td>
</tr>
<tr>
<td>int</td> <td>+</td> <td>int</td> <td>Int</td>
</tr>
<tr>
<td>int</td> <td>+</td> <td>long</td> <td>long</td>
</tr>
</table>
</div><hr>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
  public class Lab4Test {
    public static void main(String[] args) { 
      int a=0/10;
      System.out.println(a);  //0
      // int b=10/0;
      // java.lang.ArithmeticExcepton:/by zero
      // system.out.println(b);   
      double dl = 0.0/10.;         
      System.out.println(dl); //0.0 
      double d2= 10.0/00;
      System.out.println(d2);   //Infinity 
      int x=10%3;
      System.out.println(x);    //1 
      double d3=10.0/10.0; 
      System.out.println(d3);   //1.0 
      int x1=10; 
      System.out.println(x1);   //10 
      double d=10.0%1.0; 
      System.out.println(d);    //0.0
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     0
     0.0
     Infinity 1
     1.0
     10
     0.0
    </code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="RelationalOperator">
<h2 class="breadcrumb">Relational Operator (>, >=, <, <=)</h2>
<p>It is a form of relational expression whose result is the ‘boolean’ value a < b.</p>
</div>
<div role="tabpanel" class="tab-pane fade" id="LogicalOperator">
<h2 class="breadcrumb">Logical Operator (&&, ||, \)</h2>
<p>A Logical operator forms logical expression, which is a combination of one or more relational expressions</p>
<ul>
<li><p>(a>b) && (a>c)</p></li>
<li><p>(a>b) || (a>c)</p></li>
</ul>
<div class="tablediv">
<p>The result of logical expression is based on Boolean values, which in turn is based on the following table:</p>
<table class="table-bordered table-fixed center" style="width:100%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<tr>
<th>A</th> <th>B</th> <th>A&&B [and]</th> <th>A||B [OR]</th>
</tr>
<tr>
<td>T</td> <td>T</td> <td>T</td> <td>T</td>
</tr>
<tr>
<td>T</td> <td>F</td> <td>F</td> <td>T</td>
</tr>
<tr>
<td>F</td> <td>T</td> <td>F</td> <td>T</td>
</tr>
<tr>
<td>F</td> <td>F</td> <td>F</td> <td>F</td>
</tr>
</table>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="AssignOperator">
<h2 class="breadcrumb">Assign Operator (=, +=, -=, *=, /=, &=)</h2>
<ul>
<b>Syntax:</b>
<ul>destination_var = source_var;</ul><br>
<b>Example:</b>
<ul>
<code>int x = 10+9.9; // error - Type mismatch: cannot convert from double to int <br>
System.out.println(10+9.9); //ok <br>
byte b = 10; // ok <br>
int x = b; //ok
</code>
</ul>
</ul><hr>
<h4>There are two types of casting:</h4>
<ul>
<li><p>Implicit casting</p></li>
<li><p>Explicit casting</p></li>
</ul>
<p><b>Implicit casting :</b> When the destination is bigger than the source, then conversion happens automatically, which is called implicit casting. Another term for it is widening.</p>
<p><b>Explicit casting :</b> When the destination is smaller than the sources, then you have to do explicit casting or narrowing</p>
<ul>
<b>Syntax:</b>
<ul>destination_var = (destination type)source_var;</ul><br>
<b>Example:</b>
<ul>
<code>int x = 10+9.9; // error-Type mismatch: cannot convert from double to int<br>
int x1=(int)10+9.9; // error-Type mismatch: cannot convert from double to int <br>
int x2=(int) (10+9.9); // ok <br>
int x3=10+(int)9.9; // ok
</code>
</ul>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="IncrementDecrementOperator">
<h2 class="breadcrumb">Increment/Decrement Operator (++, --)</h2>
<p>It is a type of arithmetic operator. It allows you to add and subtract 1 from variables.</p>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
class Lab5 {
   public static void main(String[] args) { 
    int x = 10;
    System.out.println(x);  // o/p 10
    int a = ++x;  // prefix increment
    int b = --x;  // prefix decremennt 
    int c = x++;  // postfix increment
    int d = x--;  // postfix decrement
    int e = ++x;  // prefix increment
    int f = ++x;  // prefix increment
    int g = x++;  
    System.out.println(a);  //	11	11	11	
    System.out.println(b);  //	10	10	10	
    System.out.println(c);  //	10	11	10	
    System.out.println(d);  //	11	11	11	
    System.out.println(e);  //	11	12	11	
    System.out.println(f);  //	12	12	12	
    System.out.println(g);  //	12	13	12	
   }				
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      10
      11
      10
      10
      11
      11
      12
      12

</code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="TernaryOperator">
<h2 class="breadcrumb">Ternary Operator (?:)</h2>
<ul>
<li><p>Ternary operator is used to perform simple conditional checking</p>
<ul><b>Syntax :</b> (Conditional expression)? s1:s2;</ul></li><br>
<li><p>First, the given expression is evaluated. If the expression is true, then s1 will be executed. If the expression is false, then s2 will be executed.</p></li>
</ul><hr>
<div>
<h4><b>Question :</b> Write a program to read the two numbers from command line and find the minimum and maximum number.</h4>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
  public class Lab6 {
    public static void main(String[] as) { 
        int a = Integer.parseInt(as[0]);
        int b = Integer.parseInt(as[1]); 
        int min=(a < b) ? a:b;
        int max=(a > b) ? a:b;
        System.out.println("Min :: "+min);
        System.out.println("Max :: "+max);
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      20
      1) javaLab6
      // ArrayIndexOutOfBoundsException:0
      2) java Lab6 10 [when we pass single parameter below error will occur]
      // ArrayIndexOutOfBoundException:1
      3) java Lab6 10 20 [output would be] 
      4) Min :: 10
         Max :: 20

</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
public class Lab7 {
  public static void main(String[] args) { 
    int a=10;
    int b=20;
    //int min=(a+b) ? a:b; // error-Type mismatch: cannot convert  
                           // from int to boolean
    int min=(a>b) ? a:b;
    System.out.println(min);
    }
  }
  /*error: incompatible types 
    found: int 
    required: boolean
    int min= (a+b) ? a:b; 
  */
</code></pre>
</div><hr>
<div>
<h4><b>Question :</b> Write a program to take three numbers from the command line and find the minimum and maximum.</h4>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>
package com.javabykiran.basics; 
public class Lab8 {
    public static void main(String[] a5) { 
     int a =Integer.parseInt(a5[0]);
     int b =Integer.parseInt(a5[1]); 
     int c =Integer.parseInt(a5[2]);
     int max=(a > b) ? (a > c) ? a:c: (b > c) ? b:c;
     int min=(a < b) ? (a < c) ? a:c: (b < c) ? b:c;
     System.out.println("Min:" +min); 
     System.out.println("Max:" +max);
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      Min: 5
      Max 15

</code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="BitwiseOperator">
<h2 class="breadcrumb">Bitwise Operator (&, \, ^)</h2>
<p>Bitwise operator acts on individuals bits of given numbers.</p>
<div class="tablediv">
<table class="table-bordered table-fixed center" style="width:100%;">
<colgroup>
<col style="width: 10%" />
<col style="width: 50%" />
<col style="width: 40%" />
</colgroup>
<tr>
<td>1.</td> <td>Left shift operator</td> <td><<</td>
</tr>
<tr>
<td>2.</td> <td>Right shift operator</td> <td>>></td>
</tr>
<tr>
<td>3.</td> <td>Bitwise AND</td> <td>&</td>
</tr>
<tr>
<td>4.</td> <td>Bitwise OR</td> <td>|</td>
</tr>
<tr>
<td>5.</td> <td>Bitwise XOR</td> <td>^</td>
</tr>
<tr>
<td>6.</td> <td>Bitwise NOT</td> <td>~</td>
</tr>
</table>
</div><br>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
  public class Lab10Test {
    public static void main(String[] args) { 
      int a = 2; // 0010
      int b = 4; // 0100
      System.out.println("value of a before:"+a); 
      System.out.println("value of b before:"+b);
      // bitwise unary complement operator (~) 
      System.out.println("value of a after negation: " + ~a); //-3
      System.out.println("value of a after negation: " + ~b); //-5

      // bitwise AND operator & 
      System.out.println("Result of a&b	is:"+(a & b)); //0
      // bitwise OR operator | 
      System.out.println("Result of a|b is:"+(a| b)); // 6
      // bitwise XOR operator ^ 
      System.out.println("Result of a^b is:"+(a^ b)); // 6
      int no = 8; // 0000 1000 
      System.out.println("Original number:"+no); // 8
      // left shifting bytes with 1 position
      no = no << 1; // should be 16 i.e. 0001 0000
      // equivalent of multiplication of 2 
      System.out.println("value after left shift:" + no); //16 
      no = -8;
      //right shifting bytes with sign 1 position 
      no=no>>1; //should be 16 i.e.00010000
      // equivalent of division of 2 
      System.out.println("value after right shift with sign:"+no); //-4
      no = -8;
      //right shifting bytes without sign 1 position no=no>>>1; 
      //should be 16 i.e.00010000
      // equivalent of division of 2 
      System.out.println("value after right shift with sign: " + no); 
                                         // 2147483644
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      38
      76
      9
      6
      15
      9
      -16
      -501
      130
      32
      -1

</code></pre>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="NewOperator">
<h2 class="breadcrumb">New Operator (new)</h2>
<p>A new operator is used to create an object of a given class.</p>
<ul>
<b>Example:</b>
<ul><code>Hello h = new Hello();</code></ul>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="DotOperator">
<h2 class="breadcrumb">Dot Operator</h2>
<p>A dot operator is used to refer members of a class using class name or object.</p>
<ul>
<b>Example:</b>
<ul><code>Hello h = new Hello(); <br> h.a; <br> h.show();</code></ul>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="EqualityOperator">
<h2 class="breadcrumb">Equality</h2>
<div class="tablediv">
<table class="table-bordered table-fixed center" style="width:100%;">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tr>
<td>bitwise AND</td> <td>&</td>
</tr>
<tr>
<td>bitwise exclusive OR</td> <td>^</td>
</tr>
<tr>
<td>bitwise inclusive OR</td> <td>|</td>
</tr>
<tr>
<td>logical AND</td> <td>&&</td>
</tr>
<tr>
<td>logical OR</td> <td>||</td>
</tr>
<tr>
<td>ternary</td> <td>?</td>
</tr>
<tr>
<td>assignment</td> <td>=++-=*=/=%=&=^=|=<=>=</td>
</tr>
</table>
</div><br>
</div>
<div role="tabpanel" class="tab-pane fade" id="OperatorPrecedence">
<h2 class="breadcrumb">Operator Precedence</h2>
<div class="tablediv">
<table class="table-bordered table-fixed center" style="width:100%;">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tr>
<th>Operator</th> <th>Precedence</th>
</tr>
<tr>
<td>Post fix</td> <td>expr ++ expr --</td>
</tr>
<tr>
<td>Unary</td> <td>~ ! +!expr -- expr+expr-expr</td>
</tr>
<tr>
<td>Multiplicative</td> <td>* / %</td>
</tr>
<tr>
<td>Additive</td> <td>+ -</td>
</tr>
<tr>
<td>Shift</td> <td>< < > >>>></td>
</tr>
<tr>
<td>Relational</td> <td>< > <=> = instance of</td>
</tr>
</table>
</div><br>
<p><b>Note:</b> <i>no sizeof operator in java</i></p>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
 public class Lab11 {
   public static void main(String[] args) { 
   double a=19.9;
   //System.out.println(a>>1); //error- operator << 
                               //cannot be applied to double
   //int x = 09;   //error - The literal Octal 09 (digit 9)
                   //of type int is out of range
   //System.out.println(x);   // integer number too large :09
   int y = 0101;
   System.out.println(y); //65 - octal conversion
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      65

</code></pre>
</div>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#ArithmeticOperator" role="tab" data-toggle="tab">Arithmetic Operator</a></li>
<li role="presentation"><a href="#RelationalOperator" role="tab" data-toggle="tab">Relational Operator</a></li>
<li role="presentation"><a href="#LogicalOperator" role="tab" data-toggle="tab">Logical Operator</a></li>
<li role="presentation"><a href="#AssignOperator" role="tab" data-toggle="tab">Assign Operator</a></li>
<li role="presentation"><a href="#IncrementDecrementOperator" role="tab" data-toggle="tab">Increment/Decrement Operator</a></li>
<li role="presentation"><a href="#TernaryOperator" role="tab" data-toggle="tab">Ternary Operator</a></li>
<li role="presentation"><a href="#BitwiseOperator" role="tab" data-toggle="tab">Bitwise Operator</a></li>
<li role="presentation"><a href="#NewOperator" role="tab" data-toggle="tab">New Operator</a></li>
<li role="presentation"><a href="#DotOperator" role="tab" data-toggle="tab">Dot Operator</a></li>
<li role="presentation"><a href="#EqualityOperator" role="tab" data-toggle="tab">Equality</a></li>
<li role="presentation"><a href="#OperatorPrecedence" role="tab" data-toggle="tab">Operator Precedence</a></li>
</ul>
</div><hr>
<a href="java-language.php" class="btn btn-outline-danger">&larr; Back to Java Language Chapter</a>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item disabled">
<a class="page-link btn-outline-primary" href="#">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Operators - Java",
 "alternativeHeadline": "What are operators in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  }, 
 "genre": "java operators", 
 "keywords": "java operators, operators in java, operators, arithmetic operator, logical operator, assign operator, operator precedence", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/operators-in-java-language.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "Operators are special symbols that perform operations.",
 "articleBody": "Arithmetic operation from arithmetic expression (a+b, a/b). The result of arithmetic expression is integer literal or floating point literal."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
