<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Database in Java</title>
<meta name="description" content="A database is a data structure that stores organized information. Most databases contain multiple tables, which may each include several different fields.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Database in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/database-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="A database is a data structure that stores organized information. Most databases contain multiple tables, which may each include several different fields.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Database in Java">
<meta name="twitter:description" content="A database is a data structure that stores organized information. Most databases contain multiple tables, which may each include several different fields.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/database-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="database-in-java.php">
<span itemprop="name">What is Database in detail?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Database</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Database Concepts for Java</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<div>
<h2 class="breadcrumb">Database Concepts</h2>
<p>Now that we have learned about Java Database Connectivity (JDBC), it is time to learn about some database concepts which you find useful during interviews or while programming.</p>
<ul>
<li><p>The DBMS is the software which is situated between a human being and the data storage. If you want to manipulate the data available in the storage, then you will have to interact the DBMS with SQL commands.</p></li>
<li><p>The SQL (Structure Query Language) is a standard which is followed by all the DB vendors to interact with the data and is provided by ANSI (American National Standard Institute).</p></li>
<li><p>There is some validation by the DB task to implement their database.</p></li>
<li><p>Some ANSI style syntaxes are more complicated and make it tricky to code sometimes. To avoid these complications DB vendors provide their own syntax called the Theta style syntax.</p></li>
<li><p>All the DBMS store their data in a tabular format with rows and columns.</p></li>
<li><p>Row contains all the values related to one entity.</p></li>
<li><p>The column contains similar types of values related to all the entities.</p></li>
<li><p>A Database contains tables, and tables contain rows and columns. One row denotes one record. One column represents the common entity of all the rows.</p></li>
</ul>
</div>
<hr>
<div>
<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#DataTypes" role="tab" data-toggle="tab">Data Types</a></li>
<li role="presentation"><a href="#SQLCommands" role="tab" data-toggle="tab">SQL Commands</a></li>
<li role="presentation"><a href="#SQLOperations" role="tab" data-toggle="tab">SQL Operations</a></li>
<li role="presentation"><a href="#Functions" role="tab" data-toggle="tab">Functions</a></li>
<li role="presentation"><a href="#GroupByandHavingClause" role="tab" data-toggle="tab">Group By & Having Clause</a></li>
<li role="presentation"><a href="#Constraints" role="tab" data-toggle="tab">Constraints</a></li>
<li role="presentation"><a href="#Joins" role="tab" data-toggle="tab">Joins</a></li>
<li role="presentation"><a href="#SubQueries" role="tab" data-toggle="tab">Sub Queries</a></li>
<li role="presentation"><a href="#Index" role="tab" data-toggle="tab">Index</a></li>
<li role="presentation"><a href="#Sequence" role="tab" data-toggle="tab">Sequence</a></li>
<li role="presentation"><a href="#Views" role="tab" data-toggle="tab">Views</a></li>
<li role="presentation"><a href="#Permissions" role="tab" data-toggle="tab">Permissions</a></li>
<li role="presentation"><a href="#SpecialQueries" role="tab" data-toggle="tab">Special Queries</a></li>
<li role="presentation"><a href="#PLSQL" role="tab" data-toggle="tab">PL/SQL</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="DataTypes">
<div>
<h2 class="breadcrumb">Data Types</h2>
<p>This represents which type of information can be stored in the database. There are eight primitive data types in java. They are divided into numeric, textual and Boolean and null primitive data types.</p>
<div>
<h3>Oracle Database Data Types:</h3>
<p>There are seven Oracle Database data types. They are as follows:</p>
<p>CHAR:</p>
<ul>
<li><p>The CHAR data type stores fixed-length character strings. When you create a table with a CHAR column, you must specify a string length (in bytes or characters) between 1 and 2000 bytes, for the CHAR column width. The default is 1 byte. Oracle then guarantees that:</p></li>
<li><p>When you insert or update a row in the table, the value for the CHAR column has a fixed length</p></li>
<li><p>If you give a shorter value, then the value is blank-padded to the fixed length</p></li>
<li><p>If a value is too large, the Oracle Database returns an error.</p></li>
</ul>
<p>Oracle Database compares CHAR values using blank-padded comparison semantics.</p>
<hr>
<p>VARCHAR2:</p>
<p>(reserved keyword for future reference, as varchar will be replaced eventually)</p>
<ul>
<li><p>The Varchar2 data type stores variable-length character strings. When you create a table with a VARCHAR2 column, you specify a maximum string length (in bytes or characters) between 1 and 4000 bytes for the VARCHAR2 column. For each row, the Oracle Database stores each value in the column as a variable-length field unless a particular value exceeds the column's maximum length, in which case the Oracle Database returns an error. Using VARCHAR2 and VARCHAR saves a lot of space used by the table.<br>
For example, assume that you have declared a column VARCHAR2 with a maximum size of 50 characters.<br>
In a single-byte character set, if only 10 characters are given for the VARCHAR2 column value in a particular row, the column in the row's row piece stores only 10 characters (10 bytes), not 50.
</p></li>
<li><p>Oracle Database compares VARCHAR2 values using non-padded comparison semantics.</p></li>
</ul>
<hr>
<p>Varchar Datatype:</p>
<p>The VARCHAR datatype is synonymous with the VARCHAR2 datatype.</p>
<ul>To avoid possible changes in behavior, always use the VARCHAR2 datatype to store variable-length character strings.</ul>
<hr>
<p>Date:</p>
<ul>
<li><p>The Date datatype stores point-in-time values (dates and times) in a table. The Date datatype stores the year (including the century), the month, the day, the hours, the minutes, and the seconds (after midnight).</p></li>
<li><p>For input and output of dates, the standard Oracle date format is DD-MON-YY, as follows:</p></li>
<li><p>‘13-NOV-92’</p></li>
</ul>
<hr>
<p>Blob:</p>
<ul>
<li><p>The Blob data type stores unstructured binary data in the database. Blobs can store up to 128 terabytes of binary data.</p></li>
<li><p>Blobs participate fully in transactions. Changes made to a Blob value by the DBMS_LOB package, PL/SQL, or the OCI can be committed or rolled back. However, Blob locators cannot span transactions or sessions.</p></li>
</ul>
<hr>
<p>Clob:</p>
<ul>
<li><p>CLOBs and NCLOBs participate fully in transactions. Changes made to a CLOB or NCLOB value by the DBMS_LOB package, PL/SQL, or the OCI can be committed or rolled back. However, CLOB and NCLOB locators cannot span transactions or sessions.</p></li>
<li><p>You cannot create an object type with NCLOB attributes, but you can specify NCLOB parameters in a method for an object type.</p></li>
</ul>
<hr>
<p>File:</p>
<hr>
<h3>MySQL Database Data Types:</h3>
<ul>
<li><p>Char, Varchar</p></li> <li><p>text, (Unlimited Char use)</p></li>
<li><p>int</p></li> <li><p>long</p></li>
<li><p>float</p></li> <li><p>double</p></li>
<li><p>date</p></li> <li><p>blob</p></li>
<li><p>clob</p></li> <li><p>file</p></li>
</ul>
</div>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="SQLCommands">
<div>
<h2 class="breadcrumb">SQL Commands</h2>
<p><a href="database-sql-commands.php" class="btn btn-outline-danger">Learn about SQL Commands &rarr;</a></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="SQLOperations">
<div>
<h2 class="breadcrumb">SQL Operations</h2>
<p>The SQL operations are as follows:</p>
<ul>
<li><p>Arithmetic operations (+, -, *, /, mod)</p></li>
<li><p>Relation operations (>, >=, <=, <, < >, =)</p></li>
<li><p>Logical operations (and, or, not)</p></li>
<li><p>In operators</p></li>
<li><p>Between and operator</p></li>
<li><p>Like operator</p></li>
</ul>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Functions">
<div>
<h2 class="breadcrumb">Functions</h2>
<div>
<h3>SQL Function:</h3>
<ul>
<li><p>Math functions</p></li>
<li><p>String functions</p></li>
<li><p>Date functions</p></li>
<li><p>Conversion functions</p></li>
<li><p>Aggregate functions</p></li>
</ul>
</div>
<div>
<h3>Conversation Function:</h3>
<ul>
<li><p>to -number&rarr; &nbsp; Character to number</p></li>
<li><p>to -character&rarr; &nbsp; Number to character or date to character</p></li>
<li><p>to -date format&rarr; &nbsp; Character to date or date of one format to date or another </p></li>
</ul>
</div>
<div>
<h3>Aggregate Function:</h3>
<ul>
<li><p>Count</p></li>
<li><p>Sum</p></li>
<li><p>Average</p></li>
<li><p>Max</p></li>
<li><p>Min</p></li>
</ul>
</div><hr>
<div name="QuestionsAndAnswers">
<p><b>Question 1:</b> <i>Display the number of books available in the book store.</i><br>
<b>Answer:</b> <code>Select count (*)</code>
</p>
<p><b>Question 2:</b> <i>Display different types of total books available.</i><br>
<b>Answer:</b> <code>Select count (*) from books;</code>
</p>
<p><b>Question 3:</b> <i>Display total books available.</i><br>
<b>Answer:</b> <code>Select sum (qly) from books;</code>
</p>
<p><b>Question 4:</b> <i>Display the maximum cost of books.</i><br>
<b>Answer:</b> <code>Select max (cost) from books; Select min (cost) from books;</code>
</p>
</div>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="GroupByandHavingClause">
<div>
<h2 class="breadcrumb">Group By and Having Clause</h2>
<p><a href="database-groupby-and-having-clause.php" class="btn btn-outline-danger">Learn about Group by & Having Clause &rarr;</a></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Constraints">
<div>
<h2 class="breadcrumb">Constraints</h2>
<p><a href="database-constraints.php" class="btn btn-outline-danger">Learn about Constraints &rarr;</a></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Joins">
<div>
<h2 class="breadcrumb">Joins</h2>
<p><a href="database-joins.php" class="btn btn-outline-danger">Learn about Joins &rarr;</a></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="SubQueries">
<div>
<h2 class="breadcrumb">Sub Queries</h2>
<p><a href="database-sub-queries.php" class="btn btn-outline-danger">Learn about Sub Queries &rarr;</a></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Index">
<div>
<h2 class="breadcrumb">Index</h2>
<p>An Index is an ordered list of elements belonging to one column or a combination of two or more columns.</p>
<p><b>Syntax:</b><br>
<code>CREATE UNIQUE INDEX index_name ON table_name ( column1, column2,_ _ _ _ _);</code></p>
<p>There are Two Types of Indexes:</p>
<ul>
<li><p>Simple Index</p></li> <li><p>Composite Index</p></li>
</ul>
<h3>Simple Index:</h3>
<p>When an index is created on a single column of a tablethen it is called simple index.</p>
<p><b>Example:</b></p>
<ul>
<li><p>Create index i1 On customers (email);</p></li>
<li><p>Now on disk. a space will be occupied with email in ascending order and a pointer to them. You search will become easier now.</p></li>
</ul>
<h3>Composite Index:</h3>
<p>When an index is created with a combination of two or more columns then it is called composite index.</p>
<p><b>Example:</b></p>
<div class="table-responsive">
<table class="table table-bordered">
<code>Create index i2 on accounts (branch code, account type, account no.);</code>
<tr><th>Customer ID</th> <th>Customer Name</th> <th>Email</th> <th>Phone</th> <th>City</th></tr>
<tr><td>1.</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>2.</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>3.</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>4.</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
<tr><td>5.</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td> <td>&nbsp;</td></tr>
</table></div>
<code>Select from customers where email='….'</code>
<p>This query directly goes through the customers table when there is no index table. But it is time consuming and not efficient.</p>
<hr>
<h3>Index Table</h3>
<ul>
<li><p>It goes into the index table when the index is created. Indexes mainly help to speed up the result of a query.</p></li>
<li><p>If you do not have any index for assuming columns, then all the elements of that column will be searched for a given element one by one. But it takes more time when data is vast.</p></li>
<li><p>To avoid this delay we can create indexes on that column.</p></li>
<li><p>When you create an index then all the elements of that column will be created and will be placed in a separate object.</p></li>
<li><p>When you search elements, DBMS will use this order list to find an element using a better search algorithm.</p></li>
<li><p>No need to use index directly because the index will be used by DBMS automatically wherever select statement contains the column which has the index.</p></li>
<li><p>If a primary key exists, DBMS will create the index automatically.</p></li>
<li><p>If the tables contain a composite primary key, a composite index is created by the DBMS automatically.</p></li>
<li><p>A table can have one or more indexes</p></li>
</ul>
<hr>
<h3>Dropping Index</h3>
<p><b>Syntax:</b><br>
<code>Drop index index_name;</code></p>
<p><b>Example:</b><br>
<code>drop index i1;</code></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Sequence">
<div>
<h2 class="breadcrumb">Sequence</h2>
<p>Sequences are used to generate the values automatically for any given column. They generate only number type value and are not suitable for character type values.</p>
<p><b>Syntax:</b><br>
<code>Create sequence seq_name Start with int_value <br>
Min value int_value Max value int_value Increment by int_value Cycle <br>
No cycle;
</code></p>
<p><b>Example:</b><br>
<code>Create sequence s1 Start with 101 <br>
Increment by 1;
</code></p>
<p>Sequence object has the following variations:</p>
<ol>
<li><p>Current Value - return the current value</p></li>
<li><p>Next Value - returns the current value and then increment</p></li>
</ol>
<p><b>Example:</b><br>
<code>Create sequences S2 Start with 101
Max value 1000<br>
Increment by 1 Cycle;<br>
Create sequence S3 Start with 1000<br>
Min Value 101<br>
Increment by -1 No cycle;<br>
</code></p>
<hr>
<h3>Dropping Sequence:</h3>
<p>This drops a sequence from the table.</p>
<p><b>Syntax:</b><br>
<code>Drop sequence seq_name;</code></p>
<p><b>Example:</b><br>
<code>Drop Sequence S1;</code></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Views">
<div>
<h2 class="breadcrumb">Views</h2>
<p><a href="database-views.php" class="btn btn-outline-danger">Learn about Views &rarr;</a></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="Permissions">
<div>
<h2 class="breadcrumb">Granting The Permission</h2>
<p><b>Syntax:</b><br>
<code>Grant select, delete, update, insert, create, drop,_ _ _ _ _. <br>
On object_name to user_name; <br>
Table name, view name index name, seq. name
</code></p>
<p><b>Example:</b><br>
<code>Grant select, update on students to kiran; Grant select on ad_view to kiran, vas;</code></p>
</div>
<div>
<h2 class="breadcrumb">Revoking Permissions</h2>
<p><b>Syntax:</b><br>
<code>Revoke select, delete, update, insert, create, drop,_ _ _ _ _ _.<br>
On object name from user_name;
</code></p>
<p><b>Example:</b><br>
<code>Revoke select, update on students from kiran; Revoke select on ad_view from kiran, vas;</code></p>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="SpecialQueries">
<div>
<h2 class="breadcrumb">Special Queries</h2>
<p><b>In MySQL:</b><br>
<code>Create table account (ID int, name char (12), balance double);</code></p>
<p><b>In Create:</b><br>
<code>Create table account (ID number (2), name char (5);
balance number (g,2)); <br>
Insert into account values (1,'a', 1000); <br>
Insert into account values (2, 'b', 2000); <br>
Insert into account values (3, 'c', 4000); <br>
Insert into account values (4, 'd', 9000); <br>
Insert into account values (5, 'e', 6000); <br>
Insert into account values (6, 'f', 7000); <br>
Insert into account values (7, 'g', 5000); <br>
Insert into account values (8, '4', 3000); <br>
Insert into account values (9, '4', 4000);
</code></p>
<ol>
<li><p><b>Display nth row(6) (Oracle)</b></p>
<ul><code>Select *from (select id, name, bal, row number from accounts where <br>
Row num (8) where rn=6; <br>
Select from account limit 5,1
</code></ul></li><br>
<li><p><b>Display rows from m(2) to n(5) (Oracle)</b></p>
<ul><code>Select *from (select balance, row number from account where row number <7) <br>
Where in between 2 & 5;
</code></ul><br>
<b>MySQL</b><br>
<code>Select * from account limit 1,4</code>
</li><br>
<li><p><b>Display nth highest</b></p>
<ul>Oracle and MySQL <br>
<code>(Select * from account where 3=(select count (distinct balance) from account <br>
where acc.bal<=bal);
</code></ul></li><br>
<li><p><b>Display Top N rows : (Oracle)</b></p>
<ul><code>Select * from (select *from account order by ID) Where row num < 5;<br>
Select * from (select *from account order by ID description) Where row num <5; <br>
Select * from account where row num <5;
</code></ul><br>
<b>MySQL</b><br>
<code>Select * from account limit 4;</code> (limit start index, no. of records)
</li><br>
<li><p><b>Display every n(3)th row : (Oracle)</b></p>
<ul><code>Select * from account where (row ID, 0) in <br>
(Select row ID mod (rownum, 3) from accounts);
</code></ul>
</li>
</ol>
<div>
<h3>Invalid relational operator MySQL:</h3>
<code>Select *from account where (ID.0) in <br>
(select ID, mod(ID, 3) from account);
</code>
</div><br>
</div>
</div>
<div role="tabpanel" class="tab-pane fade" id="PLSQL">
<div>
<h2 class="breadcrumb">PL / SQL</h2>
<p><a href="database-pl-sql-concepts.php" class="btn btn-outline-danger">Learn about PL/SQL &rarr;</a></p>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#DataTypes" role="tab" data-toggle="tab">Data Types</a></li>
<li role="presentation"><a href="#SQLCommands" role="tab" data-toggle="tab">SQL Commands</a></li>
<li role="presentation"><a href="#SQLOperations" role="tab" data-toggle="tab">SQL Operations</a></li>
<li role="presentation"><a href="#Functions" role="tab" data-toggle="tab">Functions</a></li>
<li role="presentation"><a href="#GroupByandHavingClause" role="tab" data-toggle="tab">Group By & Having Clause</a></li>
<li role="presentation"><a href="#Constraints" role="tab" data-toggle="tab">Constraints</a></li>
<li role="presentation"><a href="#Joins" role="tab" data-toggle="tab">Joins</a></li>
<li role="presentation"><a href="#SubQueries" role="tab" data-toggle="tab">Sub Queries</a></li>
<li role="presentation"><a href="#Index" role="tab" data-toggle="tab">Index</a></li>
<li role="presentation"><a href="#Sequence" role="tab" data-toggle="tab">Sequence</a></li>
<li role="presentation"><a href="#Views" role="tab" data-toggle="tab">Views</a></li>
<li role="presentation"><a href="#Permissions" role="tab" data-toggle="tab">Permissions</a></li>
<li role="presentation"><a href="#SpecialQueries" role="tab" data-toggle="tab">Special Queries</a></li>
<li role="presentation"><a href="#PLSQL" role="tab" data-toggle="tab">PL/SQL</a></li>
</ul>
</div><hr>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="jdbc-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Database - Java",
 "alternativeHeadline": "How to store data in database using java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java database", 
 "keywords": "java database, database, database in java, datatypes, sql commands, sql operations, functions, group by clause, having clause, constraints, joins, sub queries, index, views, pl sql", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/database-in-java.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "Database manipulates the data available in the storage.",
 "articleBody": "The SQL (Structure Query Language) is a standard which is followed by all the DB vendors to interact with the data and is provided by ANSI (American National Standard Institute). A Database contains tables, and tables contain rows and columns. One row denotes one record. One column represents the common entity of all the rows."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
