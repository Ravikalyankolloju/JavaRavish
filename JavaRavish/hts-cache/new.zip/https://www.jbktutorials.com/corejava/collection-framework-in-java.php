<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Collection Framework in Java</title>
<meta name="description" content="The collection framework in java is made up of classes and interfaces that stores and processes data in an efficient manner.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Collection Framework in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/collection-framework-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="The collection framework in java is made up of classes and interfaces that stores and processes data in an efficient manner.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Collection Framework in Java">
<meta name="twitter:description" content="The collection framework in java is made up of classes and interfaces that stores and processes data in an efficient manner.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/collection-framework-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 

<div class="container-fluid">

<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="collection-framework-in-java.php">
<span itemprop="name">What is Collection Framework?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Collection Framework</span>
<meta itemprop="position" content="4" />
</li>
</ol> 
<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Collection Framework in Java</h1>
<div class="card-body">
<p>The <b>collection framework</b> in java is made up of classes and interfaces that stores and processes data in an efficient manner.</p>
<ul><li><p>The Sun Microsystems has introduced collection framework in Java 2.0</p></li>
<li><p>The hierarchy of the whole collection framework is given below :</p></li>
</ul>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/collectionframeworkhierarchy.webp" alt="collection hierarchy in java" title="Collection Hierarchy Diagram"></div>
<hr>

<div class="tab" role="tabpanel">

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#List" role="tab" data-toggle="tab">List</a></li>
<li role="presentation"><a href="#Set" role="tab" data-toggle="tab">Set</a></li>
<li role="presentation"><a href="#Queue" role="tab" data-toggle="tab">Queue</a></li>
<li role="presentation"><a href="#Dequeue" role="tab" data-toggle="tab">Dequeue</a></li>
<li role="presentation"><a href="#Map" role="tab" data-toggle="tab">Map</a></li>
<li role="presentation"><a href="#PropertiesClasses" role="tab" data-toggle="tab">Properties Classes</a></li>
<li role="presentation"><a href="#CollectionsClasses" role="tab" data-toggle="tab">Collections Classes</a></li>
<li role="presentation"><a href="#ComparableInterface" role="tab" data-toggle="tab">Comparable Interface</a></li>
<li role="presentation"><a href="#ComparatorInterface" role="tab" data-toggle="tab">Comparator Interface</a></li>
</ul>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="List">
<div class="card-text">
<h2 class="breadcrumb"><a name="List"></a>List</h2>
<ul>
<li><p>List is an interface that is available in the java.util package.</p></li>
<li><p>List is used to store a collection of elements and allows duplicates.</p></li>
<li><p>The term ‘List is ordered’ means that the order is retained in which we add elements, and will get the same sequence while retrieving elements.</p></li>
<li><p>List interface has three concrete subclasses:</p>
<ul>
<li>ArrayList</li> <li>LinkedList</li> <li>Vector</li>
</ul></li>
</ul>
<p><b>Remember the following three important methods of List :</b></p>
<ul>
<li>Boolean add(Object o) ; //Append the specified elements to the end of the list
<ul>
<li>Return type is Boolean</li>
<li>Input type is Object</li>
</ul>
</li><br>
<li>Object get(int i); //Return the elements as Object of the specified position in the list
<ul>
<li>Return type is Object</li>
<li>Input type is int [index of Arraylist ]</li>
</ul>
</li><br>
<li>int size(); // Return number of elements in the list
<ul>
<li>Return type is int [no of elements exist.]</li>
<li>Input type is nothing</li>
</ul>
</li>
</ul><hr>
<h4>ArrayList</h4>
<p>The <b>ArrayList</b> extends the AbstractList and implements the List interface. It is usually slower than the other arrays, but is useful where you need to manipulate a lot in programs.</p>
<ul>
<li><p>Uses Dynamic array for storing the elements</p></li>
<li><p>Duplicate elements are allowed</p></li>
<li><p>Maintains insertion order</p></li>
<li><p>Methods are not synchronised</p></li>
<li><p>Random access as it works on index basis</p></li>
<li><p>Manipulation is slow because lot of shifting needs to be done. This means that if the ArrayList has 1000 elements and we remove the 50th element, then the 51st element tries to acquire that 50th position and likewise all elements. So, moving every element consumes a lot of time.</p></li>
</ul><hr>
<h4>Vector</h4>
<p>The <b>vector</b> class ‘implements a growable array of objects. Similar to an array, it contains components that can be accessed using an integer index’. The vector may expand or contract as per the requirements.</p>
<ul>
<li><p>All methods are synchronised</p></li>
<li><p>It is slower than an Arraylist</p></li>
<li><p>Vector is thread-safe as it has synchronised methods</p></li>
<li><p>It has capacity concept. The default capacity is 10</p></li>
<li><p>It doubles when it reaches its threshold</p></li>
<li><p>Size methods returns the number of elements present</p></li>
<li><p>Capacity method returns the capacity which doubles after reaching the default capacity, which is 10</p></li>
<li><p>Vector can be iterated by simple for loop, Iterator, ListIterator and Enumeration</p></li>
</ul><hr>
<div>
<p><b>Example</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>
package com.javabykiran.collection; 
import java.util.ArrayList;
import java.util.Iterator;
/*
* @author Java By Kiran
*/
public class ArrayListTest {
    public static void main(String[] args) { 
     ArrayList al = new ArrayList();
     al.add("aaa");
     al.add("bbb");
     al.add("ccc");
     // see return type of add below
     System.out.println(al.add("ddd")); 
     al.size(); 
     System.out.println(al.size);
     //to check if Arraylist is empty
     al.isEmpty();
   System.out.println("iteration of Arraylist by for loop"); 
     for (int i = 0; i < al.size(); i++) {
        System.out.println(al.get(i));
    }
   System.out.println("iteration of Arraylist by Iterator");
     Iterator itr = al.iterator();
        while (itr.hasNext()) { 
           Object o = itr.next(); //this is removed in   
                                  //jdk 1.5 and after by autoboxing 
           String s = (String) o; 
           System.out.println(s);
         }
   System.out.println("iteration of Arraylist by List Iterator");
     ListIterator ltr = al.listIterator(); 
        while (ltr.hasNext()) {
           Object o = ltr.next();
           String s = (String) o; 
           System.out.println(s);	
           //Object op = ltr.previous();
           /*String prevStr = (String) op; 
           System.out.println(prevStr);*/
        }
    }
}
</code>
</pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      true
      4
      iteration of Arraylist by for loop
      aaa
      bbb
      ccc
      ddd
      iteration of Arraylist by Iterator
      aaa
      bbb
      ccc
      ddd
      iteration of Arraylist by List Iterator
      aaa
      bbb
      ccc
      ddd
    </code></pre>
</div><br>
<div>
<p><b>Example for vector :</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>
package com.javabykiran.Collection; import java.util.Vector;
/*
* @author Java By Kiran
*/
public class VectorTest {
     public static void main(String[] args) {            
	Vector v = new Vector();
        System.out.println(v.size()); 
        System.out.println(v.capacity());
        //we can change its default behaviour 
        Vector v1 = new Vector(2); 
        System.out.println(v1.size()); 
        System.out.println(v1.capacity());
        //now try adding elements 
        v1.add("apple");
        v1.add("mango");
        v1.add("grapes"); 
  System.out.println(v1.size());
  // observe capacity 
  System.out.println(v1.capacity());
  //Iterate by using Enumeration 
  Enumeration enumeration=v1.elements(); 
  while (enumeration.hasMoreElements())	{ 
      String element =(String)enumeration.nextElement(); 
        System.out.println(element);
    }
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb">	
<code class="nohighlight">
    <b>Output:</b>
     0
     10
     0
     2
     3
     4
     apple
     mango 
     grapes
    </code></pre>
</div>
<ul>
<li>Every List interface implementing class has two constructors :
<ul>
<li>Default constructor</li>
<li>Constructor which takes java.util.collection</li>
</ul>
</li>
</ul><br>
<div>
<p><b>Example of ArrayList</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>ArrayList al=new ArrayList (); //with default constructor
ArrayList al1=new ArrayList (al); //constructor with ArrayList
ArrayList al2=new ArrayList (v); //constructor with vector
ArrayList al3=new ArrayList (c); //with java.util.collection
</code></pre>
</div><br>
<div>
<p><b>Example of Vector</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>Vector v=new Vector (); //with default constructor 
v.add(); //to add elements
Vector v1=new Vector (al); //with java.util.collection 
Vector v2=new Vector(v); // with vector
</code></pre>
</div>
<div class="card-text">
<h2 class="breadcrumb"><a name></a>Difference between Iterator and Enumeration:</h2>
<div class="tablediv">
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tr>
<th class="center">Iterator</th>
<th class="center">Enumeration</th>
</tr>
<tr>
<td><ul><li>Iterator can be used to access the elements of six subclasses of collection interface:
<ol type="1">
<li>ArrayList</li> <li>Vector</li> <li>LinkedList</li> <li>LinkedHashSet</li> <li>Treeset and HashSet</li>
</ol>
</li></ul></td>
<td><ul><li>Enumeration can be used for accessing elements of vector only.</li></ul></td>
</tr>
<tr>
<td><ul><li>Using the Iterator methods hasNext() and next(), you can access the elements of collection.</li></ul></td>
<td><ul><li>Using enumeration method has More Elements() and nextElements(), you can access the elements of vector one by one.</li></ul></td>
</tr>
<tr>
<td><ul><li>Using the Iterator you can remove the elements of collection. Example :
<code>
Iterator it=al.iterator(); <br>
&nbsp; while(it.hasNext()) {<br>
&nbsp;&nbsp; String str=it.next().toString(); <br>
&nbsp;&nbsp;&nbsp; if(str.equals("jbk")) {<br>
&nbsp;&nbsp;&nbsp;&nbsp; it.remove();<br>
&nbsp; }<br>
}
</code></li></ul></td>
<td><ul><li>Enumeration is read only i.e. you can just the read the data from vector but you cannot remove the element from vector using Enumeration.</li></ul></td>
</tr>
</table>
</div>
</div>
<div class="card-text">
<h2 class="breadcrumb"><a name></a>Difference between Iterator and ListIterator:</h2>
<ol type="1">
<li><p>ListIterator is the sub interface of Iterator and therefore has more features in ListIterator than Iterator.</p></li>
<li><p>ListIterator can access elements in forward and reverse directions.</p></li>
<li><p>Adding elements by using add method.</p></li>
<li><p>Replacement of existing elements with new element by using the set method.</p></li>
<li><p>Access index of element.</p></li>
</ol>
<div class="tablediv">
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tr>
<th class="center">Iterator</th>
<th class="center">ListIterator</th>
</tr>
<tr>
<td><ul><li>Using Iterator we can access the elements of collection only in forward direction using the hasNext() & next() methods.</li></ul></td>
<td><ul><li>Using ListIterator we can access the elements in the forward direction using hasNext() and next() methods and in reverse direction using hasPrevious()and previous() methods.</li></ul></td>
</tr>
<tr>
<td><ul><li>You cannot add elements to collection.</li></ul></td>
<td><ul><li>You can add the elements collection.</li></ul></td>
</tr>
<tr>
<td><ul><li>You cannot replace the existing elements with new elements.</li></ul></td>
<td><ul><li>You can replace the existing elements with a new element by using void set(E e).</li></ul></td>
</tr>
<tr>
<td><ul><li>Using Iterator you cannot access the indexes of elements of collection.</li></ul></td>
<td><ul><li>Using ListIterator you can access indexes of elements of collection using nextIndex() and previousIndex() methods.</li></ul></td>
</tr>
<tr>
<td><ul><li>Using Iterator you can remove the elements of a collection.</li></ul></td>
<td><ul><li>Using ListIterator you can also remove the elements of collection.</li></ul></td>
</tr>
</table>
</div> </div>
<div class="card-text">
<h2 class="breadcrumb"><a name></a>Difference between Array and ArrayList:</h2>
<div class="tablediv">
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<tr>
<th class="center">Array</th>
<th class="center">ArrayList</th>
</tr>
<tr>
<td><ul><li>The size of an Array is fixed, i.e. when you create an array with same size you cannot change dynamically.</li></ul></td>
<td><ul><li>The size of an ArrayList is grow-able, i.e. once the ArrayList is created you can add any number of elements without restriction.</li></ul></td>
</tr>
<tr>
<td><ul><li>When you create an small Array you can't add more elements and when you create a large sized array, the memory will be wasted when we don't put that.</li></ul></td>
<td><ul><li>You won't get these problems with an ArrayList.</li></ul></td>
</tr>
<tr>
<td><ul><li>When you have an array with a size 100 and has 10 elements only, then you need to repeat the loop 100 times to access 10 elements which is an unnecessary and time consuming process.</li></ul></td>
<td><ul><li>When you access elements of ArrayList using iterator you won't face this time wastage problem.</li></ul></td>
</tr>
<tr>
<td><ul><li>Array stores only similar types of elements.You can store primitive and objects in Array<br>
e.g: <code>int a[]=new int[5];<br>
Students[] stu=new Student[5];</code>
</li></ul></td>
<td><ul><li>ArrayList store different types of elements You can store only objects in an ArrayList Student s1= new Student();<br>
e.g. <code>al.add(s1);<br>
al.add("sri");</code>
</li></ul></td>
</tr>
</table>
</div>
<p><b>Note:</b> Both Array and ArrayList store the elements internally using indexing representation and these elements can be accessed randomly</p>
<ul>
<li>You can access the elements of an Array using index representation <br>
For example: <code>a [1]</code>
</li>
<li>You cannot access the elements of an ArrayList using index representation<br>
For example: <code>al [0] is not allowed but al.get(0) is allowed</code>
</li>
</ul><hr>
<div class="tablediv">
<p><b>Comparison</b> between <b>ArrayList</b>, <b>Vector</b> and <b>LinkedList</b>:</p>
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<tr>
<th class="center">Topic</th>
<th class="center">ArrayList</th>
<th class="center">Vector</th>
<th class="center">LinkedList</th>
</tr>
<tr>
<td>Legacy or collection Framework</td>
<td>Collection framework class added in java 2</td>
<td>Legacy class but revised in java 2</td>
<td>Collection framework class added in java 2</td>
</tr>
<tr>
<td>Synchronised</td>
<td>Not Synchronised</td>
<td>Synchronised</td>
<td>Not Synchronised</td>
</tr>
<tr>
<td>Storage Representation</td>
<td>Index Representation</td>
<td>Index Representation</td>
<td>Node Representation</td>
</tr>
<tr>
<td>Accessing Elements</td>
<td>Iterator. List Iterator</td>
<td>Enumeration. Iterator List Iterator</td>
<td>Iterator. List Iterator</td>
</tr>
<tr>
<td>Access Type</td>
<td>Random Access</td>
<td>Random Access</td>
<td>----</td>
</tr>
</table>
</div>
</div>
</div>
</div>

<div role="tabpanel" class="tab-pane fade" id="Set">
<div class="card-text">
<h2 class="breadcrumb"><a name="Set"></a>Set</h2>
<ul>
<li><p>A set is used to store the collection of elements without duplicates.</p></li>
<li><p>It is an unordered collection which means that order is not maintained while storing elements and while retrieving them, we may not get the same order that we had put them in.</p></li>
<li><p>A set cannot be iterated by using ListIterator but by Iterator.</p></li>
<li>There are four classes which implement Set interface:
<ul>
<li>HashSet</li>
<li>LinkedHashSet</li>
<li>TreeSet</li>
<li>SortedSet - It uses hash table to store elements. Duplicates are not allowed.</li>
</ul>
</li>
</ul><br>
<div>
<p><b>Example:</b> Consider the following <b>program of HashSet</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection; 
 import java.util.HashSet;
 import java.util.Iterator;
 /*
 * @author Java By Kiran
 */
 public class HashSetTest {
  public static void main(String[] args) { 
    HashSet hs = new HashSet();
    hs.add("aaaa");
    hs.add("bbbb");
  // aaaa will not be allowed as the set doesn't allow duplicates
    hs.add("aaaa");
    hs.add("cccc");
  // see size
  System.out.println(hs.size());

  // we can print values for testing
  System.out.println(hs);

  // By using iterator
  Iterator itr = hs.iterator();
  while (itr.hasNext())
    System.out.println(itr.next());
    }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     3
     [bbbb, aaaa, cccc] 
     bbbb
     aaaa 
     cccc
  </code></pre>
</div><hr>
<div class="tablediv">
<p><b>Comparison</b> between <b>HashSet</b>, <b>LinkedHashSet</b> and <b>TreeSet</b>:</p>
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
<col style="width: 25%" />
</colgroup>
<tr>
<th class="center">Topic</th>
<th class="center">HashSet</th>
<th class="center">LinkedHashSet</th>
<th class="center">TreeSet</th>
</tr>
<tr>
<td>Duplicate</td>
<td>Not Allowed</td>
<td>Not Allowed</td>
<td>Not Allowed</td>
</tr>
<tr>
<td>Ordering</td>
<td>Unordered</td>
<td>Maintains insertion order</td>
<td>Maintains sorting order</td>
</tr>
<tr>
<td>Null</td>
<td>Allow</td>
<td>Allow</td>
<td>Do not allow</td>
</tr>
<tr>
<td>Accessing Elements</td>
<td>Iterator</td>
<td>Iterator</td>
<td>Iterator</td>
</tr>
<tr>
<td>Thread Safety</td>
<td>No</td>
<td>No</td>
<td>No</td>
</tr>
</table>
</div>
</div>
</div>

<div role="tabpanel" class="tab-pane fade " id="Queue">
<div class="card-text">
<h2 class="breadcrumb">Queue</h2>
<div>
<ul>
<li><p>The <b>Queue</b> is an interface of a subtype of the Collection interface</p></li>
<li><p>It represents an ordered list of objects just like a List, but its intended use is slightly different.</p></li>
<li><p>A queue is designed to have elements inserted at the end of the queue, and elements removed from the beginning of the queue. Just like a queue in a supermarket or any shop.</p></li>
<li>Following are the concrete subclasses of the Queue interface:
<ul>
<li>ArrayDeque</li>
<li>PriorityQueue</li>
<li>PriorityblockingQueue</li>
<li>LinkedBlockingQueue</li>
</ul>
</li><br>
<li>Each Queue method exists in two forms:
<ul>
<li>One throws an exception if the operation fails</li>
<li>The other returns a special value if the operation fails (either null or false, depending on the operation)</li>
</ul>
</li>
</ul></div><br><br>
</div>
</div>

<div role="tabpanel" class="tab-pane fade " id="Dequeue">
<div class="card-text">
<h2 class="breadcrumb">Dequeue</h2>
<div>
<ul>
<li><p><b>Dequeue</b> is a sub-interface of Queue interface</p></li>
<li><p>A double-ended-queue is a linear collection of elements that supports the insertion and removal of elements at both end points</p></li>
<li><p>It defines methods to access the elements at both ends of the Deque instance</p></li>
<li>Methods for insertion, removal and retrieval of Deque elements are summarised in the following table:</li>
<div class="tablediv">
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 20%" />
<col style="width: 40%" />
<col style="width: 40%" />
</colgroup>
<tr>
<th class="center">Type of Operation</th>
<th class="center">First Element (Beginning of the Deque instance)</th>
<th class="center">Last Element (End of the Deque instance)</th>
</tr>
<tr>
<td>Insert</td>
<td>addFirst(e)<br>
offerFirst(e)</td>
<td>addLast(e)<br>
offerLast(e)</td>
</tr>
<tr>
<td>Remove</td>
<td>removeFirst(e)<br>
pollFirst(e)</td>
<td>removeLast(e)<br>
pollLast(e)</td>
</tr>
<tr>
<td>Examine</td>
<td>getFirst(e)<br>
peekFirst(e)</td>
<td>getLast(e)<br>
peekLast(e)</td>
</tr>
</table>
</div>
</ul></div></div>
</div>

<div role="tabpanel" class="tab-pane fade " id="Map">
<h2 class="breadcrumb"><a name="Map"></a>Map</h2>
<ul>
<li><p>A <b>map</b> is used to store the key-value pair</p></li>
<li><p>It doesn't allow duplicate keys but duplicate values are allowed</p></li>
<li>It has the following concrete subclasses:
<ul>
<li>HashMap</li>
<li>WeakHashMap</li>
<li>HashTable</li>
<li>IdentityHashMap</li>
<li>TreeMap</li>
<li>LinkedHashMap</li>
</ul>
</li>
</ul><br>
<div>
<h4>HashMap:</h4>
<ul>
<li><p>A <b>HashMap</b> is class which implements the Map interface</p></li>
<li><p>It stores values based on key</p></li>
<li><p>It is unordered, which means that the key must be unique</p></li>
<li><p>It may have null key-null value</p></li>
<li><p>For adding elements in HashMap we use the put method</p></li>
<li><p>Return type of put method is Object</p></li>
<li><p>It returns the previous value associated with key or null if there was no mapping for key</p></li>
</ul><br>
</div>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection; 
import java.util.HashMap;
import java.util.Iterator; 
import java.util.Map; 
import java.util.Set;
/*
* @author Java By Kiran
*/
public class HashMapTest {
 public static void main(String[] args) {
    // Creation of HashMap 
        HashMap hm = new HashMap();
    // Adding elements with key 
        hm.put("101", "java");
        hm.put("102", ".Net");
    // Will print null
        Object o = hm.put("103", "C++"); 
        System.out.println(o);
    // Will print previous value as it is duplicate value    
        Object o1 = hm.put("103", "C");
        System.out.println(o1);

//1. Retrieving elements from HashMap by using iterator
   System.out.println("======By using Iterator======");
        Set s = hm.keySet(); // set s contains all keys 
        Iterator itr = s.iterator();
    while (itr.hasNext()) {
    String key = (String) itr.next(); 
    System.out.println("Key :"+key); 
    System. out. println(" Value :"+ hm.get(key));
  }

//2. Retrieving elements from HashMap by using Map.Entry

   System.out.println("====== By using Map.Entry ======");
   // Get a set of the entries 
   Set set = hm.entrySet();
   // Get an iterator
   Iterator it = set.iterator();

   // Display elements 
   while(it.hasNext()) { 
        Map.Entry me = (Map.Entry) it.next();   
        System.out.print(me.getKey()+ ": ");
        System.out.println(me.getValue());
      }
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
    null
    C++
    ======By using Iterator======
    Key :101
    Value :java
    Key :102
    Value :.Net
    Key :103
    Value :C
    ====== By using Map.Entry ======
    101: java
    102: .Net
    103: C

  </code></pre>
</div><br>
<div>
<h4>LinkedHashMap:</h4>
<ul>
<li><p>A <b>LinkedHashMap</b> is a ‘hastable and linked list implementation of the map interface with a predictable iteration order.</p></li>
<li><p>It is the same as HashMap except it maintains an insertion order i.e. ordered<br>
Consider the same above programs using LinkedHashMap. Observe the output. Change one line in the above example.</p></li>
</ul><br>
<div>
<p><b>In above program,</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>//Instead of
  HashMap hm=new HashMap ();
  //Use below
  // Creation of LinkedHashMap 
  LinkedHashMap hm = new LinkedHashMap()

</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     null 
     C++
     ====== By using Iterator ====== 
     Key :101
     Value :java 
     Key :102
     Value :.Net 
     Key :103
     Value :C
     ====== By using Map.Entry ====== 
     101: java
     102: .Net
     103: C
  </code></pre>
</div>
</div><br>
<div>
<h4>TreeMap:</h4>
<ul>
<li><p>The <b>TreeMap</b> is a class which implements NavigableMap interface which is the sub- interface of SortedMap.</p></li>
<li><p>It stores values based on key</p></li>
<li><p>It is ordered but in an Ascending manner</p></li>
<li><p>Keys should be unique</p></li>
<li><p>It cannot have null key at run time but can have null values because the interpreter will not understand how to sort null with other values</p></li>
<li><p>Consider the program of storing elements using TreeMap</p></li>
</ul><br>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection; 
import java.util.Iterator;
import java.util.Set; 
import java.util.TreeMap;
/*
* @author Java By Kiran
*/
public class TreeMapTest {
   public static void main(String[] args) {
    // Creation of TreeMap 
    TreeMap tm = new TreeMap();
    // adding elements with key 
    tm.put("103", "java");
    tm.put("102", ".Net");
    Object o = tm.put("101", "C++");
      // below will print null 
      System.out.println (o);
      Object o1 = tm.put("101", "C"); 
      System.out.println (o1);
      // retrieving elements from TreeMap 
      Set s = tm.keySet();
     // set s contains all keys 
     Iterator itr = s.iterator(); 
      while (itr.hasNext()) {
          String key = (String) itr.next();     
          System.out.println("Key :" + key); 
          System.out.println("Value :" + tm.get(key));
    }
    // Try putting null value
    // will not throw compile time error
    // but gives runtime error uncomment below
    // tm.put(null, null);
  }	
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     null
     C++
     Key :101
     Value :C 
     Key   :102
     Value :.Net
     Key   :103
     Value :java
  </code></pre>
</div>
</div><br>
<div>
<h4>Hashtable:</h4>
<ul>
<li><p><b>Hashtable</b> is a class which implements Map interface and extends Dictionary class.</p></li>
<li><p>It stores values based on key</p></li>
<li><p>It is unordered and the key should be unique</p></li>
<li><p>It cannot have null keys or null values. It gives runtime error if we try to add any null keys or values but will not show an error at compile time.</p></li>
<li><p>It has synchronised methods and slower than hashmap</p></li>
<li><p>Consider the program of storing elements using Hashtable</p></li>
</ul><br>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection; 
import java.util.Hashtable;
/*
* @author Java By Kiran
*/
public class HashTableTest {
    public static void main(String[] args){ Hashtable ht = new Hashtable(); ht.put("ind", "India");
      ht.put("bhu", "Bhutan");
      ht.put("ind", "India");
    //the below will print size of ht by
    //ignoring the duplicate key
 System.out.println("size of hashTable> "+ht.size());	// 2
    //OK - compile time
    //NOT OK AT RUNTIME
    //ht.put(null, "India");
    //OK - compile time
    //NOT OK AT RUNTIME
    //ht.put(null, null);
    //OK - compile time
    //NOT OK AT RUNTIME
    //ht.put("ind", null);
   System.out.println(ht.size()); // 2
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     size of hashTable > 2
     Exception in thread "main" java.lang.NullPointerException 
     at java.util.Hashtable.put(Unknown Source)
     at com.javabykiran.Collection.HashTableTest.main(HashTableTest.java:23)
  </code></pre>
</div><hr>
<div class="tablediv">
<p><b>Comparison</b> between <b>HashMap</b>, <b>LinkedHashMap</b>, <b>TreeMap</b> and <b>HashTable:</b></p>
<table class="table-responsive-xl table-bordered table" style="width:100%;">
<colgroup>
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
<col style="width: 20%" />
</colgroup>
<tr>
<th class="center">Topic</th>
<th class="center">HashMap</th>
<th class="center">LinkedHashMap</th>
<th class="center">TreeMap</th>
<th class="center">HashTable</th>
</tr>
<tr>
<td>Duplicate Key</td>
<td>Not Allowed</td>
<td>Not Allowed</td>
<td>Not Allowed</td>
<td>Not Allowed</td>
</tr>
<tr>
<td>Ordering</td>
<td>Unordered</td>
<td>Maintains insertion order</td>
<td>Maintains in Accessing order</td>
<td>Unordered</td>
</tr>
<tr>
<td>Null (Key Value)</td>
<td>Allow</td>
<td>Allow</td>
<td>key Not allowed but value is Iterator</td>
<td>Not Allowed</td>
</tr>
<tr>
<td>Accessing Elements</td>
<td>Iterator</td>
<td>Iterator</td>
<td>Iterator</td>
<td>Iterator</td>
</tr>
<tr>
<td>Thread Safety</td>
<td>No</td>
<td>No</td>
<td>No</td>
<td>Yes</td>
</tr>
</table>
</div>
</div>
</div>

<div role="tabpanel" class="tab-pane fade " id="PropertiesClasses">
<h2 class="breadcrumb">Properties Classes</h2>
<div>
<p>It can be used to get properties from xml file or to store data in xml file.</p>
<ul>
<li><p>All methods of this class are synchronised, So it is a thread-safe class</p></li>
<li><p>It is since jdk 1.0</p></li>
<li><p>It is the subclass of HashTable</p></li>
<li><p>It stores the key-value pair, but both as string</p></li>
<li><p>It can be used to get property value based on property key</p></li>
<li><p>It can also be used to get properties of system</p></li>
<li><p>It provides easy maintenance</p></li>
</ul>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection; 
 import java.io.FileOutputStream; 
 import java.util.Iterator;
 import java.util.Properties; 
 import java.util.Set;
 /*
 * @author Java By Kiran
 */
public class PropertiesTest {
    public static void main(String[] args) { 
        Properties properties = new Properties();
        // Same way we can put elements 
        properties.put("101", "java");
        properties.put("102", "C");
        properties.put("103", "C++");
        properties.put("104", ".Net");
        // to retrieve the elements. 
        Set s = properties.keySet(); 
        Iterator itr = s.iterator();
     while (itr.hasNext()) {     
        System.out.println(properties.get((String)itr.next()));
      }
      // to store in xml file
     try {
        FileOutputStream fout = new FileOutputStream("D:\\prop.xml"); 
        properties.storeToXML(four,"key-value pair");
     }
     catch (Exception e) {    
        e.printStackTrace();
    }
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     .Net 
     C++ 
     C
     java
  </code></pre>
</div><br>
<div>
<p>An XML file is created as shown below in the D drive that we have just printed in above Program <br>
<b>Example:</b></p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code111" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code111" class="breadcrumb pretagcodebox">
<xmp><!DOCTYPE properties SYSTEM "http://java.sun.com/dtd/properties.dtd">
<properties>
    <comment>key-value pair</comment>
    <entry key="104">.Net</entry>
    <entry key="103">C++</entry>
    <entry key="102">C</entry>
    <entry key="101">java</entry>
</properties>
</xmp></pre>
</div><br>
</div>
</div><br>
</div>

<div role="tabpanel" class="tab-pane fade " id="CollectionsClasses">
<h2 class="breadcrumb">Collections Classes</h2>
<div>
<ul>
<li><p>All methods of this class are static. Constructor is private</p></li>
<li><p>This class has methods to give extra features to Collection Hierarchy. For example: sort, binary Search, reverse, finding min value, max Value and making list read only.</p></li>
<li><p>Those collection classes which are not synchronised will be synchronised by using methods - synchronizedList (), synchronizedMap ()</p></li>
</ul>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code11" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code11" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection; 
import java.util.ArrayList;
import java.util.Collections;
/*
* @author Java By Kiran
*/
public class CollectionsTest {
  public static void main(String[] args) {
    ArrayList al = new ArrayList(); 
    al.add("Java");
    al.add("By");
    al.add("Kiran");
  System.out.println("before sorting " + al); 
  Collections.sort(al); 
  System.out.println("after sorting" + al);
  //To make arraylist object synchronised 
    Collections.synchronizedList(al);
 }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     before sorting [Java, By, Kiran] 
     after sorting [By, Java, Kiran]
  </code></pre>
</div><br>
<p><b>Note:</b>
<ul>
<li><p>To sort custom objects. For example: One student having age and location
We add students in Arraylist and we want to sort these students on the basis of their ages
If we use only Collections, it will sort by addresses of the students’ object, which we don't want.
</p></li>
<li><p>
This is not possible with the ordinary sort method. For that we need to use <b>Comparable</b> or <b>Comparator</b> interface, where we need to specify our sorting criteria. Then we can pass that criteria into the sort method.
</p></li>
</ul>
</p>
</div>
</div>

<div role="tabpanel" class="tab-pane fade " id="ComparableInterface">
<h2 class="breadcrumb">Comparable Interface</h2>
<div>
<h4><a name="ComparableInterface"></a>Comparable Interface:</h4>
<p><b>Comparable interface</b> is primarily used to sort out lists or arrays of custom objects. It contains only one method.</p>
<ul>
<li><p>The class whose object has to be compared has to implement Comparable interface and has to override compareTo () method in the following format.</p></li>
<li><p>public int compareTo(Object 0bj).</p></li>
<li><p>Comparable provides only one way of comparison.</p></li>
<li><p>You can sort the elements on based on single data member only. For instance it may be rollno, name, age or anything else.</p></li>
</ul><br>
<div>
<p><b>Example:</b><br> Consider the following program of sorting students on the basis of age:</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code12" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code12" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection;
/*
* @author Java By Kiran
*/
class Student implements Comparable{ 
    String name;
    int age;
  public int compareTo(Object obj){ 
    Student s = (Student)obj; 
    if(age==s.age)
      return 0;
    else if(age>s.age) 
      return -1;
    return age;
    }
}
</code></pre>
</div>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code13" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code13" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection; 
import java.util.*;
/*
* @author Java By Kiran
*/
public class CollectionLab9 {
  public static void main(String args[]){ 
     ArrayList al = new ArrayList (); 
     Student s1 = new Student ();
       s1.name = "ABC"; 
       s1.age = 24;
     Student s2 = new Student (); 
       s2.name = "XYZ";
       s2.age = 21;
     Student s3 = new Student (); 
       s3.name = "PQR"; 
       s3.age = 19;
      al.add(s1);
      al.add(s2);
      al.add(s3); 
    Collections.sort(al); 
      Iterator itr=al.iterator();          
      while(itr.hasNext()){
        Student st= (Student) itr.next ();   
        System.out.println(st.name+"--"+st.age);
      }
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     ABC--24
     XYZ--21
     PQR--19

  </code></pre>
</div>
</div><br>
</div>

<div role="tabpanel" class="tab-pane fade " id="ComparatorInterface">
<h2 class="breadcrumb">Comparator Interface</h2>
<div>
<p><b>Comparator interface</b> is used when you have to order user-defined class objects and contains two methods.</p>
<ul>
<li><p>We need to write separate class by implementing Comparator interface by overriding the following method:<br>
public int compare(Object o1,Object o2)
</p></li>
<li><p>You can write multiple comparators to compare objects in different ways<br>
To use compare() method of Comparator interface for sorting, use following method:<br>
Collections.sort(al , new NameComparator());
</p></li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code14" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code14" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection;
/*
* @author Java By Kiran
*/
class Student { 
    String name; 
    int age;
}
</code></pre>
<button class="copycodebuttonstyle" data-clipboard-target="#code15" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code15" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection;
/*
* @author Java By Kiran
*/
import java.util.*;
public class AgeComparator implements Comparator{ 
   public int compare(Object o1, Object o2) {
     Student s1=(Student)o1; 
     Student s2=(Student)o2;
     if(s1.age==s2.age) 
       return 0;
     else if(s1.age>s2.age) 
       return 1;
     else return -1;
   }
}
</code></pre>
<button class="copycodebuttonstyle" data-clipboard-target="#code16" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code16" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection;
/*
* @author Java By Kiran
*/ import java.util.Comparator;
public class NameComparator implements Comparator {  
public int compare(Object o1, Object o2) {
     Student s1=(Student)o1; 
     Student s2=(Student)o2;
   return s1.name.compareTo(s2.name);
  }
}
</code></pre>
<button class="copycodebuttonstyle" data-clipboard-target="#code17" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code17" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection;
/*
* @author Java By Kiran
*/
import java.util.*;
public class CollectionLab10 {
   public static void main(String args[]){ 
   ArrayList al = new ArrayList(); 
     Student s1 = new Student();
       s1.name = "ABC"; 
       s1.age = 24;
     Student s2 = new Student(); 
       s2.name = "XYZ";
       s2.age = 21;
     Student s3 = new Student(); 
       s3.name = "PQR";
       s3.age = 19; 
     al.add(s1);
     al.add(s2);
     al.add(s3); 
   System.out.println("Sorting by Name...");
   Collections.sort(al,new NameComparator());
        Iterator itr=al.iterator(); 
        while(itr.hasNext()){
            Student st=(Student)itr.next(); 
            System.out.println(st.name+" "+st.age);
        }
   System.out.println("sorting by age..."); 
    Collections.sort (al,new AgeComparator()); 
    Iterator itr2=al.iterator();
     while (itr2.hasNext()){
        Student st= (Student)itr2.next();
        System.out.print(st.name); 
        System.out.println(" "+st.age);
      }
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     Sorting by Name... 
     ABC 24
     PQR 19
     XYZ 21
     Sorting by age... 
     PQR 19
     XYZ 21
     ABC 24
  </code></pre>
</div>
</div><hr>
<div>
<p>The following table gives the <b>properties of derived classes</b>:</p>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/collectionframework_derivedclassesproperties.webp" alt="properties of derived classes in java" title="Properties of derived classes in Java"></div>
</div>
</div>

</div>
<ul class="nav nav-tabs nav-bottom  mt-3" role="tablist">
<li role="presentation" class="active"><a href="#List" role="tab" data-toggle="tab">List</a></li>
<li role="presentation"><a href="#Set" role="tab" data-toggle="tab">Set</a></li>
<li role="presentation"><a href="#Queue" role="tab" data-toggle="tab">Queue</a></li>
<li role="presentation"><a href="#Dequeue" role="tab" data-toggle="tab">Dequeue</a></li>
<li role="presentation"><a href="#Map" role="tab" data-toggle="tab">Map</a></li>
<li role="presentation"><a href="#PropertiesClasses" role="tab" data-toggle="tab">Properties Classes</a></li>
<li role="presentation"><a href="#CollectionsClasses" role="tab" data-toggle="tab">Collections Classes</a></li>
<li role="presentation"><a href="#ComparableInterface" role="tab" data-toggle="tab">Comparable Interface</a></li>
<li role="presentation"><a href="#ComparatorInterface" role="tab" data-toggle="tab">Comparator Interface</a></li>
</ul>
</div>

</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="input-and-output-streams-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="collection-revisited-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>


</div>

</div>

<script type="application/ld+json">
{ "@context": "http://schema.org",
  "@type": "Product",
  "name": "Collection Framework",
  "url": "https://www.jbktutorials.com/corejava/collection-framework-in-java.php",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.2",
    "ratingCount": "8",
    "reviewCount": "187"
  }}
  </script>
<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Collection Framework - Java",
 "alternativeHeadline": "What is collection framework in java?",
 "image": "https://www.jbktutorials.com/images/java/collectionframeworkhierarchy.webp",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java collection framework", 
 "keywords": "java collection framework, java collections, collection framework, collections classes, list, set, dequeue, properties class, comparable interface, comparator interface", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/collection-framework-in-java",
   "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "The collection framework in java is made up of classes and interfaces that stores and processes data in an efficient manner.",
 "articleBody": "List is an interface that is available in the java.util package. List is used to store a collection of elements and allows duplicates. The term ‘List is ordered’ means that the order is retained in which we add elements, and will get the same sequence while retrieving elements."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
