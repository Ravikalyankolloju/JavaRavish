<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Literals in Java</title>
<meta name="description" content="Literals are syntactic representations of boolean, character, numeric, or string data. In other words, Literals are value which we can assign to variable or constant.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Literals in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/literals-in-java-language.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Literals are syntactic representations of boolean, character, numeric, or string data. In other words, Literals are value which we can assign to variable or constant.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Literals in Java">
<meta name="twitter:description" content="Literals are syntactic representations of boolean, character, numeric, or string data. In other words, Literals are value which we can assign to variable or constant.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/literals-in-java-language.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto; }
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="introduction-to-java.php">
<span itemprop="name">Core Java</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Java Language- Literals</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Literals in Java</h1>
<div class="card-body">
<div>
<div class="tab" role="tabpanel">
<p><b>Literals</b> are a value which you can assign to the variable or a constant.</p>
<p>There are five types of literals and are listed below:</p>
<hr><div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#IntegerLiteral" role="tab" data-toggle="tab">Integer Literal</a></li>
<li role="presentation"><a href="#FloatingPointLiteral" role="tab" data-toggle="tab">Floating Point Literal</a></li>
<li role="presentation"><a href="#CharacterLiteral" role="tab" data-toggle="tab">Character Literal</a></li>
<li role="presentation"><a href="#BooleanLiteral" role="tab" data-toggle="tab">Boolean Literal</a></li>
<li role="presentation"><a href="#StringLiteral" role="tab" data-toggle="tab">String Literal</a></li>
</ul>
</div><hr>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="IntegerLiteral">
<h2 class="breadcrumb">Integer Literal</h2>
<ul>
<li><p>It can be assigned to one of the integer data types; there are three types of integer literals.</p></li>
<li><p>Decimal integer literals: Base 10 [0-9]</p></li>
<li><p>Octal integer literals (starts with 0) [0-7]</p></li>
<li><p>Hexadecimal integer literals (0-9, A-F)</p></li>
</ul>
<ul><b>Examples</b> (imp. Interview questions)
<li><p><code>int a=123;</code></p></li>
<li><p><code>int a=0123;</code> (starting with zero)</p></li>
<li><p><code>int a=0x123A;</code> (starting with zero & x)</p></li>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="FloatingPointLiteral">
<h2 class="breadcrumb">Floating Point Literal</h2>
<ul>
<li><p>It can be assigned to floating point variables declared with float or double datatypes.<br>
There are two types of representation:</p>
<ul>
<li><p>Decimal pointer presentation</p></li>
<li><p>Exponential representation</p></li>
</ul>
</li>
<b>Examples</b>
<li><p><code>double d16 = 99.99;</code></p></li>
<li><p><code>double d12 = 99.99e-5; // 99.99e-4</code></p></li>
<li><p><code>double d15 = 9.9E3; // (9.9*10*10*10)</code></p></li>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="CharacterLiteral">
<h2 class="breadcrumb">Character Literal</h2>
<ul>
<li><p>It is a single character which is enclosed between single quotes ‘ ’</p></li>
<ul>Example :
<ul><p><code>‘a’ ‘+’ ‘ ’ <br>
‘ ’ // invalid (because of space)
</code></p></ul>
</ul>
<li>A character literal can be assigned to a character type variable.</li>
<ul>Example :
<ul><p><code>char ch1='a';</code></p></ul>
</ul>
<li><p>Each character which is enclosed in single quotation marks will have integer equivalent’s value as per ASCII character set as shown in the example below:</p>
<ul>
<li><p>‘a’ = 97, ‘b’ = 98, ------------- , ’y’ = 121, ’z’ =122</p></li>
<li><p>‘A’ = 65, ‘B’ = 66, ------------- , ‘Y’ = 89, ‘Z’ = 90</p></li>
<li><p>‘0’ = 48, ‘1’ = 49, ------------- , ‘8’ = 56, ‘9’ = 57</p></li>
</ul>
</li>
<li><p>Java uses the character set UNICODE (Universal Code)</p></li>
<li><p>UNICODE character set takes two bytes of memory for each character and supports multi languages.</p></li>
<li><p>ASCII character set takes only one byte character and supports only English language.</p></li>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="BooleanLiteral">
<h2 class="breadcrumb">Boolean Literal</h2>
<ul>
<li><p>There are two boolean literals:</p></li>
<ul>
<li><p>True</p></li>
<li><p>False</p></li>
</ul>
<li><p>Boolean literals can be assigned to the variables which are declared with boolean data type.</p></li>
<ul>
Example :
<ul><code>boolean b=true;</code></ul>
</ul>
</ul>
</div>
<div role="tabpanel" class="tab-pane fade" id="StringLiteral">
<h2 class="breadcrumb">String Literal</h2>
<ul>
<li><p>It is a collection of one or more characters enclosed between double quotation marks.</p></li>
<li><p>String literals can be assigned to reference variable of type String.</p></li>
</ul>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>class Lab1 {
   String s1 = "hello guys";
   String s2 = "123 guys as d";
   String s3 = "     “;
   public static void main(String as[]) { 
    int a = 10;
    int $b = 20;
     // int 1c=30;
     // int ab=40;
     // int 1=10;
    System.out.println(-a); 
    System.out.println($b);
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      -10
      20
</code></pre>
</div>
<div>
<p><b>Lab2.Java</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.basics; 
 class Lab2 {
    byte b;     // variable & constants demo 
    short s;    // 0
    int i;      // 0 
    long l;     // 0 
    float f;    //0.0
    double d;   // 0.0
    char ch;    // for 1 character’s blankspace
    boolean b1; //  false
   void show1() {
    System.out.println("variables & constants demo");
    System.out.println(b); 
    System.out.println(d); 
    System.out.println(s); 
    System.out.println(ch); 
    System.out.println(i); 
    System.out.println(b1); 
    System.out.println(l); 
    System.out.println(f1); 
    System.out.println(f);
    // System.out.println (x);x cannot resolved to a variable
    // x=x+1
   }
   void show2() {
    System.out.println("integer literal demo"); 
    int a = 12;
    int b = 10;
    int c = 0x12a; // integer literal demo 
    Byte d = 012; 
    System.out.println(a); // 12
    System.out.println(b); // 10
    System.out.println(c); // 298
    System.out.println(d); // 10
   }
   void show3() {
    System.out.println("floating point literal demo");
    float f1 = 99.97f;
    double d1 = 9.9e-9; 
    double d2 = 9.9E+9;
    System.out.println(f1); // 99.97 
    System.out.println(d1); // 9.9E-9 
    System.out.println(d2); // 9.9E9
   }
   void show4() {
    System.out.println("character literal demo");
    char ch1 = 'A'; 
    int x1 = 'A';
     // char ch2 = ''; // error invalid character constant
     //int x2 = '' ;   // error 
    char ch3 = 'I';
    int x3 = 'I'; 
    System.out.println(ch1); // A 
    System.out.println(x1);  //65
     // System.out.println (ch2); // error +
     // System.out.println (x2);  // error + 
     System.out.println(ch3);     // I 
    System.out.println(x3);       // 73
   }
   void show5() {
    System.out.println("Boolean literal demo"); 
    boolean bb1 = false;
    boolean bb2 = true; 
    System.out.println(bb1); // false 
    System.out.println(bb2); // true
   }
   void show6() {
    System.out.println("string literal demo");
    String ste1 = "";
    String ste2 = "123 abc+"; 
    String ste3 = "1";
    System.out.println("ste1 " + ste1);   // ste1- - "blank" 
    System.out.println(ste1.length());
    System.out.println("ste2 = " + ste2); // ste2=123 abc +
    System.out.println(ste2.length());    // 9 
    System.out.println("ste3="	+ ste3);  // ste = 1
    System.out.println(ste3.length());    // 1
   }  
}
package com.javabykiran.basics; 
 class Lab2Test {
   public static void main(String[] args){
     Lab2 h = new Lab2(); 
     h.show1();
     h.show2();
     h.show3();
     h.show4();
     h.show5();
     h.show6();
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      variables & constants demo 0
      0.0
      0
      Blank
      0
      false 
      0
      10.9
      0.0
      integer literal demo 
      12
      10
      298
      10
      floating point literal demo 
      99.97
      9.9E-9
      9.9E9
      character literal demo 
      A
      65
      I 
      73
      Boolean literal demo 
      false
      true
      string literal demo 
      ste1
      0
      ste2 = 123 
      abc + 9
      ste3 = 1
      1

</code></pre>
</div>
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#IntegerLiteral" role="tab" data-toggle="tab">Integer Literal</a></li>
<li role="presentation"><a href="#FloatingPointLiteral" role="tab" data-toggle="tab">Floating Point Literal</a></li>
<li role="presentation"><a href="#CharacterLiteral" role="tab" data-toggle="tab">Character Literal</a></li>
<li role="presentation"><a href="#BooleanLiteral" role="tab" data-toggle="tab">Boolean Literal</a></li>
<li role="presentation"><a href="#StringLiteral" role="tab" data-toggle="tab">String Literal</a></li>
</ul>
</div><hr>
<a href="java-language.php" class="btn btn-outline-danger">Back to Java Language Chapter</a>
</div>
</div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item disabled">
<a class="page-link btn-outline-primary" href="#">&lArr; Previous Chapter</a>
</li>
<li class="page-item disabled">
<a class="page-link" href="#">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Literals - Java",
 "alternativeHeadline": "What are literals in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java literals", 
 "keywords": "java literals, literals in java, literals, integer literal, floating point literal, character literal, boolean literal, string literal", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/literals-in-java-language.php",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "Literals are a value which you can assign to the variable or a constant.",
 "articleBody": "It can be assigned to one of the integer data types; there are three types of integer literals. Decimal integer literals: Base 10 [0-9], Octal integer literals (starts with 0) [0-7], Hexadecimal integer literals (0-9, A-F)"
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
