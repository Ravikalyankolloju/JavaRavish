<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Input and Output Streams in Java</title>
<meta name="description" content="Java - I/O - The java.io package contains nearly every class you might ever need to perform input and output (I/O) in Java.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Input and Output Streams in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/input-and-output-streams-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="Java - I/O - The java.io package contains nearly every class you might ever need to perform input and output (I/O) in Java.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Input and Output Streams in Java">
<meta name="twitter:description" content="Java - I/O - The java.io package contains nearly every class you might ever need to perform input and output (I/O) in Java.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/input-and-output-streams-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="input-and-output-streams-in-java.php">
<span itemprop="name">What is I/O Stream?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Input Output Stream</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Input Output Stream in Java</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<p><b>Stream</b> is nothing but sequence of bytes which makes input and output operations feasible and faster. It is called stream because it facilitates a continuous flow of data. An <b> Input/Output stream </b> is an input source or output destination which represents various types of sources. Java uses the concept of stream to make I/O operation fast. All the classes required for I/O operation are given in java.iopackage</p>
<div>

<hr><ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#IOIntroduction" role="tab" data-toggle="tab">Stream Introduction</a></li>
<li role="presentation"><a href="#CharacterStreams" role="tab" data-toggle="tab">Character Streams</a></li>
<li role="presentation"><a href="#ByteStreams" role="tab" data-toggle="tab">Byte Streams</a></li>
<li role="presentation"><a href="#BufferedIandOStream" role="tab" data-toggle="tab">Buffered I/O Stream</a></li>
<li role="presentation"><a href="#FileWriterandFileReaderClass" role="tab" data-toggle="tab">FileWriter & FileReader</a></li>
<li role="presentation"><a href="#SequenceInputStream" role="tab" data-toggle="tab">SequenceInputStream</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="IOIntroduction"><br>
<p>In java, I/O is used to receive input data and produce output by processing the input provided.</p>
<div>
<p><b>Example for File Class:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>package com.jbk.fileio;
import java.io.File;
import java.util.Date; 
  public class FileInfoExample {
    public static void main(String[] args) {
        File apath = new File("C:/test/abc.txt");
        // Check if exists.
     System.out.println("Path exists? "+ apath.exists());
        if (apath.exists()) {
            // Check if 'apath' is a directory.
     System.out.println("Directory? "+ apath.isDirectory());
         // Check 'apath' is a Hidden path.
     System.out.println("Hidden? "+ apath.isHidden());
     System.out.println("Simple Name: " + apath.getName());
     System.out.println("Absolute Path: "+ apath.getAbsolutePath());
        // Check file size (in bytes):
     System.out.println("Length (bytes): " + apath.length());
       // Last modify (in milli second)
       long lastMofifyInMillis = apath.lastModified();
       Date lastModifyDate = new Date(lastMofifyInMillis);
     System.out.println("Last modify date: " + lastModifyDate);
       }
 
    } 
}
</code></pre>
</div>
<p>There are two types of streams, which are Character Stream and Byte stream.</p>
</div>
<div role="tabpanel" class="tab-pane fade" id="CharacterStreams">
<div id="Div1">
<h2 class="breadcrumb">Character Streams</h2>
<ul>
<li><p>The Java platform stores character values using Unicode conventions. Character I/O stream automatically translates this internal format to and from the local character set. In Western locales, the local character set is usually an 8-bit superset of ASCII.</p></li>
<li><p>For most applications, I/O with character stream is no more complicated than I/O with binary streams. Input and output done with stream classes automatically translates to and from the local character set.</p></li>
<li><p>A program that uses character stream in place of byte streams automatically adapts to the local character set and is ready for internationalisation - all without extra effort by the programmer.</p></li>
<li><p>All character stream classes are descended from Reader and Writer. As with byte streams, there are character stream classes that specialise in file I/O: FileReader and FileWriter.</p></li>
<li><p>Classes under this hierarchy are used for reading and writing characters from file, which are text files.</p></li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiram.IO;
 Import java.io.Filewriter; 
 public class CopyCharacters {
    public static void main(String[] args) throws Exception { 
        FileReader reader = null;
        Filewriter writer = null;
 try {
     reader = new FileReader(“jbk.txt”); 
     writer = new FileWriter(“coralsoft.txt”); int c;
     while ((c=reader.read()) !=-1){ 
        writer.writer(c);
    }
}finally{
     if (reader !=null){ reader.close();
     }
     if (writer !=null){ writer.close();
     }
   }
}
</code></pre>
</div>
<ul><li><p>Now, we have a lot of classes in this hierarchy of reader and writer. Every class has some more features. In the above example we copy characters by characters. For that we use BufferedReader and PrintWriter classes as shown below:</p></li></ul>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="ByteStreams">
<div id="Div2">
<h2 class="breadcrumb">Byte Streams</h2>
<ul>
<li><p>Programs use byte streams to perform input and output of 8-bytes. All byte stream classes are descended from InputStream and OutputStream classes.</p></li>
<li><p>There are many byte stream classes. To demonstrate how byte streams work, we'll focus on the file I/O byte streams, File Input Stream and File Output Stream. Other kind of byte streams are used much in the same way; the difference is mainly in the way they are constructed.</p></li>
<li><p>These classes are used for binary data. We can use these classes for text files as well.</p></li>
<li><p>Character streams are wrapper for binary streams. This means that the character stream uses the binary stream internally.</p></li>
<li><p>Java uses OutputStream and InputStream for Writing data to destination and Reading data from source, respectively.</p></li>
<li><p>OutputStream and InputStream are abstract classes. So we can't use them directly</p>
<ul>
<li><p><b>Output Stream class:</b> OutputStream class is an abstract class. It is the superclass of all classes representing an output stream of bytes. Like FileOutputStream, ObjectOutputStream, etc.</p></li>
<li><p><b>Input Stream class:</b> InputStream class is an abstract class. It is the superclass of all classes representing an input stream of bytes, like File Input Stream, Object Input Stream, etc.</p></li>
</ul>
</li>
</ul>
<div class="docs-galley"><img class="docs-pictures clearfix centerimage" src="../images/java/bytestreams.webp" alt="input streams and output streams in java" title="I/O Streams"></div>
</div><hr>
<div id="Div3">
<p class="card-text">
<h2 class="breadcrumb"><a name="ReadingDataFromanInputStream"></a>Reading Data From an InputStream</h2>
<ul>
<li><p>The abstract superclass InputStream declares an abstract method read() to read one data-byte from the input source.</p></li>
<li><p>The read() method :</p>
<ul>
<li><p>Returns the input byte read as an int in the range of 0 to 255, or</p></li>
<li><p>Returns -1 if "end of stream" condition is detected, or</p></li>
<li><p>Throws an IOException if it encounters an I/O error</p></li>
</ul>
</li>
<li><p><b>The read ()</b> method returns an int instead of a byte, because it uses -1 to indicate end-of- stream.</p></li>
<li><p><b>The read ()</b> method blocks until a byte is available, an I/O error occurs, or the "end-of- stream" is detected. The term "block" means that the method (and the program) will be suspended. The program will resume only when the method returns.</p></li>
</ul>
</div><hr>
<div id="Div4">
<p class="card-text">
<h2 class="breadcrumb"><a name="WritingtoanOutputStream"></a>Writing to an Output Stream</h2>
<ul>
<li><p>Similar to the InputStream, the abstract superclass OutputStream declares an abstract method write() to write a data-byte to the output sink.</p></li>
<li><p><code>write()</code> : Takes an int as the input parameter</p></li>
<li><p>The least-significant byte of the int argument is written out; the upper three bytes are discarded.</p></li>
<li><p>It throws an IOException if an I/O error occurs (for example, if output stream has been closed).</p></li>
<li><p>InputStream and OutputStream are abstract classes that cannot be instantiated. You need to choose an appropriate concrete subclass to establish a connection to a physical device. For example, you can instantiate a FileInputStream or FileOutputStream to establish a stream to a physical disk file.</p></li>
<li><p>We can use FileInputStream and FileOutputStream for File related operations</p></li>
</ul><br>
<div>
<p><b>Example</b><br>
<b>How to Read File?</b> [keep file in the d drive notes folder- write as a javabykiran.com in file]</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code3" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code3" class="breadcrumb pretagcodebox">
<code>package com;
  import java.io.FileInputStream; 
  import java.io.IOException; 
  public class IOLab1 {
    public static void main(String[] args){ 
    try {
         //windows file path - D:\notes\abc.txt //not allowed
         //invalid escape sequence
      String path = "D:\\notes\\abc.txt";
         //or path = "D:/notes/abc.txt";
    FileInputStream fis = new FileInputStream(path); 
      int i=0;
      while((i=fis.read())!=-1){ 
         char c =(char) i; 
         System.out.print(c);
      }
      fis.close();
    }    
    catch (IOException e) { 
         e.printStackTrace();
    }
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     www.javabykiran.com
    </code></pre>
</div><br>
<div>
<p><b>Example<br>
How to Write to File?</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code4" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code4" class="breadcrumb pretagcodebox">
<code>package com;
import java.io.FileOutputStream; import java.io.IOException; 
public class IOLab2 {
public static void main(String[] args) {
    try {
          //windows file path - D:\notes\abc.txt // not allowed
          //Envalid escape sequence
          String path = "D:\\notes\\abc.txt";
          //or path = "D:/notes/abc.txt";
          FileOutputStream fos = new FileOutputStream(path);
          String s ="javabykiran Add- Karvenagar,pune";
                byte b[] = s.getBytes();
                fos.write(b);
          System.out.println( "successfully written"); 
          fos.close();
    } 
    catch (IOException e) { 
           e.printStackTrace();
    }	
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     Successfully written
    </code></pre>
</div><br>
<div>
<p><b>Example<br>
How to copy data from one file to another?</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code5" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code5" class="breadcrumb pretagcodebox">
<code>package com;
import java.io.FileInputStream; 
import java.io.FileOutputStream; 
import java.io.IOException; 
 public class IOLab3 {
   public static void main(String[] args) { 
   try {
    String srcpath = "D:\\WorkSpaces\\Eclipse_IndigoWS\\IO\\src\\com\\IOLab3.java";
    String despath = "D:\\notes\\LabProgram3.txt";
    FileInputStream fis = new FileInputStream(srcpath);
    FileOutputStream fos = new FileOutputStream(despath);
    int i=0;
        while((i=fis.read())!=-1){
        fos.write(i);
    }
    fis.close();
 } catch (IOException e) { 
        e.printStackTrace();
      }
   }
}
</code></pre>
</div><br>
<ul><li><p>There are some <b>important classes</b> that you would need to remember: <b>BufferedInputStream</b> and <b>BufferedOutputStream</b></p></li></ul>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="BufferedIandOStream">
<div id="Div5">
<h2 class="breadcrumb"><a name="BufferedIandOStream"></a>BufferedInputStream and BufferedOutputStream</h2>
<ul>
<li><p>A BufferedInputStream adds functionality to another input stream, namely, the ability to buffer the input and to support the mark and reset methods.</p></li>
<li><p>When the BufferedInputStream is created, an internal buffer array is created. As bytes from the stream are read or skipped, the internal buffer is refilled as necessary from the contained input stream, many bytes at a time.</p></li>
<li><p>The mark operation remembers a point in the input stream and the reset operation causes all the bytes read since the most recent mark operation to be reread before new bytes are taken from the contained input stream.</p></li>
<li><p>The BufferedOutput Stream implements a BufferedOutputStream. By setting up such an output stream, an application can write bytes to the underlying output stream without necessarily causing a call to the underlying system for each byte written.</p></li>
</ul><br>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code6" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code6" class="breadcrumb pretagcodebox">
<code>package com;
import java.io.BufferedInputStream; 
import java.io.BufferedOutputStream; 
import java.io.FileInputStream; 
  public class IOLab5 {
    public static void main(String[] args) { 
      try{ 
       FileInputStream fin=new FileInputStream("D:\\notes\\abc.txt"); 
       BufferedInputStream bufferedinputstream = new BufferedInputStream(fin);
       int i=0;   
       while((i=bufferedinputstream.read())!=-1){
         System.out.print((char)i);
       }
    } catch (Exception e){    
       e.printStackTrace();
    }
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
    javabykiran Add- Karvenagar,pune
    </code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="FileWriterandFileReaderClass">
<div id="Div6">
<h2 class="breadcrumb">FileWriter and FileReader Classes:</h2>
<p>The file reader and file writer read and write information from text files.</p>
<ul>
<li><p>These are the convenience classes for reading and writing character-oriented data.</p></li>
<li><p>So, it's good to avoid FileInputStream and FileOutputStream if you have to read and write the textual information.</p></li>
<li><p>The constructors of this classes assume that the default character encoding and the default byte-buffer size are appropriate.
<br>For example: Copying data from one file to another file using FileReader and FileWriter.</p></li>
</ul>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code7" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code7" class="breadcrumb pretagcodebox">
<code>package com;
import java.io.FileReader; 
import java.io.IOException; 
public class IOLab6 {
  public static void main(String[] args) { 
    try {
    String srcpath = " D:\\jbk\\IOLab6.java";
    String des pat h = "D:\\notes\\LabProgram3.txt"; 
    FileReader fr = new FileReader(srcpath); 
    FileWriter fw = new FileWriter(despath);
      int i=0;
        while((i=fr.read())!=-1){ 
          fw.write(i); 
          System.out.print((char)i);
       }
  } catch (IOException e) { 
    e.printStackTrace();
  }
 }
}
</code></pre>
</div>
</div><hr>
<div id="Div7">
<p class="card-text">
<h2 class="breadcrumb"><a name="ReadingDatafromKeyboard"></a>Reading Data from Keyboard:</h2>
<p>There are many ways to read from the keyboard. By using the following classes we can read the data from keyboard:</p>
<ul>
<li>InputStreamReader</li>
<li>BufferedReader</li>
<li>Scanner</li>
<li>Console</li>
<li>By using InputStreamReader and Buffered Reader –</li>
</ul>
<div>
<p><b>Example:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com;
import java.io.BufferedReader; 
import java.io.IOException; 
import java.io.InputStreamReader; 
public class IOLab7 {
  public static void main(String[] args) { 
    try {
      InputStreamReader inputStreamReader = new InputStreamReader(System.in);
      BufferedReader br = new BufferedReader(inputStreamReader); 
      String name =" ";
      while(true){
      System.out.println("Enter Website :");
      name = br.readLine(); //Reads a line of text 
      System.out.println("You Enter :"+name); 
      if(name.equals("www.javabykiran.com")){
        break;
     }
   }
    } catch (IOException e) { 
        e.printStackTrace();
   }
 }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     Enter Website : 
     www.google.com 
     You Enter : www.google.com 
     Enter Website :
     www.javabykiran.com
     You Enter :www.javabykiran.com
    </code></pre>
</div><br>
<div>
<p><b>Example:</b><br>Addition of two numbers by scanner class in 1.5 JDK:</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<code>package com;
 import java.util.Scanner; 
   public class IOLab8 {
     public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);
     System.out.print("Enter 1st Number :"); 
     int a = scanner.nextInt() ; 
     System.out.print("Enter 2st Number :"); 
     int b = scanner.nextInt() ; 
     System.out.println("Addition is:"+(a+b));
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     Enter 1st Number :12 
     Enter 2st Number :20 
     Addition is :32
    </code></pre>
</div><br>
<div>
<p><b>Example:</b><br>By using Console class</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
<code>import java.io.Console; 
class IOLab9 {
public static void main(String args[]){ 
Console c = System.console();
    System.out.print("Enter the Name:"); 
    String name = c.readLine(); 
    System.out.print("Hello "+name);
   }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
      Enter the Name : java 
      Hello java
    </code></pre>
</div>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="SequenceInputStream">
<div id="Div8">
<h2 class="breadcrumb"><a name="SequenceInputStream"></a>SequenceInputStream class:</h2>
<ul>
<li><p>This class can be used to read data from multiple streams.</p></li>
<li><p>A SequenceInputStream represents the logical concatenation of other input streams.</p></li>
<li><p>It starts out with an ordered collection of input streams and reads from the first one until end of file is reached, where on it reads from the second one, and so on, until the end of file is reached on the last of the contained input streams.</p></li>
</ul><br>
<div>
<p><b>Example:<br> Reading two files using SequenceInputStream –</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code11" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code11" class="breadcrumb pretagcodebox">
<code>package com;
import java.io.FileInputStream; 
import java.io.SequenceInputStream; 
public class IOLab10 {
    public static void main(String[] args) { 
    try{
      String path1 = "D:\\notes\\abc.txt"; 
      String path2 = "D:\\notes\\xyz.txt";
       FileInputStream fin1 = new FileInputStream(path1); 
       FileInputStream fin2 = new FileInputStream(path2);
SequenceInputStream sis = new SequenceInputStream(fin1,fin2); 
     int i =0; 
     while((i=sis.read())!=-1){
      System.out.print((char)i);
     }
    }catch (Exception e) { 
      e.printStackTrace();
    }
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     www.javabykiran.comCall us to join : 8888809416
    </code></pre>
</div>
</div></div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#IOIntroduction" role="tab" data-toggle="tab">Stream Introduction</a></li>
<li role="presentation"><a href="#CharacterStreams" role="tab" data-toggle="tab">Character Streams</a></li>
<li role="presentation"><a href="#ByteStreams" role="tab" data-toggle="tab">Byte Streams</a></li>
<li role="presentation"><a href="#BufferedIandOStream" role="tab" data-toggle="tab">Buffered I/O Stream</a></li>
<li role="presentation"><a href="#FileWriterandFileReaderClass" role="tab" data-toggle="tab">FileWriter & FileReader</a></li>
<li role="presentation"><a href="#SequenceInputStream" role="tab" data-toggle="tab">SequenceInputStream</a></li>
</ul>
</div></div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="garbage-collection-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="collection-framework-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{ "@context": "https://schema.org", 
 "@type": "Article",
 "headline": "I/O Streams - Java",
 "alternativeHeadline": "What are input and output streams in java?",
 "image": "https://www.jbktutorials.com/images/java/bytestreams.webp",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java input and output streams", 
 "keywords": "java input and output streams, java input stream, java output stream, i/o streams, character stream, byte stream, file reader, file writer", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/input-and-output-streams-in-java.php",
   "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "An Input/Output stream is an input source or output destination which represents various types of sources.",
 "articleBody": "Stream is nothing but sequence of bytes which makes input and output operations feasible and faster. It is called stream because it facilitates a continuous flow of data."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
