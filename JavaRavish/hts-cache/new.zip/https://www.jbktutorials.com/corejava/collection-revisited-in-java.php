<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>JBK Tutorials | Collection Revisited in Java</title>
<meta name="description" content="This Chapter is specially designed to know what all there is in Collection at very advanced level and how it is used in the industry and in business projects.">
<meta name="keywords" content="java tutorials, core java, advance java, java by kiran, java interview questions, blog, articles, learn java programming, codes, examples, selenium, python, spring">
<meta name="author" content="Java By Kiran">
<meta name="robots" content="index, follow">

<meta property="og:title" content="Collection Revisited in Java" />
<meta property="og:url" content="https://www.jbktutorials.com/corejava/collection-revisited-in-java.php" />
<meta property="fb:app_id" content="881390338999747" />
<meta property="og:description" content="This Chapter is specially designed to know what all there is in Collection at very advanced level and how it is used in the industry and in business projects.">
<meta property="og:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta property="og:image:secure_url" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png" />
<meta property="og:type" content="article" />


<meta name="twitter:title" content="Collection Revisited in Java">
<meta name="twitter:description" content="This Chapter is specially designed to know what all there is in Collection at very advanced level and how it is used in the industry and in business projects.">
<meta name="twitter:image" content="https://www.jbktutorials.com/images/jbktutorialslogo3square.png">
<meta name="twitter:card" content="summary_large_image">

<link rel="canonical" href="https://www.jbktutorials.com/corejava/collection-revisited-in-java.php" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon/android-chrome-192x192.png" />
<link rel="apple-touch-icon" href="../images/favicon/apple-touch-icon.png">

<link rel="preload" href="../vendor/bootstrap/css/bootstrap.min.css" as="style">
<link rel="preload" href="../css/customcss.css" as="style">
<link rel="preload" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/styles/a11y-light.css" as="style">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/css/viewer.css" as="style">
<link rel="preload" href="../vendor/syntaxhighlighter/highlight.pack.js" as="script">
<link rel="preload" href="../js/jquery.min.js" as="script">
<link rel="preload" href="../vendor/clipboard/clipboard.min.js" as="script">
<link rel="preload" href="../vendor/bootstrap/js/bootstrap.bundle.min.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" as="script">
<link rel="preload" href="../vendor/jquery-viewer-master/docs/js/main.js" as="script">
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-156439212-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-156439212-1');
  </script>


<script data-ad-client="ca-pub-5964671306985297" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>




<link rel="stylesheet" type="text/css" href="../css/customcss.css">
<link rel="stylesheet" href="../vendor/fontawesome-free-5.0.13/web-fonts-with-css/css/fontawesome-all.min.css">


<link rel="stylesheet" href="../vendor/syntaxhighlighter/styles/a11y-light.css">
<script src="../vendor/syntaxhighlighter/highlight.pack.js"></script>
<script defer>hljs.initHighlightingOnLoad();</script>


<script src="../js/jquery.min.js"></script>
<script src="../vendor/clipboard/clipboard.min.js"></script>



<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>

<link rel="stylesheet" href="../vendor/jquery-viewer-master/docs/css/viewer.css">
<script src="../vendor/jquery-viewer-master/docs/js/viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/jquery-viewer.js" defer></script>
<script src="../vendor/jquery-viewer-master/docs/js/main.js" defer></script>

</head>
<body>

<nav class="navbar navbar-expand-lg border-bottom navbarmenu fixed-top bg-white">
<div class="container p-0">
<a class="navbar-brand pull-left" href="https://www.jbktutorials.com"><img src="../images/jbktutorialslogo3.png" style="height: 65px; max-width: 100%;" alt="java by kiran tutorials" title="JBK Tutorials"></a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse pull-right" id="navbarResponsive">
<script async src="https://cse.google.com/cse.js?cx=001580368639334093203:va4ehh0xpyd"></script>
<div class="gcse-search"></div>
<ul class="navbar-nav ml-auto text-center">
<li class="nav-item">
<a class="nav-link" href="../"><i class="fa fa-home"></i></a>
</li>
<li class="nav-item">
<a class="nav-link" href="../corejava/introduction-to-java.php">Java</a>
</li>

<li class="nav-item">
<a class="nav-link" href="../selenium/eclipse-configuration.php">Selenium</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-tutorials.php">Spring</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../spring-boot-framework-tutorials.php">Spring Boot</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../technical-tutorials.php">Technical Tutorial</a>
</li>
<li class="nav-item">
<a class="nav-link" href="../interview-questions.php">Interview Questions</a>
</li>

</ul>
</div>
</div>
</nav><br>

<script async src="https://platform-api.sharethis.com/js/sharethis.js#property=5e25b77a7fe3e8001237b15f&product=sticky-share-buttons"></script>
 <style>
    .centerimage {
    display: block;
    margin-left: auto; 
    margin-right: auto;}
</style>


<div class="container-fluid">
<br/>
<ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadcrumb no-padding  mt-5 bg-light nohighlight">
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../index.php">
<span itemprop="name">Home</span>
</a>
<meta itemprop="position" content="1" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="../corejava/introduction-to-java.php">
<span itemprop="name">Java</span>
</a>
<meta itemprop="position" content="2" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<a class="text-dark" itemprop="item" href="collection-revisited-in-java.php">
<span itemprop="name">What are advanced concepts of Collection?</span>
</a>
<meta itemprop="position" content="3" />
</li>
<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="breadcrumb-item">
<span itemprop="name">Collection Revisited</span>
<meta itemprop="position" content="4" />
</li>
</ol>

<div class="row">

<link rel="stylesheet" href="../css/sidebarcollapsecss.css">
<style>
    @media only screen and (max-width: 425px){
    .hidesidebar{display: none;}}
</style>
<script>
    //Script to Open and Close Sidebar
function sidebar_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function sidebar_close() {
  document.getElementById("mySidebar").style.display = "none";
}

    // toggle up & down icon
function myFunction(x) {
  x.classList.toggle("fa-book-open");
}
</script>


<button class="w3-button w3-teal w3-hide-large" onclick="sidebar_open()">&#9776;</button>
<div class="col-lg-3 w3-collapse w3-animate-right hidesidebar sidebarfont" id="mySidebar" role="tablist" aria-multiselectable="true">
<div class="card">
<h2 class="card-header text-white" style="background: rgb(1, 71, 128);">Java</h2><br>
<div class="list-group">
<button class="w3-teal bg-transparent w3-large w3-hide-large" onclick="sidebar_close()">Close Menu &times;</button>
<ul class="leftBarList">
<li><a href="introduction-to-java.php">Java Introduction</a></li>
<li><a href="java-language.php">Java Language</a></li>
<li><a href="communication-between-two-classes-in-java.php">Communication Between Two Classes</a></li>
<li><a href="package-in-java.php">Package</a></li>
<li><a href="methods-variable-and-block-in-java.php">Methods, Variable and Block</a></li>
<li><a href="encapsulation-in-java.php">Encapsulation</a></li>
<li><a href="access-modifiers-in-java.php">Access Modifiers</a></li>
<li><a href="statickeyword-in-java.php">Static Keyword</a></li>
<li><a href="final-keyword-in-java.php">Final Keyword </a></li>
<li><a href="constructor-in-java.php">Constructor </a></li>
<li><a href="inheritance-in-java.php">Inheritance </a></li>
<li><a href="super-and-this-keyword-in-java.php">Super This</a></li>
<li><a href="polymorphism-in-java.php">Polymorphism</a></li>
<li><a href="abstraction-in-java.php">Abstraction</a></li>
<li><a href="garbage-collection-in-java.php">Garbage Collection</a></li>
<li><a href="input-and-output-streams-in-java.php">Input Output Stream</a></li>
<li><a href="collection-framework-in-java.php">Collection Framework</a></li>
<li><a href="collection-revisited-in-java.php">Collection Revisited</a></li>
<li><a href="serialization-in-java.php">Serialization</a></li>
<li><a href="exception-in-java.php">Exception</a></li>


<li><a href="arrays-in-java.php">Arrays</a></li>
<li><a href="strings-in-java.php">Strings</a></li>
<li><a href="features-of-jdk-1.5-in-java.php">Features and Enhancements in jdk 1.5</a></li>
<li><a href="features-of-jdk-1.6-in-java.php">Features and Enhancements in jdk 1.6</a></li>
<li><a href="features-of-jdk-1.7-in-java.php">Features and Enhancements in jdk 1.7</a></li>
<li><a href="features-of-jdk-1.8-in-java.php">Features and Enhancements in jdk 1.8</a></li>
<li><a href="multithreading-in-java.php">Thread</a></li>
<li><a href="java-virtual-machine-memory-management.php">JVM Memory Management</a></li>
<li><a href="jdbc-in-java.php">JDBC</a></li>
<li><a href="database-in-java.php">Database</a></li>
</ul>
</div>
</div><br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="1171818896" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
</div>
</div>



<div class="col-lg-7 mb-4">
<div class="card h-100">
<h1 class="card-header text-white" style="background: rgb(1, 71, 128);">Collection Revisited</h1>
<div class="card-body">
<div class="tab" role="tabpanel">
<p class="card-text">
This chapter is specially designed to know what all there is in Collection at very advanced level and how it is used in the industry and in business projects. In this chapter you we will explore the following:
<ul>
<li>What is introduced in jdk 1.5, 1.6 and 1.7?</li>
<li>How does the compiler treat Collection framework in advanced versions of Java?</li>
</ul>
<hr>
<div>

<ul class="nav nav-tabs nav-top" role="tablist">
<li role="presentation" class="active"><a href="#ArrayList" role="tab" data-toggle="tab">ArrayList</a></li>
<li role="presentation"><a href="#Generics" role="tab" data-toggle="tab">Generics</a></li>
<li role="presentation"><a href="#foreachloop" role="tab" data-toggle="tab">foreach loop</a></li>
<li role="presentation"><a href="#Autoboxing" role="tab" data-toggle="tab">Autoboxing</a></li>
<li role="presentation"><a href="#BusinessRequirement" role="tab" data-toggle="tab">Business Requirement</a></li>
</ul>
</div>
<div class="tab-content tabs">
<div role="tabpanel" class="tab-pane fade in active" id="ArrayList">
<div id="Div1">
<h2 class="breadcrumb">ArrayList</h2>
<p>
<ul>
<li>Size means the number of elements present in ArrayList</li>
<li>Capacity means the capability to store elements but in Java it is not restricted,<br>
When we write <br>
<pre><code>ArrayList al=new ArrayList();</code></pre>
by default, the capacity is 10<br>
This you can see in source code of ArrayList.class.
<div>
<p>See the code below from sun microsystem:</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code1" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code1" class="breadcrumb pretagcodebox">
<code>/*
* Constructs an empty list with an initial capacity of 10
*/
   public ArrayList() { 
   this(10);
 }
</code></pre>
</div>
<ul>
<li>So, we can specify our own capacity as well</li>
<li>ArrayList al=new ArrayList(6);</li>
<li>But remember, this does not mean it only takes six elements</li>
</ul>
</li><br>
<li>To add primitives in ArrayList of jdk 1.4 we have add method which asks for the Object</li>
</ul>
<div>
<p><b>Example</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code2" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code2" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection.revisited; 
import java.util.ArrayList ;
/*
* @author Java By Kiran
*/
public class ArrayListTest {
  public static void main(String[] args){
    ArrayList arrayList = new ArrayList();
    //Below is not an error as we put object type 
    arrayList.add(String.valueOf(34));
  }
}
</code></pre>
</div>
<ul>
<li>Here, in this case, we must change primitive to Wrapper class as given below. For more details read the previous collection chapter.<br>
//Below is not an error as we put Object type <br><code>arrayList.add (String.valueOf (34));</code><br>
<b>OR</b> <br>
<code>arrayList.add (new Integer (34));</code>
</li>
</ul>
</div><hr>
<p class="card-text">
<h4><a name="JDK1.5"></a>JDK 1.5</h4>
<p>Following are concepts introduced in new version jdk 1.5:</p>
<ol type="a">
<li>Generics</li>
<li>Auto Boxing</li>
<li>Enhance for loop or for each loop</li>
</ol></div>
<div role="tabpanel" class="tab-pane fade" id="Generics">
<div id="Div2">
<h2 class="breadcrumb">Generics</h2>
<ul>
<li><p>We use generics for type safety, which means only one type of element will get added</p></li>
<li><p>It does not means Sun Microsystem has changed the add method of class ArrayList</p></li>
<li><p>It is same as before and only changes done are in the compiler. In this case, the compiler will do more work on your behalf</p></li>
<li><p>One of compiler tasks, besides compilation, is addition of extra code</p></li>
</ul>
<br>
<p>
<h4>Declaring ArrayList in 1.5</h4>
<ul>
<li><pre><xmp>ArrayList <Integer> al = new ArrayList <Integer>();</xmp></pre></li>
<li><p>This means that the compiler will start giving errors if we try to put any elements other than an integer.</p></li>
<li><p>Point to be remembered: If we look at the byte code, these angular brackets are not considered. This is just for the compiler to give errors.</p></li>
<li><p>In these <>, classes under Object hierarchy are allowed not primitives</p></li>
<li>
In both sides, the class type must be same, No superclass or subclass combination is allowed.<br>
<pre><xmp>ArrayList <Object> al = new ArrayList <Integer>();  // not allowedly
ArrayList <int> al = new ArrayList <int>();  // not allowed – primitives       
</xmp></pre>
<pre><xmp>In jdk 1.7 right side <Integer> or <int> is not needed</xmp></pre>
Like below
<pre><xmp>ArrayList <Integer> al = new ArrayList<>();</xmp></pre>
</li>
</ul>
<br>
<h4>Adding elements in jdk 1.5</h4>
<ol type="1">
<li><p><code>al.add (33)</code> - after the above declaration, we are able to directly add 33 primitive and there is no need of typecasting. This is one of the advantages of generics</p></li>
<li><p>Compiler will convert this line on the fly to <code>al.add(new Integer(33))</code></p></li>
</ol><br>
<h4>Retrieving elements in jdk 1.5</h4>
<ol type="1">
<li><p>
<code>al.get(index)</code> in this case, in the earlier versions we must follow these three :
<pre><code>Object obj=al.get (5) 
Integer i = (Integer) obj; 
int val=i.intValue ();
</code></pre>
</li>
<li><p><code>int val = al.get (index)</code>- This is also one of the extra features of compiler. Object gets converted into the Integer. If we use the decompiler then byte code we see this in the byte code.</p></li>
<li><p>Another way is by using iterator:
<pre><xmp>Iterator <Integer> itr=al.iterator (); 
  while (itr.hasNext()) {
    int element =itr.next(); [ Due to generics we return int directly]
  }
</xmp></pre>
</li>
</ol></div></div>
<div role="tabpanel" class="tab-pane fade" id="foreachloop">
<div id="Div3">
<h2 class="breadcrumb">foreach loop</h2>
<p>The <b>foreach loop</b> in java is used for traversing arrays or collection elements. It is sometimes referred to as the For In loops</p>
<ul>
<li>In this case we need to remember these points below:
<ul>
<li>No increment decrement</li>
<li>No size calculation</li>
<li>Must use generics for iterating</li>
<li><pre><xmp>ArrayList<String> al=new ArrayList<String>(); 
  for (String element : al){
    System.out.println (element)
}
</xmp></pre></li>
<li>This for loop is for compiler. It always gets converted into a simple ordinary for loop</li>
<li><pre><xmp>ArrayList<Student> al=new ArrayList<Student>(); 
  for (Student stu: al) {
    System.out.println (stu.age); 
    System.out.println (stu.loc);
  }
</xmp></pre></li>
<li>This way of iterating element is most commonly used in industrial projects.</li>
</ul>
</li>
</ul></div></div>
<div role="tabpanel" class="tab-pane fade" id="Autoboxing">
<h2 class="breadcrumb"><a name="Autoboxing"></a>Autoboxing</h2>
<ul>
<li>Autoboxing means automatic conversion of objects</li>
<li>This happens in generics; there we don't need type casting</li>
<li>Do not think it is related to collection, it's just type
<ul>
<li><code>Object o =3;</code> // OK in jdk 1.5 because compiler will convert it to Integer</li>
<li><code>Integer i=78;</code> // OK</li>
<li><code>int ii=90;</code> // OK</li>
</ul>
</li>
</ul><hr>
<div>
<h4>Business Use</h4>
<p>Consider the following requirement:<br>
<b>Question:</b> One student has age and location which needs to be added in the Arraylist, and give to ten students to other department.
</p>
<div>
<button class="copycodebuttonstyle" data-clipboard-target="#code8" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code8" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection.revisited;
/*
* @author Java By Kiran
*/
public class Student { 
    int age;
    String loc;
}
</code></pre>
</div>
<p><b>Answer:</b> First we design student as below:</p>
</div><br>
<div>
<p><b>Example 1:</b> Write class which prepares Students and returns from one of method.</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code9" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code9" class="breadcrumb pretagcodebox">
<xmp>package com.javabykiran.Collection.revisited; 
import java.util.ArrayList;
/*
* @author Java By Kiran
*/
public class PrepareStudent { 
ArrayList<Student> buildStudents() {
      Student student1 = new Student(); 
      student1.age = 28;
      student1.loc = "Pune";
      Student student2 = new Student(); 
      student2.age = 30;
      student2.loc = "Nagpur";
      // Students added in arraylist
      // remember a1 knows students’ address but not age and loc
      // Here we are placing addresses not actual data in ArrayList
      ArrayList<Student> arrayListStu = new ArrayList<Student>();
      arrayListStu.add(student1); 
      arrayListStu.add (student2); 
      return arrayListStu;
   }
}
</xmp></pre>
</div><br>
<div>
<p>Now, write the class which gets students from above class's buildStudents () method and iterate over them to get students age and location.<br>
<b>Example 2:</b>
</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
<xmp>package com.javabykiran.Collection.revisited; 
import java.util.ArrayList;
/*
* @author Java By Kiran
*/
public class RetriveStudents { 
 void fetchStudent() {
      PrepareStudent prepare = new PrepareStudent ();
      ArrayList<Student> listStu = prepare.buildStudents();
      // enhance for loop -- for each loop 
      for (Student student : listStu) {
          System.out.println("students age: " + student.age);
          System.out.println("students location: "+ student.loc);
      }	
  }
}
</xmp></pre>
</div><br>
<div>
<p>Write client class to test our logic.</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code10" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code10" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection.revisited;
/*
* @author Java By Kiran
*/
public class TestStudentsOperation { 
    public static void main(String[] args) {
    // prepare students
    PrepareStudent sp=new PrepareStudent();        
    sp.buildStudents();
    //retrieve students
    RetriveStudents retrivestudents = new RetriveStudents();    
        retrivestudents.fetchStudent ();
  }
}
</code></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     students age: 28
     students location: Pune
     students age: 30
     students location: Nagpur

  </code></pre>
</div></div>
<div role="tabpanel" class="tab-pane fade" id="BusinessRequirement">
<h2 class="breadcrumb">Business Requirement</h2>
<div>
<p><b>Question:</b> One student, who has age, location and many phone numbers, needs to be added in ArrayList and given to other department which has ten students.</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code11" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code11" class="breadcrumb pretagcodebox">
<xmp>package com.javabykiran.Collection.revisited; 
import java.util.ArrayList;
/*
* @author Java By Kiran
*/
public class Student { 
   int age;
   String loc;    
   ArrayList<String> alMobNo;
}

package com.javabykiran.Collection.revisited; 
import java.util.ArrayList;
/*
* @author Java By Kiran
*/
public class StudentPrepare {        
    ArrayList<Student> buildStudents(){
      Student student1 = new Student();   
      student1.age = 28;
      student1.loc = "Pune";
      
      //creates list of mobile numbers of student1 
    ArrayList<String> alMobNoStu1 = new ArrayList<>();
      alMobNoStu1.add("8888809416");   
      alMobNoStu1.add("9552343698"); 
      student1.alMobNo = alMobNoStu1; 
      Student student2 = new Student(); 
      student2.age = 28;
      student2.loc = "Pune";
      
      //creates list of mobilenumbers of student2 
    ArrayList<String> alMobNoStu2 = new ArrayList<>();
      alMobNoStu2.add("8234876642"); 
      alMobNoStu2.add("3455455441"); 
      student2.alMobNo = alMobNoStu2;
      // Students added in arraylist
      //remember al knows students’ address not their age and loc
      
      //Here we are placing address, not actual data in ArrayList    
    ArrayList<Student> arrayListStu = new ArrayList<>();
      arrayListStu.add(student1);  
      arrayListStu.add (student2);
      System.out.println("ArrayList >> "+ arrayListStu); 
      return arrayListStu;
   }	
}
</xmp></pre>
</div><br>
<div>
<p>For Fetching Students use the method given below: <br>
<b>Example 4:</b></p>
<button class="copycodebuttonstyle" data-clipboard-target="#code12" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code12" class="breadcrumb pretagcodebox">
<xmp>void fetchStudent() {
  StudentPrepare prepare = new StudentPrepare();
  ArrayList <Student> listStu = prepare.buildStudents();
    //Enhance for loop -- foreach loop 
    for(Student student : listStu) {
     System.out.println("students age: " + student.age);  
     System.out.println("students location: " + student.loc);
       ArrayList<String> alMobNo = student.alMobNo;    
         for (String mobNo : alMobNo) {       
         System.out.println("al mob no" + mobNo);
       } // end 1st For loop
    }// end 2nd for loop
}
</xmp></pre>
<pre class="codeblock3 breadcrumb"><code class="nohighlight">
    <b>Output:</b>
     ArrayList >> [com.jbk.Student@15db9742, com.jbk.Student@6d06d69c]
     students age: 28
     students location: Pune
     al mob no: 8888809416
     al mob no: 9552343698
     students age: 28
     students location: Pune
     al mob no: 8234876642
     al mob no: 3455455441
  </code></pre>
</div><br>
<h4>Consider the following requirement:</h4>
<div>
<p><b>Example 5:</b><br>
<b>Question:</b> One student has age, location and a phone having two types, one landline number and many mobile numbers. It needs to be added in ArrayList and given to other department which has ten students.<br>
First we design Phone as below:
</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code12" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code12" class="breadcrumb pretagcodebox">
<xmp>package com.javabykiran.Collection.revisited; 
import java.util.ArrayList;
/*
* @author Java By Kiran
*/
public class Phone { 
  int landLineNo;
  ArrayList<String> mobNos;
</xmp></pre>
</div><br>
<div>
<p>First we design Student as below having phone attribute: This also shows one to one relationship.</p>
<button class="copycodebuttonstyle" data-clipboard-target="#code13" onclick="copySuccessMessage()"><i class="fa fa-clipboard"></i></button>
<pre id="code13" class="breadcrumb pretagcodebox">
<code>package com.javabykiran.Collection.revisited; 
import java.util.ArrayList;
/*
* @author Java By Kiran
*/
public class Student { 
  int age;
  String loc; 
  Phone p;
}
</code></pre>
</div>
Try adding students and fetching.
</div>
</div><hr>
<ul class="nav nav-tabs nav-bottom mt-3" role="tablist">
<li role="presentation" class="active"><a href="#ArrayList" role="tab" data-toggle="tab">ArrayList</a></li>
<li role="presentation"><a href="#Generics" role="tab" data-toggle="tab">Generics</a></li>
<li role="presentation"><a href="#foreachloop" role="tab" data-toggle="tab">foreach loop</a></li>
<li role="presentation"><a href="#Autoboxing" role="tab" data-toggle="tab">Autoboxing</a></li>
<li role="presentation"><a href="#BusinessRequirement" role="tab" data-toggle="tab">Business Requirement</a></li>
</ul>
</div></div>
<div class="card-footer">
<ul class="pagination justify-content-center mb-4">
<li class="page-item">
<a class="page-link btn-outline-primary" href="collection-framework-in-java.php">&lArr; Previous Chapter</a>
</li>
<li class="page-item">
<a class="page-link" href="serialization-in-java.php">Next Chapter &rArr;</a>
</li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 mb-4">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="6605368152" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
<br>
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5964671306985297" data-ad-slot="7335995893" data-ad-format="auto" data-full-width-responsive="true">
</ins>
<script>
               (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
</div>
</div>

</div>

</div>

<script type="application/ld+json">
{"@context": "https://schema.org", 
 "@type": "Article",
 "headline": "Collection Revisited - Java",
 "alternativeHeadline": "What are advanced collections in java?",
 "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
 "author": {
    "@type": "Person",
    "name": "Kiran Digrase"
  },
 "genre": "java advanced collections", 
 "keywords": "java collection advanced, collection revisited, advanced collection, arraylist, generics, foreach loop, autoboxing", 
 "publisher": {
    "@type": "Organization",
    "name": "Java By Kiran",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.javabykiran.com/images/logojbk.png"
    }
  },
 "url": "https://www.jbktutorials.com/corejava/collection-revisited-in-java",
    "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.javabykiran.com/"
  },
 "datePublished": "2019-11-22",
 "dateCreated": "2019-11-22",
 "dateModified": "2019-11-22",
 "description": "The collection framework in java is made up of classes and interfaces that stores and processes data in an efficient manner.",
 "articleBody": "This chapter is specially designed to know what all there is in Collection at very advanced level and how it is used in the industry and in business projects."
 }
</script>

<style>
   .footerfont{font-size: 16px}
</style>
<div class="footer footerfont" style="background: #55585a;">

<div class="container text-center text-md-left"><br>

<div class="row">

<div class="col-md-3 mt-md-0 mt-3">

<p><b class="text-white">About Us</b></p>
<p class="text-white">Java by Kiran has been actively helping students to enhance their skills in IT Industry (specially in Java, Selenium & Python). Our aim is to provide quality education to all.</p>
</div>

<hr class="clearfix w-100 d-md-none">

<div class="col-md-2 mb-md-0 mb-3">

<p><b class="text-white">Tutorials</b></p>
<ul class="list-unstyled">
<li>
<a href="../corejava/introduction-to-java.php" class="footerlinks">Java</a>
</li>
<li>
<a href="../selenium/eclipse-configuration.php" class="footerlinks">Selenium</a>
</li>
<li>
<a href="../spring-tutorials.php" class="footerlinks">Spring</a>
</li>
<li>
<a href="../spring-boot-framework-tutorials.php" class="footerlinks">Spring Boot</a>
</li>
</ul>
</div>

</div>

</div>

<div class="footer-copyright border-top ">
<div class="container">
<div class="row">

<div class=" col-sm-6 pull-left py-3 text-white">Copyright © 2020
<a href="http://javabykiran.com" class="footerlinks" target="_blank">javabyKiran</a>
</div>

<div class="col-sm-6 pull-right">
<ul class="list-unstyled p-0 mt-4 text-right mb-1">
<a href="https://www.facebook.com/javabykiran" class="icon" target="_blank"><i class="fab fa-facebook"></i></a>
<a href="https://www.twitter.com/javabykiran" class="icon" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.instagram.com/javabykiran/" class="icon" target="_blank"><i class="fab fa-instagram"></i></a>
<a href="https://ca.linkedin.com/company/javabykiran" class="icon" target="_blank"><i class="fab fa-linkedin"></i></a>
<a href="https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA" class="icon" target="_blank"><i class="fab fa-youtube"></i></a>
</ul>
</div>
</div>
</div>
</div>
</div>





<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "logo": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-888-880-9416",
    "contactType": "customer service"
  },
  
  "sameAs": [
    "https://www.facebook.com/javabykiran",
    "https://twitter.com/javabykiran",
    "https://plus.google.com/+JavabyKiran",
    "https://www.instagram.com/javabykiran/",
    "https://www.youtube.com/channel/UCZoq1kylnMYP_c5WG9FV9XA",
    "https://ca.linkedin.com/company/javabykiran"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "PostalAddress",
  "name": "JBK Tutorials",
  "url": "https://www.jbktutorials.com/",
  "image": "https://www.jbktutorials.com/images/jbktutorialslogo3.png",
  "addressLocality": "Pune",
   "addressRegion": "Maharashtra",
   "postalCode": "411052",
   "streetAddress": "403, 4th Floor, Park Plaza, Above Birla super Market, State Bank Nagar, Karve Nagar,Pune "
  }

</script>

<script>

$(document).ready(function (){
	$('.tab-pane').addClass('show');
});

$('ul.nav-bottom').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-bottom li').removeClass('active');
		$('.nav-top li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

$('ul.nav-top').find('a').click(function(){
	$('.tab-pane').addClass('show');
	var $href = $(this).attr('href');
	$('html, body').animate({
		scrollTop: ($($href).first().offset().top)-90
	},500);
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var target = $(e.target).attr("href");
		$('.nav-top li').removeClass('active');
		$('.nav-bottom li').removeClass('active');
		$('[href*="'+target+'"]').parent('li').addClass('active');
	})
});

 //Script for Copy to Clipboard
var clipboard = new Clipboard('button');
  function copySuccessMessage() {
  alert("Copied to Clipboard!");
}
 </script>
</body>

</html>
